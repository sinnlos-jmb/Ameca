/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ameca;

/**
 *
 * @author manu
 */

import com.mysql.cj.util.StringUtils;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import manu.utils.*;

public class Comercios extends HttpServlet
{  public void doGet(HttpServletRequest request, HttpServletResponse response)
	  throws ServletException, IOException

   {  //	htmls.logger.fine("homeOsoc. Carga servlet\n--");
   
   		response.setContentType("text/html");
	  	PrintWriter out = response.getWriter();

		String operacion  = request.getParameter ("operacion") != null ?  request.getParameter ("operacion") : "nuevo" ;
		String nro_cuit  = request.getParameter ("nro_cuit") != null ?  request.getParameter ("nro_cuit") : "--" ;
                if (nro_cuit.equals(""))
                    nro_cuit="--";
		String razon_social  = request.getParameter ("razon_social") != null ?  request.getParameter ("razon_social") : "" ;
		String nombre_responsable  = request.getParameter ("nombre_responsable") != null ?  request.getParameter ("nombre_responsable") : "" ;
		String apellido_responsable  = request.getParameter ("apellido_responsable") != null ?  request.getParameter ("apellido_responsable") : "" ;
		String id_zona  = request.getParameter ("id_zona") != null ?  request.getParameter ("id_zona") : "0" ;
		String id_localidad  = request.getParameter ("id_localidad") != null ?  request.getParameter ("id_localidad") : "0" ;
		String nro_telefono  = request.getParameter ("nro_telefono") != null ?  request.getParameter ("nro_telefono") : "" ;
		String email  = request.getParameter ("email") != null ?  request.getParameter ("email") : "" ;

		String id_comercio  = request.getParameter ("id_comercio") != null ?  request.getParameter ("id_comercio") : "0" ;
		String calle_comercio  = request.getParameter ("calle_comercio") != null ?  request.getParameter ("calle_comercio") : "" ;
		String cuit_calle  = request.getParameter ("cuit_calle") != null ?  request.getParameter ("cuit_calle") : "" ;

                

                if(operacion.equals("find"))
                    {
                    out.println(HTML.getHead("comercios"));
                    out.println("<br>\n<h1>Administrar Comercios</h1>"+
                    		"\n<form action='/ameca/comercios'>\n\t" +
                                "\n\tIngrese CUIT del Comercio: <input type='text' name='nro_cuit'>\n\t");
                    out.println("\n<br>Ingrese Calle del Establecimiento: "+ 
                                "<input type='text' name='calle_comercio'><br><br>");		
                    out.println("<input type='hidden' name='operacion' value='find'> "+ 
                                "<input type='submit'>\n</form><br><br>");

                    if (!cuit_calle.equals(""))
                        out.println(this.TablaFindComercios(cuit_calle));
                    else if(!nro_cuit.equals("--") || !calle_comercio.equals("--"))
                         out.println(this.TablaFindComercios(nro_cuit, calle_comercio));
                    

                    out.println("<table><tr><td height='377px'></td></tr></table>"); 
                    out.println(HTML.getTail());

                    }
                else if (operacion.equals("new"))
                    {
                    out.println(HTML.getHead("comercios")); //devuelve la mitad de la tabla con <tr>s hasta las catgegs del menu (inicio, comercios, liquidaciones, facturacion).
                    out.println("<h1>Nuevo Comercio:</h1> <br>"+
   				"\n<form action=/ameca/comercios><table cellSpacing='0' cellPadding='0'>\n\t"+
                                "<tr>\n\t\t<td>CUIT: </td><td><input type=\"number\" name=\"nro_cuit\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Razon Social: </td><td><input type=\"text\" name=\"razon_social\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Nombre Responsable: </td><td><input type=\"text\" name=\"nombre_responsable\"></td>\n\t"+
                                "\t<td>Apellido Responsable: </td><td><input type=\"text\" name=\"apellido_responsable\"></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Domicilio Fiscal: </td><td><input type=\"text\" name=\"domicilio_fiscal\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Localidad: </td><td><select name=\"id_localidad\"><option value=\"1\">CABA</option><option value=\"2\">Pvcia. BA</option></td>\t"+
                                "\t<td>Zona: </td><td><select name=\"id_zona\"><option value=\"1\">Caminando</option><option value=\"2\">Lanus</option></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Telefono: </td><td><input type=\"number\" name=\"nro_telefono\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Email: </td><td><input type=\"email\" name=\"email\"></td><td></td><td></td></tr>");
		
                    out.println("</table><input type=\"hidden\" name=\"operacion\" value=\"save\"> <input type=\"submit\"></form>\n\n");
    
                    out.println("<table><tr><td height='277px'></td></tr></table>"); // aca va el contenido del cuerpo bajo, mas claro
                    
                    out.println(HTML.getTail());                   
                    
                    }
                else if (operacion.equals("save")) //guarda los datos recibidos del formulario ya completo
                    {
                    out.println("<html><head><title>Ameca - Save Data</title>\n\n</head>" +
   				"<body marginheight='0' marginwidth='0'>  \n\n  "+
   				"\nValores recibidos del formulario: <br>"+
   				"\n<table cellSpacing='0' cellPadding='0'>\n\t"+
                                "<tr>\n\t\t<td>CUIT: "+nro_cuit+"</td></tr>"+
                                "<tr>\n\t\t<td>Razon Social: "+razon_social+"</td></tr>"+
   				"\n\t<tr>\n\t\t<td>Nombre Responsable: "+nombre_responsable+"</td></tr>"+
   				"\n\t<tr>\n\t\t<td>Apellido Responsable: "+apellido_responsable+"</td></tr>"+
   				"\n\t<tr>\n\t\t<td>Localidad: "+id_localidad+"</td></tr>"+
   				"\n\t<tr>\n\t\t<td>Zona: "+id_zona+"</td></tr>" +
   				"\n\t<tr>\n\t\t<td>Telefono: "+nro_telefono+"</td></tr>" +
   				"\n\t<tr>\n\t\t<td>E-Mail: "+email+"</td></tr>" +
                                "</table>");
                    
                    String res=this.insertaComercio(nro_cuit, razon_social, nombre_responsable, apellido_responsable, id_zona, id_localidad, nro_telefono, email);
                    
                    out.println("INSERT Execute: "+res+"<br><br>");
                    
                    
                    out.println("<a href=\"/ameca/comercios?operacion=detalle&id_comercio="+res+"\">Cargar Establecimientos</a> <br><br>");
                    out.println("<a href=\"/ameca/comercios?operacion=new\">Nuevo Comercio</a></body></html>");
                    
                    }
                else if (operacion.equals("detalle"))
                    {
                    out.println(HTML.getHead("comercios"));
                    out.println("<br><br><br>");

                    out.println("<table width='1300px' bgcolor='#E8E7C1' cellspacing='0'>\n\t"
                            + "<tr><th bgcolor='#ccc793'>&nbsp;&nbsp;&nbsp;</th><th align='center' colspan='5' bgcolor='#ccc793'><h2>Administrar Comercio</h2></th><th bgcolor='#ccc793'>&nbsp;&nbsp;&nbsp;</th></tr>"
                            + "<tr><td colspan='7' height='15px'></td></tr>"
                            + "<tr><td></td><td rowspan='2' valign='top'>"+this.DatosComercioTable(id_comercio)+"</td><td width='40px'></td><td valign='top'> <h3>Perfil Impositivo</h3></td><td width='40px'></td><td valign='top' align='left'><h3>Establecimientos</h3></td><td></td>");
                    
                    out.println("<tr><td></td><td></td><td valign='top'>"+this.getPerfilImpositivo(id_comercio, nro_cuit)+"</td><td></td><td valign='top'>"+this.DatosEstablecimientoTable(id_comercio, nro_cuit)+"</td><td></td>\n\t</tr>\t\n");
                    
                    out.println("\n");

                    out.println("<tr><td colspan='7' height='15px'></td></tr></table><br><br><br><br>");

                    out.println(HTML.getTail());                    
                                        
                    }
                
                
  }



    // Recibe  el id_comercio y devuelve una tabla html con sus datos 

    private String DatosComercioTable(String id_comercio) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        String razon_social="", nombre_responsable="", domicilio_fiscal="", id_localidad="", nro_telefono="", email="", nro_cuit="";
	String resul="", codigo_postal="", fecha_baja="", observaciones="", fecha_alta="";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement( "SELECT nro_cuit, razon_social, nombre_responsable, domicilio_fiscal, fecha_alta, id_localidad, nro_telefono, email, " +
                                                "codigo_postal, fecha_baja, observaciones_comercio "+
                                        " FROM dbAmeca.Comercios"+
                                        " WHERE id_comercio="+id_comercio);

                                               
            rs = pst.executeQuery();
            if (rs.next())
                {
                 nro_cuit=rs.getString(1);
                 razon_social=rs.getString(2);
                 nombre_responsable=rs.getString(3);
                 domicilio_fiscal=rs.getString(4);
                 fecha_alta=rs.getString(5)!= null ?  rs.getString(5) : "" ;
                 id_localidad=rs.getString(6);
                 nro_telefono=rs.getString(7);
                 email=rs.getString(8);
                 codigo_postal=rs.getString(9)!= null ?  rs.getString(9) : "" ;
                 fecha_baja=rs.getString(10)!= null ?  rs.getString(10) : "" ;
                 
                 observaciones=rs.getString(11);

                }
            
            resul="<table><tr>\n\t\t<td>CUIT: <b>"+nro_cuit+"</b></td></tr>"+
                    "<tr>\n\t\t<td>Razon Social: <b>"+razon_social+"</b></td></tr>"+
                    "\n\t<tr>\n\t\t<td>Nombre Responsable: <b>"+nombre_responsable+"</b></td></tr>"+
                    "\n\t<tr>\n\t\t<td>Domicilio Fiscal: <b>"+domicilio_fiscal+"</b></td></tr>"+
                    "\n\t<tr>\n\t\t<td>Provincia: <b>"+domicilio_fiscal+"</b></td></tr>"+
                    "\n\t<tr>\n\t\t<td>Codigo Postal: <b>"+HTML.getProvincia(id_localidad)+"</b></td></tr>"+
                    "\n\t<tr>\n\t\t<td>Localidad: <b>"+id_localidad+"</b></td></tr>"+
                    "\n\t<tr>\n\t\t<td>Telefono: <b>"+nro_telefono+"</b></td></tr>" +
                    "\n\t<tr>\n\t\t<td>E-Mail: <b>"+email+"</b></td></tr>" +
                    "\n\t<tr>\n\t\t<td>Fecha de Alta: <b>"+fecha_alta+"</b></td></tr>" +
                    "\n\t<tr>\n\t\t<td>Fecha de Baja: <b>"+fecha_baja+"</b></td></tr>" +
                    "\n\t<tr>\n\t\t<td>Comentarios: <textarea name='observaciones' cols='60' rows='8'>"+observaciones+"</textarea></td></tr>" +
                    "\n\t<tr>\n\t\t<td align='center'><br><a href=\"/ameca/liquidaciones?operacion=ver_c&id_comercio="+id_comercio+"&nro_cuit="+nro_cuit+"\">Ver D.D.J.J actual</a></td></tr>" +
                    "</table>";
            
            
            
            }
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con datos del comercio
        }

 
    

    // Recibe  el id_comercio y devuelve una tabla html con los datos de sus establecimientos 

    private String DatosEstablecimientoTable(String id_comercio, String nro_cuit) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        CX connection=null;

	String resul="", id_establecimiento, nombre_establecimiento;
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement( "SELECT e.id_establecimiento, e.id_actividad, e.nombre_establecimiento, e.direccion_establecimiento, " // 4
                                            + "e.id_zona, e.id_localidad, porcentaje_sociedad, nro_telefono_establecimiento, email_establecimiento, "  // 9
                                            + "e.nombre_responsable_establecimiento" + 
                                        " FROM Establecimientos e"+
                                        " WHERE e.id_comercio="+id_comercio);

                                               

            rs = pst.executeQuery();
            
            resul="\n<table cellpadding='0' cellspacing='0'> \n\n";
            while (rs.next())
                {
                 id_establecimiento=rs.getString(1);
                 nombre_establecimiento=rs.getString(3);
                 resul+="<tr><td>\n<table border='1' cellpadding='0' cellspacing='0'>";
                 resul+="\n\t<tr>\n\t\t<td>Nombre Establecimiento: "+nombre_establecimiento+"<br>\n\t";
                 resul+="\t\tDireccion: "+rs.getString(4)+"<br>\n\t";
                 resul+="\n\tNombre Responsable: "+rs.getString(10)+"<br>\n\t";
                 resul+="\t\tActividad: "+rs.getString(2)+"<br>\n\t";
                 resul+="\t\tProvincia: "+rs.getString(2)+"<br>\n\t";
                 resul+="\t\tLocalidad: "+rs.getString(6)+"<br>\n\t";
                 resul+="\t\tZona: "+rs.getString(5)+"<br>\n\t";
                 resul+="\t\tTelefono: "+rs.getString(8)+"<br>\n\t";
 
                 resul+="\t\tEditar Establecimiento "+
                          "<a href='/ameca/establecimientos?operacion=liqui&id_establecimiento="+id_establecimiento+"&id_comercio="+id_comercio+"&nro_cuit="+nro_cuit+"&periodo="+HTML.getPeriodo()+"'>Cargar Tributos</a>\n"+
                          "<a href='/ameca/liquidaciones?operacion=ver_e&id_establecimiento="+id_establecimiento+"&id_comercio="+id_comercio+"&nombre_establecimiento="+nombre_establecimiento+"&periodo=201908&nro_cuit="+nro_cuit+"'>Ver D.D.J.J</a> <br>\n\t";
                 resul+="\n\t</td></tr></table><br>\n\n";
                 resul+="\n\t</td></tr>";
                }
                resul+="\n\t<tr>\n\t\t<td align='center'><br><a href='/ameca/establecimientos?operacion=new&id_comercio="+id_comercio+"&nro_cuit="+nro_cuit+"'>Agregar Nuevo Establecimiento</a></td>\n\t</tr>";
  
            resul+="\n</table>";
            
            }
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con establecimientos del comercio activo
        }

    


        private String getPerfilImpositivo(String id_comercio, String nro_cuit) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
       CX connection=null;

	String resul="";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement( "SELECT id_condicion_iibb, id_condicion_iva, id_categ_monotributo, id_categ_autonomo "+
                                        " FROM Comercios "+
                                        " WHERE id_comercio="+id_comercio);

                                               

            rs = pst.executeQuery();

            resul="\n<table cellpadding='0' cellspacing='0'> \n\n";
            if (rs.next())
                 resul+="<tr><td>\n<table border='1' cellpadding='0' cellspacing='0'>"+
                        "\n\t<tr>\n\t\t<td>Condicion I.I.B.B.: <b>"+HTML.getCondicionIIBB(rs.getString(1))+"</b><br>\n\t"+
                        "\t\tCondicion I.V.A.: <b>"+HTML.getCondicionIVA(rs.getString(2))+"</b><br>\n\t"+
                        "<br><br>\t\t"+HTML.getCategoriaMonotributo(rs.getString(3))+"\n\t"+
                        "\t\t"+HTML.getCategoriaAutonomo(rs.getString(4))+"<br>\n\t"+
                        "\n\t</td></tr></table><br>\n\n"+
                        "\n\t</td></tr>";
                resul+="\n\t<tr>\n\t\t<td align='center'><br><a href='/ameca/establecimientos?operacion=new&id_comercio="+id_comercio+"&nro_cuit="+nro_cuit+"'>Editar Situacion Impositiva</a></td>\n\t</tr>";
  
            resul+="\n</table>";
            
            }
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con establecimientos del comercio activo
        }




    
    
    
     // inserta nuevo comercio en tabla Comercios y devuelve el id_comercio 

    private String insertaComercio(String nro_cuit, String razon_social, String nombre_responsable, String apellido_responsable, 
                                    String id_zona, String id_localidad, String nro_telefono, String email) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        CX connection=null;
        long resul_insert;
 
	String resul="";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement("INSERT INTO dbAmeca.Comercios (nro_cuit, razon_social, nombre_responsable, apellido_responsable, id_zona, id_localidad, nro_telefono, email) "
                                    + " VALUES ('"+nro_cuit+"', '"+razon_social+"', '"+nombre_responsable+"', '"+apellido_responsable+"', "
                                                +id_zona+", "+id_localidad+", '"+nro_telefono+"', '"+email+"')");
                                               
            resul_insert = pst.executeUpdate();
            if (resul_insert>0)
                pst = con.prepareStatement("select last_insert_id()");
            else 
                return "todo mal";
            rs=pst.executeQuery();
            if (rs.next())
		resul=rs.getString(1);
            rs = pst.executeQuery();

            }
        catch (SQLException ex) {
               return "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                return ex.getMessage();
                }
            }
        
        return resul;  //id_comercio del nuevo registro
        }

    
    
     
     // recibe CUIT, entero o parte, y devuelve tabla con loc comercios que cumplen con link para editarlos
    
   private String TablaFindComercios (String cuit_calle) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        
	String query, resul="\n\n<table class='bicolor' align='center'><tr><th>CUIT</th><th>Razon Social</th><th>Responsable</th><th>Domicilio Fiscal (Comercio)</th><th>Direccion Establecimiento</th><th></th></tr>\n";

        if (StringUtils.isStrictlyNumeric(cuit_calle.substring(0,2)))
            query="SELECT c.id_comercio, razon_social, nombre_responsable, apellido_responsable, nro_cuit, domicilio_fiscal, '--' "+
                   "FROM Comercios c "+
                   "WHERE c.nro_cuit like '"+cuit_calle+"%' "+
                   "ORDER BY c.nro_cuit";
        else
            query= "SELECT c.id_comercio, razon_social, nombre_responsable, apellido_responsable, nro_cuit, domicilio_fiscal, direccion_establecimiento "+
                   "FROM Comercios c, Establecimientos e "+
                   "WHERE c.id_comercio=e.id_comercio AND (domicilio_fiscal like '"+cuit_calle+"%' OR direccion_establecimiento like '"+cuit_calle+"%') "+
                   "ORDER BY c.nro_cuit" ;
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next())
		resul+="<tr><td>"+rs.getString(5)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(4)+", "+rs.getString(3) +"</td><td>"+rs.getString(6) +"</td><td>"+rs.getString(7) +"</td><td><a href=\"/ameca/comercios?operacion=detalle&nro_cuit="+rs.getString(5)+"&id_comercio="+rs.getString(1)+"\">Ver Comercio</a></tr>\n";

            resul+="</table>";
            }
            
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //id_comercio del nuevo registro
        }

     // recibe CUIT y calle (de comercio o establecimiento), entero o parte, y devuelve tabla con loc comercios que cumplen con link para editarlos
    
   private String TablaFindComercios (String nro_cuit, String calle_comercio) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        
	String  query="", resul="\n\n<table class='bicolor' align='center'><tr><th>CUIT</th><th>Razon Social</th><th>Responsable</th><th>Domicilio Fiscal (Comercio)</th><th>Direccion Establecimiento</th><th></th></tr>\n";
        if (nro_cuit.equals("--") && calle_comercio.equals(""))
                return "";
        else if (!nro_cuit.equals("--") && calle_comercio.equals(""))
                query= "SELECT id_comercio, razon_social, nombre_responsable, apellido_responsable, nro_cuit, domicilio_fiscal, 'Direccion Establecimiento' "+
                                       "FROM Comercios  WHERE nro_cuit like '"+nro_cuit+"%' ";
        else if (nro_cuit.equals("--") && !calle_comercio.equals(""))
                query= "SELECT c.id_comercio, razon_social, nombre_responsable, apellido_responsable, nro_cuit, domicilio_fiscal, direccion_establecimiento "+
                                       "FROM Comercios c, Establecimientos e WHERE c.id_comercio=e.id_comercio AND (domicilio_fiscal like '"+calle_comercio+"%' OR direccion_establecimiento like '"+calle_comercio+"%')" ;
        else if (!nro_cuit.equals("--") && !calle_comercio.equals(""))
                query= "SELECT c.id_comercio, razon_social, nombre_responsable, apellido_responsable, nro_cuit, domicilio_fiscal, direccion_establecimiento' "+
                                       "FROM Comercios c, Establecimientos e WHERE c.id_comercio=e.id_comercio  AND nro_cuit like '"+nro_cuit+"%' AND (direccion_establecimiento like '"+calle_comercio+"%' OR domicilio_fiscal like '"+calle_comercio+"%')";
        
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next())
		resul+="<tr><td>"+rs.getString(5)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(4)+", "+rs.getString(3) +"</td><td>"+rs.getString(6) +"</td><td>"+rs.getString(7) +"</td><td><a href=\"/ameca/comercios?operacion=detalle&nro_cuit="+rs.getString(5)+"&id_comercio="+rs.getString(1)+"\">Ver Comercio</a></tr>\n";

            resul+="</table>";
            }
            
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //id_comercio del nuevo registro
        }
 

}