/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ameca;

/**
 *
 * @author manu
 */

import com.mysql.cj.util.StringUtils;
import java.io.IOException;
import java.io.PrintWriter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import manu.utils.*;

public class Establecimientos extends HttpServlet
{  public void doGet(HttpServletRequest request, HttpServletResponse response)
	  throws ServletException, IOException

   {  //	htmls.logger.fine("homeOsoc. Carga servlet\n--");
   
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    String operacion  = request.getParameter ("operacion") != null ?  request.getParameter ("operacion") : "nuevo" ;

    String nro_cuit  = request.getParameter ("nro_cuit") != null ?  request.getParameter ("nro_cuit") : "--" ;
    String nombre_establecimiento  = request.getParameter ("nombre_establecimiento") != null ?  request.getParameter ("nombre_establecimiento") : "" ;
    String direccion_establecimiento  = request.getParameter ("direccion_establecimiento") != null ?  request.getParameter ("direccion_establecimiento") : "" ;
    String id_actividad  = request.getParameter ("id_actividad") != null ?  request.getParameter ("id_actividad") : "" ;
    String id_zona  = request.getParameter ("id_zona") != null ?  request.getParameter ("id_zona") : "0" ;
    String id_localidad  = request.getParameter ("id_localidad") != null ?  request.getParameter ("id_localidad") : "0" ;
    String nro_telefono_establecimiento  = request.getParameter ("nro_telefono_establecimiento") != null ?  request.getParameter ("nro_telefono_establecimiento") : "" ;
    String email_establecimiento  = request.getParameter ("email_establecimiento") != null ?  request.getParameter ("email_establecimiento") : "" ;

    String id_comercio  = request.getParameter ("id_comercio") != null ?  request.getParameter ("id_comercio") : "0" ;
    String id_establecimiento  = request.getParameter ("id_establecimiento") != null ?  request.getParameter ("id_establecimiento") : "0" ;

    String periodo  = request.getParameter ("periodo") != null ?  request.getParameter ("periodo") : "2021908" ;
    String base_imponible  = request.getParameter ("base_imponible") != null ?  request.getParameter ("base_imponible") : "0" ;
    String alicuota_iva  = request.getParameter ("alicuota_iva") != null ?  request.getParameter ("alicuota_iva") : "21" ;
    String alicuota_iibb  = request.getParameter ("alicuota_iibb") != null ?  request.getParameter ("alicuota_iibb") : "3" ;
    String compra_iva  = request.getParameter ("compra_iva") != null ?  request.getParameter ("compra_iva") : "0" ;
    String percepcion_iva  = request.getParameter ("percepcion_iva") != null ?  request.getParameter ("percepcion_iva") : "0" ;
    String percepcion_iibb  = request.getParameter ("percepcion_iibb") != null ?  request.getParameter ("percepcion_iibb") : "0" ;

    if (!StringUtils.isStrictlyNumeric(percepcion_iva))
        percepcion_iva="0";




    if(operacion.equals("find"))
        {


        }
    else if (operacion.equals("new"))
        {
        out.println(HTML.getHead("comercios"));
        out.println("\n<h1>Nuevo Establecimiento</h1><br>"+
                    "\n<form action='/ameca/establecimientos'><table cellSpacing='0' cellPadding='0'>\n\t"+
                    "<table><tr>\n\t\t<td>Direccion: </td><td><input type='text' name='direccion_establecimiento'></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Nombre Establecimiento: </td><td><input type='text' name='nombre_establecimiento'></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Actividad: </td><td><select name='id_actividad'><option value='1'>Supermercado</option><option value='2'>Verduleria</option></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Localidad: </td><td><select name='id_localidad'><option value='1'>CABA</option><option value='2'>Pvcia. BA</option></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Zona: </td><td><select name='id_zona'><option value='1'>Caminando</option><option value='2'>Lanus</option></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Telefono: </td><td><input type='number' name='nro_telefono_establecimiento'></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Email: </td><td><input type='email' name='email_establecimiento'></td></tr>");

        out.println("</table><input type='hidden' name='operacion' value='save'>\n<input type='hidden' name='id_comercio' value='"+id_comercio+"'> <input type='submit'>\n</form>\n\n");
        out.println("<br><br><br>");
        out.println(HTML.getTail());

        }
    else if (operacion.equals("save")) //guarda los datos recibidos del formulario ya completo
        {
        out.println("<html><head><title>Ameca - Save Data</title>\n\n</head>" +
                    "<body>  \n\n "+
                    "<script>\n" +
                    " setTimeout(function(){\n" +
                    " window.location.href = '/ameca/comercios?operacion=detalle&id_comercio="+id_comercio+"&nro_cuit="+nro_cuit+"';\n" +
                    "  }, 2000);\n" +
                    "</script>  ");
        /*out.println("\nValores recibidos del formulario: <br>"+
                    "\n<table cellSpacing='0' cellPadding='0'>\n\t"+
                    "\n\t<tr>\n\t\t<td>Nombre Establecimiento: "+nombre_establecimiento+"</td></tr>"+
                    "\n\t<tr>\n\t\t<td>Direccion: "+direccion_establecimiento+"</td></tr>"+
                    "\n\t<tr>\n\t\t<td>Actividad: "+id_actividad+"</td></tr>"+
                    "\n\t<tr>\n\t\t<td>Localidad: "+id_localidad+"</td></tr>"+
                    "\n\t<tr>\n\t\t<td>Zona: "+id_zona+"</td></tr>" +
                    "\n\t<tr>\n\t\t<td>Telefono: "+nro_telefono_establecimiento+"</td></tr>" +
                    "\n\t<tr>\n\t\t<td>E-Mail: "+email_establecimiento+"</td></tr>" +
                    "</table>");
        */
        id_establecimiento=this.insertaEstablecmimiento(id_comercio, nombre_establecimiento, direccion_establecimiento, id_actividad, 
                                                id_zona, id_localidad, nro_telefono_establecimiento, email_establecimiento);


        out.println("INSERT: "+id_establecimiento+"<br><br>"); //hopefully id_establecimiento




        out.println("<a href='/ameca/comercios?operacion=detalle&id_comercio="+id_comercio+"&nro_cuit="+nro_cuit+"'>Ver Comercio y Establecimientos</a> <br><br>");
        //out.println("<a href='/ameca/establecimientos?operacion=new&id_comercio="+id_comercio+"&nro_cuit="+nro_cuit+"'>Nuevo Establecimiento</a>\n\n");
        out.println("</body></html>");                    
        }
    else if (operacion.equals("edit"))
        {
        out.println("<html><head><title>Ameca - Edit Comercios</title>\n\n</head>" +
                    "<body marginheight='0' marginwidth='0'>  \n\n  "+
                    "\nEditar Datos del Comercio<br><br>"+
                    "\n<table cellSpacing='2' cellPadding='2' border='1'>\n\t"+
                    "<tr>\n\t\t<td>Datos del Comercio</td>\t</tr>\n\t");

        out.println("<tr>\n\t\t<td>");

       // out.println(this.DatosComercioTable(id_comercio));

        out.println("\t</td></tr>\t\n");

        out.println("\n\n\t<tr><td></td></tr>\n\n\t<tr><td>Establecimientos del Comercio</td></tr>");

      //  out.println("\n\t<tr><td>"+this.DatosEstablecimientoTable(id_comercio)+"</td></tr>");

        out.println("\n</table>\n\n\t</body></html>");                    

        }
    else if(operacion.equals("liqui"))   // carga tributos de un establecimiento (editar mostrly)
        {
        out.println(HTML.getHead("comercios"));
        out.println("\n<br><h2>Datos para el calculo impositivo</h2> <br><br><br>"
                + "<form action='/ameca/establecimientos' name='form_periodo'>\n"
                + "<input type='text' name='periodo' value='"+periodo+"' size='7'>"
                + "<input type='hidden' name='operacion' value='liqui'>\n<input type='hidden' name='id_comercio' value='"+id_comercio+"'>\n"
                + "<input type='hidden' name='id_establecimiento' value='"+id_establecimiento+"'> \n<input type='hidden' name='nro_cuit' value='"+nro_cuit+"'> \n"
                + "</form>"+
                    "\n<table cellSpacing='0' cellPadding='0' border='1'>\n<tr>\n<td>"+
                    "<form action='/ameca/establecimientos' name='form_tributo'>\n<input type='hidden' name='operacion' value='liqui_save'>\n");
        out.println(this.getTable_carga_tributo(id_establecimiento, periodo));

        out.println("<input type='hidden' name='id_comercio' value='"+id_comercio+"'>"+
                    "\n<input type='hidden' name='id_establecimiento' value='"+id_establecimiento+"'> \n\n"+
                    "\n<input type='hidden' name='nro_cuit' value='"+nro_cuit+"'> \n\n"+
                    "\n<input type='hidden' name='periodo' value='"+periodo+"'> \n\n"+
                    "<input type='submit'>\n\n</td>");
        out.println("\n<td></td>"
                + "\n<td>\n<table>"
                + "\n\t<tr><td>Debito IVA:</td><td><input type='number' style='font-size:14px' name='debito_iva' readonly "
                +                               "onfocus='this.value=document.form_tributo.base_imponible.value*document.form_tributo.alicuota_iva.value/100;  "
                +                                   "document.form_tributo.credito_iva.value=parseFloat(document.form_tributo.compra_iva.value)*parseFloat(document.form_tributo.alicuota_iva.value)/100; "
                +                                   "document.form_tributo.ddjj_iva.value=parseFloat(document.form_tributo.debito_iva.value)-parseFloat(document.form_tributo.credito_iva.value)-parseFloat(document.form_tributo.percepcion_iva.value);'></td></tr>"
                + "\n\t<tr><td>IVA Credito:</td><td><input type='number' style='font-size:14px' name='credito_iva' readonly step='any'></td></tr>"
                + "\n\t<tr><td><b>D.D.J.J IVA</b>:</td><td><input size='10' type='text' style='font-size:22px' name='ddjj_iva' readonly step='any'></td></tr>"
                + "\n\t<tr><td><br><br></td><td></td></tr>"
                + "\n\t<tr><td>Debito IIBB:</td><td><input type='number' style='font-size:14px' name='debito_iibb' step='any' readonly "
                +                                       "onfocus='this.value=document.form_tributo.base_imponible.value*document.form_tributo.alicuota_iibb.value/100; "
                +                                       "document.form_tributo.ddjj_iibb.value=parseFloat(document.form_tributo.debito_iibb.value)-parseFloat(document.form_tributo.percepcion_iibb.value);'></td></tr>"
                + "\n\t<tr><td><b>D.D.J.J IIBB</b>:</td><td><input size='10' type='text' style='font-size:22px' name='ddjj_iibb' readonly step='any'></td></tr>"
                + "\n</table>"
                + "\n\n</td></tr></table>"
                + "\n\n</form><br><br><br>");
        out.println(HTML.getTail());

        }
    else if(operacion.equals("liqui_save"))
        {
        out.println("<html><head><title>Ameca - Guarda Actividad Impositiva</title>\n\n</head>" +
                    "<body>  \n\n  ");
        out.println("<script>\n" +
                    " setTimeout(function(){\n" +
                    " window.location.href = '/ameca/comercios?operacion=detalle&id_comercio="+id_comercio+"&nro_cuit="+nro_cuit+"';\n" +
                    "  }, 2000);\n" +
                    "</script>  ");
                  /*
                    "\nDatos para el calculo impositivo: <br>"+
                    "\n<table cellSpacing='0' cellPadding='0'>\n\t"+
                    "<tr>\n\t\t<td>Periodo (mmyyyy): </td><td>"+periodo+"</td><td></td><td></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Base Imponible: </td><td>"+base_imponible+"</td><td></td><td></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Alicuota IVA:   </td><td>"+alicuota_iva+"</td><td></td><td></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Compra (IVA): </td><td>"+compra_iva+"</td><td></td><td></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Percepcion IVA: </td><td>"+percepcion_iva+"</td><td></td><td></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Alicuota IIBB:   </td><td>"+alicuota_iibb+"</td><td></td><td></td></tr>\n\t"+
                    "<tr>\n\t\t<td>Percepcion IIBB: </td><td>"+percepcion_iibb+"</td><td></td><td></td></tr>\n\t"+
                    "<tr>\n\t\t<td>id_comercio: </td><td>"+id_comercio+"</td><td></td><td></td></tr>\n\t"+
                    "<tr>\n\t\t<td>id_establecimiento: </td><td>"+id_establecimiento+"</td><td></td><td></td></tr>\n\t");
                 */

        out.println("\n\n</table><br><br>\n\nInsert in EstablecimientosLiquiMes: "+this.insertaLiquiMes(id_establecimiento, periodo, base_imponible, alicuota_iva, alicuota_iibb, compra_iva, percepcion_iva, percepcion_iibb));
        //out.println("<br>Saldos IVA e IIBB:<br>"+Liquidaciones.LiquiEstablecimientoTable(id_establecimiento)+"<br>"); 
        out.println("<br><br><a href='/ameca/comercios?operacion=detalle&id_comercio="+id_comercio+"e&nro_cuit="+nro_cuit+"'>Ver Comercio y Establecimientos</a> <br>");
        out.println("</body>\n\n</html>");


        }               
                
   
   
 }



   
     // inserta nuevo establecimiento en tabla Establecimientos y devuelve el id_establecimiento 

    private String insertaEstablecmimiento(String id_comercio, String nombre_establecimiento, String direccion_establecimiento, 
                                              String id_actividad, String id_zona, String id_localidad, String nro_telefono_establecimiento, 
                                              String email_establecimiento) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        long resul_insert;
        
        String query="INSERT INTO dbAmeca.Establecimientos (id_comercio, nombre_establecimiento, direccion_establecimiento"
                                    + ", id_actividad, id_zona, id_localidad, nro_telefono_establecimiento, email_establecimiento) "
                                    + " VALUES ("+id_comercio+", '"+nombre_establecimiento+"', '"+direccion_establecimiento+"', "+id_actividad+", "
                                                +id_zona+", "+id_localidad+", '"+nro_telefono_establecimiento+"', '"+email_establecimiento+"')";
	String resul="";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement("INSERT INTO dbAmeca.Establecimientos (id_comercio, nombre_establecimiento, direccion_establecimiento"
                                    + ", id_actividad, id_zona, id_localidad, nro_telefono_establecimiento, email_establecimiento) "
                                    + " VALUES ("+id_comercio+", '"+nombre_establecimiento+"', '"+direccion_establecimiento+"', "+id_actividad+", "
                                                +id_zona+", "+id_localidad+", '"+nro_telefono_establecimiento+"', '"+email_establecimiento+"')");
                                               
            resul_insert = pst.executeUpdate();
            if (resul_insert>0)
                pst = con.prepareStatement("select last_insert_id()");
            else 
                return "todo mal";
            rs=pst.executeQuery();
            if (rs.next())
		resul=rs.getString(1);

            }
        catch (SQLException ex) {
               return "<br><br>ERROR: "+ex.getMessage()+"<br><br>"+query;
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                return ex.getMessage();
                }
            }
        
        return resul;  //id_comercio del nuevo registro
        }



     // inserta nuevo liquidacion mensual para un establecimiento (puede ser snapshot o final) y devuelve 1 o 0 si fue ok o no. 

    private String insertaLiquiMes(String id_establecimiento, String periodo, String base_imponible, String alicuota_iva, 
                                     String alicuota_iibb, String compra_iva, String percepcion_iva, String percepcion_iibb) 
	{
        Connection con = null;
        PreparedStatement pst = null;

        long resul_insert;
	String resul="";

        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement("INSERT INTO dbAmeca.EstablecimientosLiquiMes (id_establecimiento, periodo, base_imponible, alicuota_iva, "
                                     + "alicuota_iibb, compra_iva, percepcion_iva, percepcion_iibb) "
                                    + " VALUES ("+id_establecimiento+", '"+periodo+"', "+base_imponible+", "+alicuota_iva+", "
                                                +alicuota_iibb+", "+compra_iva+", "+percepcion_iva+", "+percepcion_iibb+")");
                                               
            resul_insert = pst.executeUpdate();
            resul = Long.toString(resul_insert);


            }
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //cantidad de registros insertados o msg error
        }

     
    

    // Recibe  el id_establecimiento y periodo, y devuelve una tabla html con los datos tributarios del periodo o vacios para que se completen. 

    private String getTable_carga_tributo(String id_establecimiento, String periodo) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

	String resul="";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement( "SELECT em.base_imponible, em.compra_iva, em.percepcion_iva, em.alicuota_iibb, em.percepcion_iibb " +
                                        "FROM Establecimientos e, EstablecimientosLiquiMes em " +
                                        "WHERE e.id_establecimiento=em.id_establecimiento " +
                                        "  AND e.id_establecimiento=" +id_establecimiento+
                                        "  AND periodo='"+periodo+"'");

                                               
            rs = pst.executeQuery();
            if (rs.next())
                resul="<table cellSpacing='0' cellPadding='0'>\n\t"+
                      "<tr>\n\t\t<td>Periodo (mmyyyy): </td><td> <= <input type='text' name='periodo' value='"+periodo+"' size='7' readonly='readonly'> =></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Base Imponible: </td><td><input type='number' name='base_imponible' value='"+rs.getString(1)+"'></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Alicuota IVA:   </td><td><input type='number' name='alicuota_iva' value='21'></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Compra (IVA): </td><td><input type='number' name='compra_iva' value='"+rs.getString(2)+"'></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Percepcion IVA: </td><td><input type='number' name='percepcion_iva' value='"+rs.getString(3)+"'></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Alicuota IIBB:   </td><td><input type='number' name='alicuota_iibb' step='any' value='"+rs.getString(4)+"'></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Percepcion IIBB: </td><td><input type='number' name='percepcion_iibb'></td></tr>\n\t" +
                      "</table>";                
            else
                resul="<table cellSpacing='0' cellPadding='0'>\n\t"+
                      "<tr>\n\t\t<td>Periodo (mmyyyy): </td><td><input type='text' name='periodo' value='"+periodo+"'></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Base Imponible: </td><td><input type='number' name='base_imponible'></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Alicuota IVA:   </td><td><input type='number' name='alicuota_iva' value='21'></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Compra (IVA): </td><td><input type='number' name='compra_iva'></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Percepcion IVA: </td><td><input type='number' name='percepcion_iva'></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Alicuota IIBB:   </td><td><input type='number' name='alicuota_iibb' value='3' step='any'></td></tr>\n\t"+
                      "<tr>\n\t\t<td>Percepcion IIBB: </td><td><input type='number' name='percepcion_iibb'></td></tr>\n\t" +
                      "</table>";
            
            
            
            }
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con datos del comercio
        }    
    

}