
package ameca;

import com.mysql.cj.util.StringUtils;

/**
 *
 * @author manu
 */
public  class HTML {
    
//public static final DecimalFormat df = new DecimalFormat("##.##.##.##.##.##.##0,00");
    
    
    
private static final Float cte_iva=0.21f;  // contstantes cargarlas en startup, y en clase HTML
private static final String prn_iva="21%";  // contstantes cargarlas en startup, y en clase HTML

private static String[] condicion_iibb={"t", "Pcia B.A. Mensual", "CABA Reg. Simplificado", "CABA Sicol", "No Inscripto", "Convenio Multilateral", "C.F. Reg. Simp. Cat. 6", "CABA DDJJ Presuntiva"};
private static final String[] condicion_iva={"t", "Monotributista", "Responsable Inscripto", "Exento", "Autonomo"};

private static final String[][] categs_autonomo={ {"t", "", "", "", ""},
                                                {"DIRECC., ADMIN., CONDUCC. DE SOCIEDADES COMERCIALES", "> a 30.000", "9.409,87", "I", "V"},
                                                {"DIRECC., ADMIN., CONDUCC. DE SOCIEDADES COMERCIALES", "> a 15.000 y < a 30.000", "6.843,53", "I", "IV"},
                                                {"DIRECC., ADMIN., CONDUCC. DE SOCIEDADES COMERCIALES", "<= a 15.000", "4.277,22", "I", "III"},
                                                {"ACTIVIDADES NO INCLUIDAS EN ID. 1", "> a 20.000", "2.994,03", "II", "II"},
                                                {"ACTIVIDADES NO INCLUIDAS EN ID. 1", "<= a 20.000", "2.138,60", "II", "I"},
                                                {"OTRAS ACTIVIDADES NO INCLUIDAS EN ID. 1", "> a 25.000", "2.994,03", "III", "II"},
                                                {"OTRAS ACTIVIDADES NO INCLUIDAS EN ID. 1", "<= a 25.000", "2.138,61", "III", "I"},
                                                {"AFILIACIONES VOLUNTARIAS", "Sin Limite", "2.138,61", "IV", "I"},
                                                {"MENORES DE 18 A 21 AÑOS", "Sin Limite", "2.138,61", "IV", "I"},
                                                {"JUBILADOS POR LEY 24241", "Sin Limite", "2.138,61", "IV", "I"},
                                                {"AMAS DE CASA QUE OPTEN POR APORTE REDUCIDO", "Sin Limite", "2.138,61", "IV", "I"} };

private static final String[][] categs_monotributo=  {
                                                {"t", "", "", ""},
                                                {"a", "Serv", "84.000", "1.007"},
                                                {"b", "Serv", "126.000", "1.126"},
                                                {"c", "Serv", "126.000", "1.126"},
                                                {"d", "Serv", "126.000", "1.126"},
                                                {"e", "Serv", "126.000", "1.126"},  //5
                                                {"f", "Serv", "126.000", "1.126"},
                                                {"g", "Serv", "126.000", "1.126"},
                                                {"h", "Serv", "126.000", "1.126"},
                                                {"i", "Serv", "0", "0"},   //9
                                                {"j", "Serv", "0", "0"},           
                                                {"k", "Serv", "0", "0"},    
                                                {"A", "Muebles", "0", "1.007"},     //12
                                                {"B", "Muebles", "0", "1.126"},
                                                {"C", "Muebles", "0", "1.126"},
                                                {"D", "Muebles", "0", "1.126"},     //15
                                                {"E", "Muebles", "0", "1.126"},
                                                {"F", "Muebles", "0", "1.126"},
                                                {"G", "Muebles", "0", "1.126"},     //18
                                                {"H", "Muebles", "0", "1.126"},
                                                {"I", "Muebles", "0", "5.840"},
                                                {"J", "Muebles", "0", "6.707"},
                                                {"K", "Muebles", "0", "7.581"}};    //22
     
    
private static final String head1="<!DOCTYPE html>\n" +
                    "<html>\n" +
                    "<head>\n<title>Ameca</title>\n" +
                    "<meta name='viewport' content='width=device-width, initial-scale=1'>\n" +
                    "<link rel='shortcut icon' href='/ameca/imgs/chrome.ico' type='image/x-icon'/>\n" +
                    "<link href='/ameca/Styles/ameca.css'  type='text/css' rel='stylesheet' />\n" +
                    "</head>\n" +
                    "\n\n<body bgcolor='black' leftmargin='0' rightmargin='0' topmargin='5'>\n" +
                    "\n<table width='100%' cellspacing='0' cellpadding='0' border='0'  bgcolor='#2C383B'>\n" + // color de navbar
                    "\n<tr>\n" +
                    " <td height='150px' bgcolor='black' colspan='6'>\n" +
                    "  <img src='/ameca/imgs/ameca2.png' style='width:1220px;height:150px;'>\n" +
                    " </td>\n" +
                    " <td height='150px' bgcolor='black'>\n" +
                    "  <img src='/ameca/imgs/ameca2_crop.png' style='width:100%;height:150px;'>\n" +
                    " </td>\n" +
                    "</tr>\n" +
                    "\n<tr>\n\n\n";

                    // aca va la categoria Inicio que se activa o no segun el paramentro de funcion getHead

private static final String head2= "<div class='navbar'>\n" +
                    "  <a href='/ameca/inicio'>Inicio</a>\n" +
                    "</div>\n" +
                    "</td>\n" +
                    "<td width='140px'></td>\n" +
                    "<td width='202px'>\n" +
                    "  <div class=\"dropdown\">\n" ;
                    //aca va comercios
private static final String head3= "      </button>\n" +
                    "    <div class='dropdown-content1'>\n" +
                    "      <a href='/ameca/comercios?operacion=new'>Nuevo</a>\n" +
                    "      <a href='/ameca/comercios?operacion=find'>Administrar</a>\n" +
                    "    </div>\n" +
                    "  </div> \n" +
                    "</td>\n" +
                    "<td width='222px'>\n" +
                    "  <div class=\"dropdown\">\n" ;
                    // aca va categoria Liquidaciones
private static final String head4= "      </button>\n" +
                    "    <div class=\"dropdown-content2\">\n" +
                    "      <a href='/ameca/liquidaciones?operacion=ver_mv&periodo=201908'>IVA Mensual</a>\n" +
                    "      <a href='/ameca/liquidaciones?operacion=ver_mb&periodo=201908'>IIBB Mensual</a>\n" +
                    "      <a href='/ameca/liquidaciones?operacion=ver_m&periodo=201908'>Completa</a>\n" +
                    "    </div>\n" +
                    "  </div> \n" +
                    "</td>\n" +
                    "<td width='222px'>\n" +
                    "  <div class=\"navbar\">\n" +
                    "     <a href=\"#\">REPORTES </a>\n" +
                    "  </div> \n" +
                    "</td>\n" +
                    "<td width='340px' align='right'><form action='/ameca/comercios'>\n <input type='hidden' name='operacion' value='find'>\n" +
                    "<div><img src='/ameca/imgs/search12.png' style='width:21px;height:21px;' ondblclick='document.forms[0].submit();'>\n" +
                    "<input type='text' name='cuit_calle' class='search'>&nbsp;\n" +
                    "</div>\n" +
                    "</form></td>\n" +
                    "<td></td>\n" +  //added movable
                    "</tr>\n"+
                    "\n<tr><td class='hole' colspan='7'>\n\n\n"+  // color de fondo
                    "<table>\n<tr><td>&nbsp;&nbsp;&nbsp;</td>  \n  <td>\n";   // tabla con margenes


private static final String tail="</td><td>&nbsp;&nbsp;&nbsp;</td></tr></table>"+   // cierro tabla con margenes
                                "\n</td></tr>\n\n"+
                                "<tr><td height='10px' bgcolor='#FCFCFC' colspan='7'>\n" +
                               "\n</td></tr>\n\n<tr><td height='99px' bgcolor='#45543D' colspan='7'></td></tr>\n" +
                                "\n\n</table>\n" +    // cierro tabla principal
                                "</body>\n" +
                                "</html>";

private static final String dropZonas= "<select name='zona'><option value=''>Todas</option><option value='2'>ZONAS VARIAS</option><option value='3'>LANUS</option>"
                                    + "<option value='5'>SAAVEDRA</option><option value='6'>MICROCENTRO</option> <option value='7'>SAN JUSTO</option>"
                                    + "<option value='8'>CAMINANDO</option><option value='4'>SAN MARTIN</option> <option value='9'>MATADEROS</option>"
                                    + "<option value='10'>BELGRANO</option>  \n</select>\n\t";





public static String getHead(String categ)
    {
     String resul=head1;
     if (categ.equals("inicio"))
        resul +="<td bgcolor='#45543D' width='85px'>\n";
     else
        resul +="<td width='85px'>\n";
     resul +=head2;
     if (categ.equals("comercios"))
        resul +="    <button class=\"dropbtn_s\">Comercios \n";
     else
        resul +="    <button class=\"dropbtn\">Comercios \n";
     resul +=head3;
     if (categ.equals("liquidaciones"))
        resul +="    <button class=\"dropbtn_s\">Liquidaciones \n";
     else
        resul +="    <button class=\"dropbtn\">Liquidaciones \n";
     resul +=head4;
     
     
     return resul;

    }



public static String getTail()
    { return tail; }

public static Float getIVA()
    { return cte_iva; }

public static String getPeriodo()
    { return "201909"; }

public static String getProvincia(String id_localidad)
    { return "--"; }


public static String getDropZonas()
    { return dropZonas; }


public static String getCondicionIIBB(String id_cond_iibb)
    { 
        if (condicion_iibb [0].equals("f"))
            condicion_iibb [0]="t";  // aca hay que llenar de vuelta consultando la tabla CondicionesIIBB [hubo algun cambio].

        if (StringUtils.isStrictlyNumeric(id_cond_iibb))
            return condicion_iibb [Integer.parseInt(id_cond_iibb)];
            
        return ""; 
    }

public static String getCondicionIVA(String id_cond_iva)
    { 
        if (condicion_iva [0].equals("f"))
            condicion_iva [0]="t";  // aca hay que llenar de vuelta consultando la tabla CondicionesIVA [hubo algun cambio].

        if (StringUtils.isStrictlyNumeric(id_cond_iva))
            return condicion_iva [Integer.parseInt(id_cond_iva)];
            
        return ""; 
    }


public static String getCategoriaMonotributo(String id_cond_iva)
    { 
        if (categs_monotributo [0][0].equals("f"))
            categs_monotributo [0][0]="t";  // aca hay que llenar de vuelta consultando la tabla CondicionesIVA [hubo algun cambio].

        if (StringUtils.isStrictlyNumeric(id_cond_iva))
            return "Categoria Monotributo: "+categs_monotributo [Integer.parseInt(id_cond_iva)][0]+
                    "<br> Categoria Adicional: "+categs_monotributo [Integer.parseInt(id_cond_iva)][1]+
                    "<br> Tope Categoria: "+categs_monotributo [Integer.parseInt(id_cond_iva)][2]+
                    "<br> Monto Mensual: "+categs_monotributo [Integer.parseInt(id_cond_iva)][3];
            
        return ""; 
    }


public static String getCategoriaAutonomo(String id_cond_iva)
    { 
        if (categs_autonomo [0][0].equals("f"))
            categs_autonomo [0][0]="t";  // aca hay que llenar de vuelta consultando la tabla CondicionesIVA [hubo algun cambio].

        if (StringUtils.isStrictlyNumeric(id_cond_iva))
            return "Categoria Autonomo: "+categs_autonomo [Integer.parseInt(id_cond_iva)][0]+
                    "<br> Tope Categoria: "+categs_autonomo [Integer.parseInt(id_cond_iva)][1]+
                    "<br> Monto Mensual: "+categs_autonomo [Integer.parseInt(id_cond_iva)][2]+
                    "<br>Tabla: "+categs_autonomo [Integer.parseInt(id_cond_iva)][3]+". Categ: "+categs_autonomo [Integer.parseInt(id_cond_iva)][4];
            
        return ""; 
    }


}
