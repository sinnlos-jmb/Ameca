package ameca;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;




/**
 *
 * @author manu
 */
public class Inicio extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println(HTML.getHead("inicio")); //devuelve la mitad de la tabla con <tr>s hasta las catgegs del menu (inicio, comercios, liquidaciones, facturacion).
        out.println("<table><tr><td height='266px'></td></tr></table>"); // aca va el contenido de la pagina
        out.println(HTML.getTail());
    }
}