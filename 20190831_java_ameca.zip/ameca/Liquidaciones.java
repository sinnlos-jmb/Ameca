/*
 * Class Liquidaciones.
 * 
 * 
 */
package ameca;

/**
 *
 * @author manu
 */

import com.mysql.cj.util.StringUtils;
import java.io.IOException;
import java.io.PrintWriter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import manu.utils.*;

public class Liquidaciones extends HttpServlet        
{  
    
        String base_imponible="", debito_iva="", debito_iibb="", venta_total="", compra_iva="", credito_iva="", compra_total="", percepcion_iva="", 
                percepcion_iibb="", saldo_ddjj_iva="", saldo_ddjj_iibb="", alicuota_iva="", alicuota_iibb="";
    
    
    static final Float cte_iva=HTML.getIVA();  // contstantes cargarlas en startup, y en clase HTML
    
            
            
    public void doGet(HttpServletRequest request, HttpServletResponse response)
	  throws ServletException, IOException

   {  //	htmls.logger.fine("homeOsoc. Carga servlet\n--");
   
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String operacion  = request.getParameter ("operacion") != null ?  request.getParameter ("operacion") : "nuevo" ;
        String do_masive  = request.getParameter ("do_masive") != null ?  request.getParameter ("do_masive") : "0" ; // 1 para insert masivo de establecimientos en un periodo que estaba vacio

        String id_comercio  = request.getParameter ("id_comercio") != null ?  request.getParameter ("id_comercio") : "0" ;
        String nro_cuit  = request.getParameter ("nro_cuit") != null ?  request.getParameter ("nro_cuit") : "0" ;
        String id_establecimiento  = request.getParameter ("id_establecimiento") != null ?  request.getParameter ("id_establecimiento") : "0" ;
        String nombre_establecimiento  = request.getParameter ("nombre_establecimiento") != null ?  request.getParameter ("nombre_establecimiento") : "" ;
        String zona  = request.getParameter ("zona") != null ?  request.getParameter ("zona") : "" ;

        String periodo  = request.getParameter ("periodo") != null ?  request.getParameter ("periodo") : "201908" ;
        if (!StringUtils.isStrictlyNumeric(periodo))
            periodo="201908";



        base_imponible  = request.getParameter ("base_imponible") != null ?  request.getParameter ("base_imponible") : "0" ;
        alicuota_iva  = request.getParameter ("alicuota_iva") != null ?  request.getParameter ("alicuota_iva") : "21" ;
        alicuota_iibb  = request.getParameter ("alicuota_iibb") != null ?  request.getParameter ("alicuota_iibb") : "3" ;
        compra_iva  = request.getParameter ("compra_iva") != null ?  request.getParameter ("compra_iva") : "0" ;
        percepcion_iva  = request.getParameter ("percepcion_iva") != null ?  request.getParameter ("percepcion_iva") : "0" ;
        percepcion_iibb  = request.getParameter ("percepcion_iibb") != null ?  request.getParameter ("percepcion_iibb") : "0" ;



        if(operacion.equals("ver_e"))  //ver establecimiento, es una sola ficha o agregar de todos los periodos (lqui historica).
            {
            out.println(HTML.getHead("liquidaciones"));
            out.println("\n<br><h1>Saldos DDJJ "+nombre_establecimiento+"</h1><br>"+
                        "\n<form action='/ameca/liquidaciones'>"+
                        "Periodo: <input type='number' name='periodo' value='"+periodo+"' min='201900' max='204311'>\n\t"+
                        "<input type='hidden' name='operacion' value='ver_e'>\n"+
                        "<input type='hidden' name='id_comercio' value='"+id_comercio+"'>\n"+
                        "<input type='hidden' name='nro_cuit' value='"+nro_cuit+"'>\n"+
                        "<input type='hidden' name='id_establecimiento' value='"+id_establecimiento+"'>\n"+
                        "<input type='hidden' name='nombre_establecimiento' value='"+nombre_establecimiento+"'>\n"+
                        "<input type='submit'></form>");

            out.println("<br><br>\n"+this.LiquiEstablecimientoTable(id_establecimiento, periodo));

            out.println("<br><br><a href='/ameca/comercios?operacion=detalle&id_comercio="+id_comercio+"&nro_cuit="+nro_cuit+"'>Volver a Comercio</a> <br>\n\n");

            out.println(HTML.getTail());

            }
        else if (operacion.equals("ver_c"))  //ver comercio
            {
            out.println(HTML.getHead("liquidaciones"));
            out.println("\n<h2>Saldos DDJJ Comercio: "+nro_cuit+"</h2><br>"+
                        "\n<form action='/ameca/liquidaciones'>"+
                        "Periodo: <input type='number' name='periodo' value='"+periodo+"' min='201900' max='20431111'>\n\t"+
                        "<input type='hidden' name='operacion' value='ver_c'>\n"+
                        "<input type='hidden' name='id_comercio' value='"+id_comercio+"'>\n"+
                        "<input type='hidden' name='nro_cuit' value'"+nro_cuit+"'>"+
                        "<input type='hidden' name='id_establecimiento' value='"+id_establecimiento+"'>\n"+
                        "<input type='submit'></form>");

            out.println("<br><br>\n"+this.LiquiComercioTable(id_comercio, periodo));

            out.println("<br><br><a href='/ameca/comercios?operacion=detalle&id_comercio="+id_comercio+"&nro_cuit="+nro_cuit+"'>Volver a Comercio</a> <br>");

            out.println("\n\n"+HTML.getTail());

            }
        else if (operacion.equals("ver_m")) //ver liquidaciones masiva total (iva e iibb)
            {
            out.println(HTML.getHead("liquidaciones"));
            out.println("<br><h2>Liquidaci&oacute;n Mensual General (IVA e IIBB)</h2><br>"+
                        "\n<form action='/ameca/liquidaciones'>"+
                        "Periodo: <input type='number' name='periodo' value='"+periodo+"' min='201900' max='204311'>\n\t"+
                        "<input type='hidden' name='operacion' value='ver_m'>\n"+
                        "<input type='submit'></form>");

            out.println("<br><br>\n"+this.LiquiMesTable(periodo));
            out.println("\n\n<br><br><a href='/ameca/inicio'>Inicio</a><br>\n\n");

            out.println(HTML.getTail());

            }
        else if (operacion.equals("ver_mv")) //ver liquidaciones masiva iva
            {
            out.println(HTML.getHead("liquidaciones"));
            out.println("\n<br><h2>Liquidaci&oacute;n I.V.A. Mensual</h2><br>"+
                        "\n<form name='form_periodo' action='/ameca/liquidaciones'>\n"+
                        "Periodo: <input type='number' name='periodo' value='"+periodo+"' min='201900' max='204312'>\n\t"+
                        "<input type='hidden' name='operacion' value='ver_mv'>\n"+
                        "<input type='submit'>\n");

            if( (!base_imponible.equals("0") && !base_imponible.equals("+0")) || (!percepcion_iva.equals("0") && !percepcion_iva.equals("+0")) || (!compra_iva.equals("0") && !compra_iva.equals("+0")) )
                out.println("<br><br>registros modificados: \n"+this.LiquiMesIVA_update(periodo, base_imponible, percepcion_iva, compra_iva));

            if(do_masive.equals("1"))
                out.println("<br><br>registros agregados: \n"+this.LiquiMes_masive(periodo));

            out.println("<br><br>\n"+this.LiquiMesIVATable(periodo));

            out.println("\n</form>\n\n<br><br><a href='/ameca/inicio'>Inicio</a><br>");
            out.println(HTML.getTail());


            }
        else if (operacion.equals("ver_mb")) //liquidaciones masiva iibb
            {
            out.println(HTML.getHead("liquidaciones"));
            out.println("\n<br><h2>Liquidacion I.I.B.B. Mensual</h2><br>"+
                        "\n<form action='/ameca/liquidaciones'>"+
                        "Periodo: <input type='number' name='periodo' value='"+periodo+"' min='201900' max='204312'>\n\t"+
                        "Zona: "+HTML.getDropZonas()+
                        "<input type='hidden' name='operacion' value='ver_mb'>\n"+
                        "<input type='submit'>");

            if( (!base_imponible.equals("0") && !base_imponible.equals("+0")) || (!percepcion_iibb.equals("0") && !percepcion_iibb.equals("+0")))
                out.println("<br><br>registros modificados: \n"+this.LiquiMesIIBB_update(periodo, base_imponible, percepcion_iibb));

            if(do_masive.equals("1"))
                out.println("<br><br>registros agregados: \n"+this.LiquiMes_masive(periodo));

            out.println("<br><br>\n"+this.LiquiMesIIBBTable(periodo, zona));

            out.println("\n</form>\n\n<br><br><a href='/ameca/inicio'>Inicio</a>\n\n");

            out.println(HTML.getTail());

            }
        else if (operacion.equals("edit"))
            {
            out.println("<html><head><title>Ameca - Edit Comercios</title>\n\n</head>" +
                        "<body marginheight='0' marginwidth='0'>  \n\n  "+
                        "\nEditar Datos del Comercio<br><br>"+
                        "\n<table cellSpacing='2' cellPadding='2' border='1'>\n\t"+
                        "<tr>\n\t\t<td>Datos del Comercio</td>\t</tr>\n\t");

            out.println("\n\n\t</table>");

            }
        else if(operacion.equals("liqui"))
            {
            out.println("<html><head><title>Ameca - Carga Tributos</title>\n\n</head>" +
                        "<body marginheight='0' marginwidth='0'>  \n\n  "+
                        "\nDatos para el calculo impositivo: <br>"+
                        "\n<form action=/ameca/establecimientos><table cellSpacing='0' cellPadding='0'>\n\t"+
                        "<tr>\n\t\t<td>Periodo (mmyyyy): </td><td><input type=\"text\" name=\"periodo\">\n<input type=\"hidden\" name=\"operacion\" value=\"liqui_save\">\n<input type=\"hidden\" name=\"id_comercio\" value=\""+id_comercio+"\">"+
                        "\n<input type=\"hidden\" name=\"id_establecimiento\" value=\""+id_establecimiento+"\"> \n<input type=\"submit\">\n</form></body>\n\n</html>");


            }
        else if(operacion.equals("liqui_save"))
            {
            out.println("<html><head><title>Ameca - Guarda Actividad Impositiva</title>\n\n</head>" +
                        "<body marginheight='0' marginwidth='0'>  \n\n  "+
                        "\nDatos para el calculo impositivo: <br>"+
                        "\n<table cellSpacing='0' cellPadding='0'>\n\t"+
                        "<tr>\n\t\t<td>Periodo (mmyyyy): </td><td>"+periodo+"</td><td></td><td></td></tr>\n\t"+
                        "<tr>\n\t\t<td>Base Imponible: </td><td>"+base_imponible+"</td><td></td><td></td></tr>\n\t"+
                        "<tr>\n\t\t<td>Alicuota IVA:   </td><td>"+alicuota_iva+"</td><td></td><td></td></tr>\n\t"+
                        "<tr>\n\t\t<td>Compra (IVA): </td><td>"+compra_iva+"</td><td></td><td></td></tr>\n\t"+
                        "<tr>\n\t\t<td>Percepcion IVA: </td><td>"+percepcion_iva+"</td><td></td><td></td></tr>\n\t"+
                        "<tr>\n\t\t<td>Alicuota IIBB:   </td><td>"+alicuota_iibb+"</td><td></td><td></td></tr>\n\t"+
                        "<tr>\n\t\t<td>Percepcion IIBB: </td><td>"+percepcion_iibb+"</td><td></td><td></td></tr>\n\t"+
                        "<tr>\n\t\t<td>id_comercio: </td><td>"+id_comercio+"</td><td></td><td></td></tr>\n\t"+
                        "<tr>\n\t\t<td>id_establecimiento: </td><td>"+id_establecimiento+"</td><td></td><td></td></tr>\n\t");
            out.println("<br><br><a href='/ameca/comercios?operacion=detalle&id_comercio="+id_comercio+"&nro_cuit="+nro_cuit+"'>Ver Comercio y Establecimientos</a> <br>");
            out.println("</body>\n\n</html>");


            }               
                
   
 }



    
    
    
   
// Recibe  el id_comercio y devuelve una tabla de los saldos de sus establecimientos 

    public static String LiquiEstablecimientoTable(String id_establecimiento) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        String base_imponible, debito_iva, debito_iibb, venta_total, compra_iva, credito_iva, compra_total, percepcion_iva, 
                percepcion_iibb, saldo_ddjj_iva, saldo_ddjj_iibb, alicuota_iva, alicuota_iibb;
	String resul="";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement( "SELECT FORMAT (base_imponible, 2, 'de_DE'), " +
                                                "@debitoF_iva := (base_imponible*alicuota_iva/100), " +   //debito fiscal IVA
                                                "@debitoF_iibb := (base_imponible*alicuota_iibb/100), " +  // 3.  debito fiscal IIBB
                                                "FORMAT (base_imponible+@debitoF_iva, 2, 'de_DE'), " + //venta total
                                                "FORMAT (compra_iva, 2, 'de_DE'), " +
                                                "@iva_credito := (compra_iva*alicuota_iva/100), " +
                                                "FORMAT (compra_iva+@iva_credito, 2, 'de_DE'), " + // 7.  compra total
                                                "percepcion_iva, percepcion_iibb, " +
                                                "FORMAT (@debitoF_iva-@iva_credito-percepcion_iva, 2, 'de_DE'), " +  // 10. SALDO IVA
                                                "FORMAT (@debitoF_iibb-percepcion_iibb, 2, 'de_DE'), "+   // SALDO IIBB
                                                "alicuota_iva, alicuota_iibb, "+ 
                                                "FORMAT (@debitoF_iva, 2, 'de_DE'), "+     // 14.  debito_iva
                                                "FORMAT (@debitoF_iibb, 2, 'de_DE'), "+ 
                                                "FORMAT (@iva_credito, 2, 'de_DE') "+    // 16.  credito_iva
                                       " FROM dbAmeca.EstablecimientosLiquiMes " +
                                       " WHERE dbAmeca.EstablecimientosLiquiMes.id_establecimiento ="+id_establecimiento);
            
            resul="<table class='bicolor'>\n\t<tr>\n\t\t<th>Base Imponible</th> <th>Alic. IVA</th> <th>Debito IVA</th> <th>Venta Total</th> <th>Compra IVA</th> "+
                    "<th>Credito IVA</th> <th>Compra Total</th> <th>Percepcion IVA</th> <th>SALDO D.D.J.J. IVA</th> \n"+
                    "<th>Alic. IIBB</th> <th>Percepcion IIBB</th> <th>Debito IIBB</th> <th>SALDO D.D.J.J. IIBB</th> \n</tr>\n\n";

            rs = pst.executeQuery();
            while (rs.next())
                {
                 base_imponible=rs.getString(1);
                 alicuota_iva=rs.getString(12);
                 alicuota_iibb=rs.getString(13);
                 debito_iva=rs.getString(14);
                 debito_iibb=rs.getString(15);
                 venta_total=rs.getString(4);
                 compra_iva=rs.getString(5);
                 credito_iva=rs.getString(16);
                 compra_total=rs.getString(7);
                 percepcion_iva=rs.getString(8);
                 percepcion_iibb=rs.getString(9);
                 saldo_ddjj_iva=rs.getString(10);
                 saldo_ddjj_iibb=rs.getString(11);

                resul+="\n\t<tr> <td>"+base_imponible+"</td> <td>"+alicuota_iva+"</td> <td>"+debito_iva+"</td> <td>"+venta_total+"</td> <td>"+compra_iva+"</td> "+
                    "<td>"+credito_iva+"</td> <td>"+compra_total+"</td> <td>"+percepcion_iva+"</td> <td>"+saldo_ddjj_iva+"</td> " +
                    "<td>"+alicuota_iibb+"</td> <td>"+percepcion_iibb+"</td> <td>"+debito_iibb+"</td> <td>"+saldo_ddjj_iibb+"</td>\n\t</tr>";
                }
            resul+="\n\t</table>\n";


            
            }
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con datos de liquidacion del establecimiento
        }



// Recibe  el id_establecimiento + periodo y devuelve una tabla de sus saldos DDJJ (IVA e IIBB) para el periodo 

    private String LiquiEstablecimientoTable(String id_establecimiento, String periodo) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

	String resul="";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement( "SELECT FORMAT (base_imponible, 2, 'de_DE'), " +
                                                "@debitoF_iva := (base_imponible*alicuota_iva/100), " +   // 2. debito fiscal IVA
                                                "@debitoF_iibb := (base_imponible*alicuota_iibb/100), " +  // debito fiscal IIBB
                                                "FORMAT (base_imponible+@debitoF_iva, 2, 'de_DE'), " + //venta total
                                                "FORMAT (compra_iva, 2, 'de_DE'), " +      // 5. compra iva
                                                "@iva_credito := (compra_iva*alicuota_iva/100), " +
                                                "FORMAT (compra_iva+@iva_credito, 2, 'de_DE'), " + //compra total
                                                "percepcion_iva, percepcion_iibb, " +
                                                "FORMAT (@debitoF_iva-@iva_credito-percepcion_iva, 2, 'de_DE'), " +  // 10. SALDO DDJJ IVA
                                                "FORMAT (@debitoF_iibb-percepcion_iibb, 2, 'de_DE'), "+   // SALDO DDJJ IIBB
                                                "alicuota_iva, alicuota_iibb, "+ 
                                                "FORMAT (@debitoF_iva, 2, 'de_DE'), "+  // 14. debito iva formateada
                                                "FORMAT (@debitoF_iibb, 2, 'de_DE'), "+ 
                                                "FORMAT (@iva_credito, 2, 'de_DE') "+    // 16.  credito_iva
                                       " FROM EstablecimientosLiquiMes " +
                                       " WHERE periodo ='"+periodo+"' AND id_establecimiento ="+id_establecimiento);
            

            resul="<table class='bicolor'>\n\t<tr>\n\t\t<th>Base Imponible</th> <th>Alic. IVA</th> <th>Debito IVA</th> <th>Venta Total</th> <th>Compra IVA</th> "+
                    "<th>Credito IVA</th> <th>Compra Total</th> <th>Percepcion IVA</th> <th>SALDO DDJJ. IVA</th> "+
                    "<th>Alic. IIBB</th> <th>Debito IIBB</th> <th>Percepcion IIBB</th> <th>SALDO DDJJ. IIBB</th> </tr>";

            rs = pst.executeQuery();
            while (rs.next())
                {
                 base_imponible=rs.getString(1);
                 alicuota_iva=rs.getString(12);
                 alicuota_iibb=rs.getString(13);
                 debito_iva=rs.getString(14);
                 debito_iibb=rs.getString(15);
                 venta_total=rs.getString(4);
                 compra_iva=rs.getString(5);
                 credito_iva=rs.getString(16);
                 compra_total=rs.getString(7);
                 percepcion_iva=rs.getString(8);
                 percepcion_iibb=rs.getString(9);
                 saldo_ddjj_iva=rs.getString(10);
                 saldo_ddjj_iibb=rs.getString(11);

                resul+="\n\t<tr><td>"+base_imponible+"</td> <td>"+alicuota_iva+"</td> <td>"+debito_iva+"</td> <td>"+venta_total+"</td> <td>"+compra_iva+"</td> "+
                    "<td>"+credito_iva+"</td> <td>"+compra_total+"</td> <td>"+percepcion_iva+"</td> <td>"+saldo_ddjj_iva+"</td> " +
                    "<td>"+alicuota_iibb+"</td> <td>"+debito_iibb+"</td> <td>"+percepcion_iibb+"</td> <td>"+saldo_ddjj_iibb+"</td>\n\t</tr>";
                }
            resul+="\n\t</table>\n";


            
            }
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con datos de liquidacion del establecimiento
        }
    

    
    
    
    
// Recibe  el id_comercio + periodo y devuelve una tabla de sus saldos DDJJ (IVA e IIBB) para el periodo 

    private String LiquiComercioTable(String id_comercio, String periodo) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        String resul, nombre_establecimiento;
         
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement( "SELECT FORMAT (elm.base_imponible, 2, 'de_DE'), " +
                                                "@debitoF_iva := (elm.base_imponible*elm.alicuota_iva/100), " +   //debito fiscal IVA
                                                "@debitoF_iibb := (elm.base_imponible*elm.alicuota_iibb/100), " +  // 3. debito fiscal IIBB
                                                "FORMAT (elm.base_imponible+@debitoF_iva, 2, 'de_DE'), " + //venta total
                                                "FORMAT (elm.compra_iva, 2, 'de_DE'), " +
                                                "@iva_credito := (elm.compra_iva*alicuota_iva/100), " +
                                                "FORMAT (elm.compra_iva+@iva_credito, 2, 'de_DE'), " + // 7. compra total
                                                "elm.percepcion_iva, elm.percepcion_iibb, " +
                                                "FORMAT (@debitoF_iva-@iva_credito-elm.percepcion_iva, 2, 'de_DE'), " +  // SALDO DDJJ IVA
                                                "FORMAT (@debitoF_iibb-elm.percepcion_iibb, 2, 'de_DE'), " +  //11.  SALDO DDJJ IIBB
                                                "elm.alicuota_iva, elm.alicuota_iibb, "+ 
                                                "FORMAT (@debitoF_iva, 2, 'de_DE'), "+ 
                                                "FORMAT (@debitoF_iibb, 2, 'de_DE'), "+  // 15.debito fiscal iibb
                                                "e.nombre_establecimiento, "+ 
                                                "FORMAT (@iva_credito, 2, 'de_DE') " +   //  17. credito iva
                                       " FROM EstablecimientosLiquiMes elm, Establecimientos e " +
                                       " WHERE elm.periodo ='"+periodo+"' AND elm.id_establecimiento = e.id_establecimiento AND e.id_comercio="+id_comercio);
            

            resul="<table class='bicolor'>\n\t<tr>\n\t\t <th>Nombre Establecimiento</th> <th>Base Imponible</th> <th>Alic. IVA</th> <th>Debito IVA</th> <th>Venta Total</th> <th>Compra IVA</th> "+
                    "<th>Credito IVA</th> <th>Compra Total</th> <th>Percepcion IVA</th> <th>SALDO D.D.J.J. IVA</th> "+
                    "<th>Alic. IIBB</th> <th>Debito IIBB</th> <th>Percepcion IIBB</th> <th>SALDO D.D.J.J. IIBB</th> </tr>";

            rs = pst.executeQuery();
            while (rs.next())
                {
                 base_imponible=rs.getString(1);
                 alicuota_iva=rs.getString(12);
                 alicuota_iibb=rs.getString(13);
                 debito_iva=rs.getString(14);
                 debito_iibb=rs.getString(15);
                 venta_total=rs.getString(4);
                 compra_iva=rs.getString(5);
                 credito_iva=rs.getString(17);
                 compra_total=rs.getString(7);
                 percepcion_iva=rs.getString(8);
                 percepcion_iibb=rs.getString(9);
                 saldo_ddjj_iva=rs.getString(10);
                 saldo_ddjj_iibb=rs.getString(11);
                 nombre_establecimiento=rs.getString(16);

                resul+="\n\t<tr><td>"+nombre_establecimiento+"</td> <td>"+base_imponible+"</td> <td>"+alicuota_iva+"</td> <td>"+debito_iva+"</td> <td>"+venta_total+"</td> <td>"+compra_iva+"</td> "+
                    "<td>"+credito_iva+"</td> <td>"+compra_total+"</td> <td>"+percepcion_iva+"</td> <td>"+saldo_ddjj_iva+"</td> " +
                    "<td>"+alicuota_iibb+"</td> <td>"+debito_iibb+"</td> <td>"+percepcion_iibb+"</td> <td>"+saldo_ddjj_iibb+"</td>\n\t</tr>";
                }
            resul+="\n\t</table>";


            
            }
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con datos de liquidacion del establecimiento
        }
    
    
    
    


// Recibe  el periodo y devuelve una tabla con los saldos DDJJ (IVA e IIBB) de los comercios para el periodo 

    private String LiquiMesTable(String periodo) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        Boolean empty=true;
	String resul, row_span;
        Float cmrc_bi=0.0f, cmrc_compra=0.0f, cmrc_percepcion_iva=0.0f, cmrc_percepcion_iibb=0.0f, cmrc_alicuota_iibb=0.0f;
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement( "SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, " +
                                                "em.base_imponible, " + //4  base imponible
                                                "em.compra_iva, " +  // 5. comopra
                                                "em.percepcion_iva, " +    // 6. percepcion IVA
                                                "em.percepcion_iibb, " +   //  7.  percepcion IIBB
                                                "em.alicuota_iibb, " +  //   8. alicuota IIBB
                                                "e.id_zona, " + //  9.  zona
                                                "(SELECT COUNT(*) \n" +
                                                " FROM EstablecimientosLiquiMes eem, Establecimientos ee \n" +
                                                " WHERE periodo='"+periodo+"' \n" +
                                                "   AND eem.id_establecimiento=ee.id_establecimiento \n" +
                                                "   AND ee.id_comercio=e.id_comercio)" +  // 10.  COUNT
                                       " FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em " +
                                       " WHERE c.id_comercio = e.id_comercio " + 
                                           " AND e.id_establecimiento=em.id_establecimiento " +
                                           " AND em.periodo ='"+periodo+"'"+ 
                                       " ORDER BY c.nro_cuit, e.id_zona");  
            

            resul="\n\n<table class='grupos' width='1800px'>\n\t<tr>\n\t\t"+
                    "<th>CUIT</th> <th>Nombre</th> <th>Direccion Establecimiento</th> \n"+
                    "<th>Base Imponible</th> <th>Alic. IVA</th> <th>Debito IVA</th> <th>Venta Total</th> <th>Compra IVA</th> \n"+
                    "<th>Credito IVA</th> <th>Compra Total</th> <th>Percepcion IVA</th> <th>SALDO D.D.J.J. IVA</th> \n"+
                    "<th>Alic. IIBB</th> <th>Debito IIBB</th> <th>Percepcion IIBB</th> <th>SALDO D.D.J.J. IIBB</th> <th>Observaciones</th> \n</tr>\n\n";

            rs = pst.executeQuery();
            int i=-1;

            while (rs.next())
                {
                empty=false;

                if (i<0)
                    {
                     row_span=rs.getString(10);
                     i=Integer.parseInt(row_span);

                    cmrc_bi=rs.getFloat(4);
                    cmrc_compra=rs.getFloat(5);
                    cmrc_percepcion_iva=rs.getFloat(6);
                    cmrc_percepcion_iibb=rs.getFloat(7);
                   // cmrc_alicuota_iibb  = rs.getString(8).equals("3") ?  3.0f : 3.5f ;
                    cmrc_alicuota_iibb  = rs.getFloat(8) ;

                    


                     if (i==1)  // unico establecimiento del comercio
                        {
                         resul+="\n\t<tr class='t1'> <td>"+rs.getString(1)+"</td> <td>"+rs.getString(2)+"</td> <td>"+rs.getString(3)+", "+rs.getString(9)+"</td> "+
                                "\n\t<td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi)+"</td> <td>21</td> "+
                                "<td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cte_iva)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cte_iva+cmrc_bi)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra)+"</td> "+
                                "<td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra*cte_iva)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra*cte_iva+cmrc_compra)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion_iva)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cte_iva-cmrc_compra*cte_iva-cmrc_percepcion_iva)+"</td> " +
                                "<td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_alicuota_iibb)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alicuota_iibb/100)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion_iibb)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alicuota_iibb/100-cmrc_percepcion_iibb)+"</td> " +
                                " \n\t <td></td>  </tr> \n ";
                         i=-1;
                        }

                      else
                        {
                         resul+="\n\t<tr> <td rowspan='"+row_span+"'>"+rs.getString(1)+"</td> <td rowspan='"+row_span+"'>"+rs.getString(2)+"</td> <td td class='t2'>"+rs.getString(3)+", "+rs.getString(9)+"</td> "+
                                "\n\t<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi)+"</td> <td td class='t2'>21</td> "+
                                "<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cte_iva)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cte_iva+cmrc_bi)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra)+"</td> "+
                                "<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra*cte_iva)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra*cte_iva+cmrc_compra)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion_iva)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cte_iva-cmrc_compra*cte_iva-cmrc_percepcion_iva)+"</td> " +
                                "<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_alicuota_iibb)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alicuota_iibb/100)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion_iibb)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alicuota_iibb/100-cmrc_percepcion_iibb)+"</td> " +
                                " \n\t <td td class='t2'></td></tr>";
                         i--;
                        }
                    }                   
                else if (i>0)
                    {
                     cmrc_alicuota_iibb=rs.getFloat(8);
                     //cmrc_alicuota_iibb  = rs.getString(8).equals("3") ?  3.0f : 3.5f ;
                     resul+="\n\t<tr> <td td class='t2'>"+rs.getString(3)+", "+rs.getString(9)+"</td> "+
                                "\n\t<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(4))+"</td> <td td class='t2'>21</td> "+
                                "<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(4)*cte_iva)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(4)*cte_iva+rs.getFloat(4))+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(5))+"</td> "+
                                "<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(5)*cte_iva)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(5)*cte_iva+rs.getFloat(5))+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(6))+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(4)*cte_iva-rs.getFloat(5)*cte_iva-rs.getFloat(6))+"</td> " +
                                "<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_alicuota_iibb)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(4)*cmrc_alicuota_iibb/100)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(7))+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(4)*cmrc_alicuota_iibb/100-rs.getFloat(7))+"</td> " +
                                " \n\t <td td class='t2'></td></tr>";
                     i--;
                     //acumular floats
                     cmrc_bi+=rs.getFloat(4);
                     cmrc_compra+=rs.getFloat(5);
                     cmrc_percepcion_iva+=rs.getFloat(6);
                     cmrc_percepcion_iibb+=rs.getFloat(7);
                     
                     if (i==0)  // ya imprimio` todos los establecimientos del comercio, por lo que debe imprimir el total
                        {
                         resul+="\n\t<tr class='t1'> <td colspan='3'></td> "+  //imprimo 'totales' o no.
                           "\n\t<td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi)+"</td> <td> </td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cte_iva)+"</td> "+
                                "<td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi+cmrc_bi*cte_iva)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra)+"</td> "+
                                "<td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra*cte_iva)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra+cmrc_compra*cte_iva)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion_iva)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cte_iva-cmrc_compra*cte_iva-cmrc_percepcion_iva)+"</td> " +
                                "<td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_alicuota_iibb)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alicuota_iibb/100)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion_iibb)+"</td> <td>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alicuota_iibb/100-cmrc_percepcion_iibb)+"</td> " +
                                " \n\t <td></td></tr> " ;

                         i=-1;
                         cmrc_bi=0f;
                         cmrc_compra=0f;
                         cmrc_percepcion_iva=0f;
                         cmrc_percepcion_iibb=0f;
                        }

                    }

                }   // fin del while que recorre recordset
                    

           resul+="\n\t</table>";

            }
        catch (Exception ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con datos de liquidacion del establecimiento
        }
 

    
// Recibe  el periodo y devuelve una tabla con los saldos DDJJ IVA de los comercios para el periodo 

    private String LiquiMesIVATable(String periodo) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        Boolean empty=true;
	String resul, row_span;
        Float cmrc_bi=0.0f, cmrc_debito=0.0f, cmrc_venta_total=0.0f, cmrc_compra=0.0f, cmrc_credito=0.0f, cmrc_compra_total=0.0f, 
                cmrc_percepcion=0.0f, cmrc_saldo=0.0f, cmrc_alic=0.0f;
        try 
            {
            con=CX.getCx_pool();

            pst = con.prepareStatement( "SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, " +
                                                "em.base_imponible, " + //4
                                                "em.compra_iva, " +  //5
                                                "em.percepcion_iva, " +   // 6  percepciojn IVA
                                                "e.id_zona, "+   //  7  zona
                                                "(SELECT COUNT(*) \n" +
                                                " FROM EstablecimientosLiquiMes eem, Establecimientos ee \n" +
                                                " WHERE periodo='"+periodo+"' \n" +
                                                "   AND eem.id_establecimiento=ee.id_establecimiento \n" +
                                                "   AND ee.id_comercio=e.id_comercio), " +  //  8   COUNT
                                                "em.saldo_iva, " +  //9  saldo_iva
                                                "em.alicuota_iva " +  //10  alicuota
                                       " FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em " +
                                       " WHERE c.id_comercio = e.id_comercio " + 
                                           " AND e.id_establecimiento=em.id_establecimiento " +
                                           " AND em.periodo ='"+periodo+"' " +
                                       " ORDER BY c.nro_cuit, e.id_zona");  
            

            resul="<table class='grupos' width='1500px'>\n\t<tr>\n\t\t"+
                    "<th>CUIT</th> <th>Nombre</th> <th>Direccion Establecimiento</th>\n "+
                    "<th>Base Imponible</th> <th>Alic. IVA</th> <th>Debito IVA</th> <th>Venta Total</th> <th>Compra IVA</th>\n "+
                    "<th>Credito IVA</th> <th>Compra Total</th> <th>Percepcion IVA</th> <th>SALDO D.D.J.J. IVA</th>\n "+
                    "</tr>\n";

            rs = pst.executeQuery();
            int i=-1;
            while (rs.next())
                {
                empty=false;

                if (i<0)
                    {
                     row_span=rs.getString(8);
                     i=Integer.parseInt(row_span);

                    cmrc_bi=rs.getFloat(4);
                    cmrc_compra=rs.getFloat(5);
                    cmrc_percepcion=rs.getFloat(6);
                    cmrc_alic=rs.getFloat(10);
                    cmrc_venta_total=cmrc_bi+cmrc_debito;
                    cmrc_credito=cmrc_compra*cmrc_alic/100;
                    cmrc_compra_total=cmrc_compra+cmrc_credito;
                    cmrc_saldo=rs.getFloat(9);


                     
                     if (i==1)  // unico establecimiento del comercio
                        {
                         resul+="\n\t<tr class='t1'> <td class='t11' height='30px'>"+rs.getString(1)+"</td> <td class='t11'>"+rs.getString(2)+"</td> <td class='t11'>"+rs.getString(3)+", "+rs.getString(7)+"</td> "+
                                "\n\t<td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.1f",cmrc_alic)+"%</td> "+
                                "<td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alic/100)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi+cmrc_bi*cmrc_alic/100)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra)+"</td> "+
                                "<td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra*cmrc_alic/100)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra+cmrc_compra*cmrc_alic/100)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_saldo)+"</td> " +
                                " \n\t</tr> \n ";
                         i=-1;
                        }
                     else
                        {
                         resul+="\n\t<tr> <td rowspan='"+row_span+"' class='t2'> </td> <td rowspan='"+row_span+"' class='t2'></td> <td class='t2'>"+rs.getString(3)+", "+rs.getString(7)+"</td> "+
                                "\n\t<td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.1f",cmrc_alic)+"%</td> "+
                                "<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alic/100)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi+cmrc_bi*cmrc_alic/100)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra)+"</td> "+
                                "<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra*cmrc_alic/100)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra+cmrc_compra*cmrc_alic/100)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_saldo)+"</td> " +
                                " \n\t</tr>";
 
                         i--;
                        }
                    }
                else if (i>0)
                    {
                     resul+="\n\t<tr> <td td class='t2'>"+rs.getString(3)+", "+rs.getString(7)+"</td> "+
                                "\n\t<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(4))+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.1f",cmrc_alic)+"%</td> "+
                                "<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(4)*cmrc_alic/100)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(4)*cmrc_alic/100+rs.getFloat(4))+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(5))+"</td> "+
                                "<td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(5)*cmrc_alic/100)+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(5)*cmrc_alic/100+rs.getFloat(5))+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(6))+"</td> <td td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(9))+"</td> " +
                                " \n\t</tr>";
                     i--;
                     //acumular floats
                     cmrc_bi+=rs.getFloat(4);
                     cmrc_compra+=rs.getFloat(5);
                     cmrc_percepcion+=rs.getFloat(6);
                     cmrc_saldo+=rs.getFloat(9);
                     //cmrc_debito+=rs.getFloat(5);
 //                    cmrc_venta_total+=rs.getFloat(11);
                    // cmrc_credito+=rs.getFloat(7);
                    // cmrc_compra_total+=rs.getFloat(8);
                     if (i==0)  // ya imprimio` todos los establecimientos del comercio, por lo que debe imprimir el total
                        {
    //                     resul+="\n\t<tr class='t1'> <td colspan='3'></td> "+  //imprimo 'totales' o no.
                           resul+="\n\t<tr class='t1'> <td class='t12' height='25px'>"+rs.getString(1)+"</td><td class='t12'>"+rs.getString(2)+"</td> <td class='t11'></td>  "+  //imprimo 'totales' o no.
                                "\n\t<td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi)+"</td> <td class='t11'> </td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alic/100)+"</td> "+
                                "<td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi+cmrc_bi*cmrc_alic/100)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra)+"</td> "+
                                "<td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra*cmrc_alic/100)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_compra+cmrc_compra*cmrc_alic/100)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_saldo)+"</td> " +
                                " \n\t</tr>  " ;
 
                         i=-1;
                         cmrc_bi=0f;
                         cmrc_compra=0f;
                         cmrc_percepcion=0f;
                         cmrc_saldo=0f;
                         cmrc_alic=0f;
                        }

                    }

                }   // fin del while que recorre recordset

            resul+="\n\t</table>";




            if(empty)
                resul="No se encontro actividad para el periodo. <br><a href='/ameca/liquidaciones?operacion=ver_mv&do_masive=1&periodo="+periodo+"'>Carga masiva de comercios</a>.";
             else
                resul+="\n<table>\n<tr><td>Base imponible: <input type='text' name='base_imponible' value='+0' size='4'></td>\n"+
                                "<td>Compras: <input type='text' name='compra_iva' value='+0' size='4'></td>\n"+
                                "<td>Percepciones: <input type='text' name='percepcion_iva' value='+0' size='4'></td></tr>\n</table>\n"+
                                "<input type='submit'>";
           
            }
        catch (Exception ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con datos de liquidacion del establecimiento
        }
 

// Recibe  el periodo y devuelve una tabla con los saldos DDJJ IVA de los comercios para el periodo 

    private String LiquiMesIIBBTable(String periodo, String zona) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        
        Boolean empty=true;
	String resul, row_span, cond1, cond2;
        Float cmrc_bi=0.0f, cmrc_alic=0.0f, cmrc_debito=0.0f, cmrc_venta_total=0.0f, cmrc_percepcion=0.0f, cmrc_saldo=0.0f;
        try 
            {
            con=CX.getCx_pool();

            if(!zona.equals(""))
                 cond1=" id_zona="+zona+" AND periodo='"+periodo+"' ";
            else
                 cond1=" periodo='"+periodo+"' ";
                
            pst = con.prepareStatement( "SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, " +
                                                "em.base_imponible, " + // 4
                                                "em.percepcion_iibb, " + // 5
                                                "em.saldo_iibb, " +     // 6
                                                "em.alicuota_iibb, " +  // 7
                                                "e.id_zona, " +     // 8  zona
                                                "(SELECT COUNT(*) "+
                                                  "FROM EstablecimientosLiquiMes eem, Establecimientos ee "+
                                                  "WHERE periodo='"+periodo+"' "+
                                                        " AND eem.id_establecimiento=ee.id_establecimiento"+
                                                        " AND ee.id_comercio=e.id_comercio and e.activo_iibb) " +   // 9. count 
                                       " FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em " +
                                       " WHERE c.id_comercio = e.id_comercio  AND e.activo_iibb" + 
                                           " AND e.id_establecimiento=em.id_establecimiento AND periodo='"+periodo+"' " +
                                           " AND e.id_comercio in (SELECT ee.id_comercio " +
                                                                        " FROM EstablecimientosLiquiMes eem, Establecimientos ee " +
                                                                        " WHERE " +cond1+
                                                                        " AND eem.id_establecimiento=ee.id_establecimiento " +
                                                                        " AND e.activo_iibb)"+
                                       " ORDER BY nro_cuit, e.id_zona"); // caute q hay establecimientos del mismo comercio en zona distinta (no ordenar x zona)

            resul="<table class='grupos'>\n\t<tr>\n\t\t"+
                    "<th>CUIT</th> <th>Nombre</th> <th>Direccion Establecimiento</th> "+
                    "<th>Base Imponible</th> <th>Alic. IIBB</th> <th>Debito IIBB</th>  "+
                    "<th>Percepcion IIBB</th> <th>SALDO D.D.J.J. IIBB</th> "+
                    "    </tr>";

            rs = pst.executeQuery();
            int i=-1;
            while (rs.next())
                {
                empty=false;
                    // agrupar establecimientos del mismo comercio
                if (i<0)
                    {
                     row_span=rs.getString(9);
                     i=Integer.parseInt(row_span);

                    cmrc_bi=rs.getFloat(4);
                    cmrc_percepcion=rs.getFloat(5);
                    cmrc_alic=rs.getFloat(7);
                    cmrc_saldo=rs.getFloat(6);
                     
                     
                     
                     if (i==1)  // unico establecimiento del comercio
                        {
                         resul+="\n\t<tr class='t1'> <td class='t11' height='30px'>"+rs.getString(1)+"</td> <td class='t11'>"+rs.getString(2)+"</td> <td class='t11'>"+rs.getString(3)+", "+rs.getString(8)+"</td> "+
                            "\n\t<td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.1f",cmrc_alic)+"%</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alic/100)+"</td> "+
                            "<td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_saldo)+"</td> " +
                            "\n\t</tr>\n ";
 //                           "\n\t</tr>\n <tr> <td colspan='8' bgcolor='#E8E7C1' height='1px'> </td></tr>";
                         i=-1;
                        }
                     else
                        {
                         resul+="\n\t<tr> <td rowspan='"+row_span+"' class='t12'></td> <td rowspan='"+row_span+"' class='t12'></td> <td class='t2'>"+rs.getString(3)+", "+rs.getString(8)+"</td> "+
                            "\n\t<td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi)+"</td> <td class='t2'>"+String.format(Locale.GERMAN, "%,.1f",cmrc_alic)+"%</td> <td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alic/100)+"</td> "+
                            "<td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion)+"</td> <td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_saldo)+"</td> " +
                            "\n\t</tr>";
                         i--;
                        }
                         
                    }
                else if (i>0)
                    {
                     resul+="\n\t<tr> <td class='t2'>"+rs.getString(3)+", "+rs.getString(8)+"</td> "+
                       "\n\t<td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(4))+"</td> <td class='t2'>"+cmrc_alic+"%</td> <td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(4)*cmrc_alic/100)+"</td> "+
                       "<td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(5))+"</td> <td class='t2'>"+String.format(Locale.GERMAN, "%,.2f",rs.getFloat(6))+"</td> " +
                       "\n\t</tr>";
                     i--;
                     //acumular floats
                     cmrc_bi+=rs.getFloat(4);
                     cmrc_percepcion+=rs.getFloat(5);
                     cmrc_saldo+=rs.getFloat(6);

                     if (i==0)  // ya imprimio` todos los establecimientos del comercio, por lo que debe imprimir el total
                        {
                         resul+="\n\t<tr class='t1'> <td class='t12' height='25px'>"+rs.getString(1)+"</td><td class='t12'>"+rs.getString(2)+"</td> <td class='t11'></td>  "+  //imprimo 'totales' o no.
                           "\n\t<td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi)+"</td> <td class='t11'> </td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_bi*cmrc_alic/100)+"</td> "+
                           "<td class='t11'>"+String.format(Locale.GERMAN, "%,.2f",cmrc_percepcion)+"</td> <td class='t11'>"+String.format(Locale.GERMAN, "%,.2f", cmrc_saldo)+"</td></tr>\n"
                                 + "" ;
//                                 + "<tr> <td colspan='8' bgcolor='#E8E7C1' height='1px'> </td></tr> " ;
                         i=-1;
                         cmrc_bi=0f;
                         cmrc_debito=0f;
                         cmrc_percepcion=0f;
                         cmrc_saldo=0f;
                        }

                    }
                

                
                }
            resul+="\n\t</table>";
            
            if(empty)
                resul="No se encontro actividad para el periodo. <br><a href='/ameca/liquidaciones?operacion=ver_mb&do_masive=1&periodo="+periodo+"'>Carga masiva de comercios</a>.";
            else if(zona.equals(""))
                resul+="\n<table>\n<tr><td>Base imponible: <input type='text' name='base_imponible' value='+0' size='4'></td>\n"+
                                "<td>Percepciones: <input type='text' name='percepcion_iibb' value='+0' size='4'></td></tr>\n</table>\n"+
                                "<input type='submit'>";

            
            }
        catch (Exception ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con datos de liquidacion del establecimiento
        }


    
    // update masivo de los establecimientos en liquidacion iva.
    // Los parametros llegan con formato: +10 o -5 que representa el porcentaje a adhisionar o sustraer (validar esto en javascript).
    private String LiquiMesIVA_update(String periodo, String base_imponible, String percepcion_iva, String compra_iva) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        int resul;
        String res="";
        try 
            {
            con=CX.getCx_pool();

            pst = con.prepareStatement( "Update EstablecimientosLiquiMes SET base_imponible = base_imponible*(1"+base_imponible+"/100),"+
                                                                            " compra_iva = compra_iva*(1"+compra_iva+"/100), "+
                                                                            " percepcion_iva = percepcion_iva*(1"+percepcion_iva+"/100) " +
                                       " WHERE periodo ='"+periodo+"'");  
 
            resul= pst.executeUpdate();
            res= Integer.toString(resul);
            }
        catch (SQLException ex) {
               res= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                res= ex.getMessage();
                }
            }
        
        return res; // cant de registros modificados o msg de la excepcion
        }


    // update masivo de los establecimientos en liquidacion iibb.
    // Los parametros llegan con formato: +10 o -5 que representa el porcentaje a adhisionar o sustraer (validar esto en javascript).
    private String LiquiMesIIBB_update(String periodo, String base_imponible, String percepcion_iibb) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        int resul;
        String res="";
        try 
            {
            con=CX.getCx_pool();

            pst = con.prepareStatement( "Update EstablecimientosLiquiMes SET base_imponible = base_imponible*(1"+base_imponible+"/100),"+
                                                                            " percepcion_iibb = percepcion_iibb*(1"+percepcion_iibb+"/100) " +
                                       " WHERE periodo ='"+periodo+"'");  
 
            resul= pst.executeUpdate();
            res= Integer.toString(resul);
            }
        catch (SQLException ex) {
               res= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                res= ex.getMessage();
                }
            }
        
        return res; // cant de registros modificados o msg de la excepcion
        }


    
     // insert masivo de los establecimientos en EstablecimientoLiquiMes para periodo sin establecimientos.
    private String LiquiMes_masive(String periodo) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        int resul;
        String res="";
        try 
            {
            con=CX.getCx_pool();

            pst = con.prepareStatement( "INSERT INTO EstablecimientosLiquiMes (id_establecimiento, base_imponible, compra_iva, percepcion_iva, percepcion_iibb, periodo)\n" +
                                            " SELECT id_establecimiento, base_imponible*(1+10/100) , compra_iva*(1+10/100), percepcion_iva*(1+10/100), percepcion_iibb*(1+10/100), '"+periodo+"'\n" +
                                            " FROM  EstablecimientosLiquiMes\n" +
                                            " WHERE periodo ='201906'");  

            resul= pst.executeUpdate();
            res= Integer.toString(resul);
            }
        catch (SQLException ex) {
               res= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                res= ex.getMessage();
                }
            }
        
        return res; // cant de registros modificados o msg de la excepcion
        }


    
    
}