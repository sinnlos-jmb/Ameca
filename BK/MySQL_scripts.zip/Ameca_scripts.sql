update dbAmeca.Comercios SET razon_social='NN' where razon_social IS NULL;

update dbAmeca.Comercios SET nro_cuit=SUBSTRING(nro_cuit,1,11);

select * from dbAmeca.Comercios WHERE id_comercio>11;

select SUBSTRING(nro_cuit,1,11) as trun, nro_cuit from dbAmeca.Comercios WHERE id_comercio>0;

SELECT e.id_comercio, e.id_establecimiento, e.nombre_establecimiento, periodo, em.base_imponible, em.compra_iva, em.percepcion_iva
FROM Establecimientos e, EstablecimientosLiquiMes em 
WHERE e.id_establecimiento=em.id_establecimiento 
	AND e.id_establecimiento=7
	AND periodo='201908';

SELECT id_comercio FROM dbAmeca.Comercios WHERE MATCH (nro_cuit) AGAINST ('23249636') ;

SELECT id_comercio FROM dbAmeca.Comercios WHERE nro_cuit like '23249636%' ;

SELECT id_comercio, razon_social, apellido_responsable FROM dbAmeca.Comercios WHERE nro_cuit like '2324%'

SELECT c.id_comercio, razon_social, nombre_responsable, apellido_responsable, nro_cuit, domicilio_fiscal, direccion_establecimiento
FROM Comercios c, Establecimientos e 
WHERE c.id_comercio=e.id_comercio AND (domicilio_fiscal like 'a%' OR direccion_establecimiento like 'a%');

SELECT c.id_comercio, razon_social, nombre_responsable, apellido_responsable, nro_cuit, domicilio_fiscal, direccion_establecimiento, e.id_establecimiento
FROM Comercios c, Establecimientos e 
WHERE c.id_comercio=e.id_comercio AND nro_cuit like '23%';
GROUP BY c.id_comercio, razon_social, nombre_responsable, apellido_responsable, nro_cuit, domicilio_fiscal
ORDER BY nombre_responsable;


SELECT COUNT(*) FROM dbAmeca.Comercios WHERE razon_social=NULL;

SELECT COUNT(*) FROM dbAmeca.Comercios WHERE razon_social IS NULL;

SELECT yearweek(now()) FROM dbAmeca.Comercios;

SELECT dbAmeca.EstablecimientosLiquiMes.base_imponible, FORMAT (base_imponible*0.03,2, 'de_DE') as 'por 0.03' 
FROM dbAmeca.EstablecimientosLiquiMes;

DELETE FROM dbAmeca.Comercios WHERE id_comercio=11;

select 66;


-- liquidacion IIBB
SELECT dbAmeca.Comercios.nro_cuit, dbAmeca.Comercios.nombre_responsable, dbAmeca.Establecimientos.direccion_establecimiento, 
		dbAmeca.EstablecimientosLiquiMes.base_imponible,
		dbAmeca.EstablecimientosLiquiMes.base_imponible*dbAmeca.EstablecimientosLiquiMes.alicuota_iibb/100 as debito_fiscal,
		dbAmeca.EstablecimientosLiquiMes.percepciones, 
		col5- dbAmeca.EstablecimientosLiquiMes.percepciones
FROM dbAmeca.Comercios, dbAmeca.Establecimientos, dbAmeca.EstablecimientosLiquiMes
WHERE dbAmeca.Comercios.id_comercio = dbAmeca.Establecimientos.id_comercio 
	AND dbAmeca.Establecimientos.id_establecimiento=dbAmeca.EstablecimientosLiquiMes.id_establecimiento;
	

SELECT 
    @importe := (`base_imponible`*`alicuota_iibb`/100) AS 'Importe' ,
    percepcion, @importe-percepcion as 'Saldo'
FROM 
    dbAmeca.EstablecimientosLiquiMes;
    
   SELECT 
    @importe := (base_imponible*alicuota_iibb/100) AS 'Importe' ,
    percepcion, @importe-percepcion as 'Saldo'
FROM 
    dbAmeca.EstablecimientosLiquiMes;

   
 -- liquidacion IVA
SELECT dbAmeca.Comercios.CUIT, dbAmeca.Comercios.nombre_responsable, dbAmeca.Establecimientos.direccion_establecimiento, 
		dbAmeca.EstablecimientosLiquiMes.base_imponible,
		dbAmeca.EstablecimientosLiquiMes.base_imponible*dbAmeca.EstablecimientosLiquiMes.alicuota_iva/100 as debito_fiscal_iva,
		dbAmeca.EstablecimientosLiquiMes.base_imponible*dbAmeca.EstablecimientosLiquiMes.alicuota_iibb/100 as debito_fiscal_iibb,
		dbAmeca.EstablecimientosLiquiMes.compra_iva, 
		dbAmeca.EstablecimientosLiquiMes.compra_iva*dbAmeca.EstablecimientosLiquiMes.alicuota_iva/100 as iva_credito 
FROM dbAmeca.Comercios, dbAmeca.Establecimientos, dbAmeca.EstablecimientosLiquiMes
WHERE dbAmeca.Comercios.id_comercio = dbAmeca.Establecimientos.id_comercio 
	AND dbAmeca.Establecimientos.id_establecimiento=dbAmeca.EstablecimientosLiquiMes.id_establecimiento;

SELECT dbAmeca.Comercios.nro_cuit, dbAmeca.Comercios.nombre_responsable, dbAmeca.Establecimientos.direccion_establecimiento, 
		dbAmeca.EstablecimientosLiquiMes.base_imponible,
		@debitoF_iva := (dbAmeca.EstablecimientosLiquiMes.base_imponible*dbAmeca.EstablecimientosLiquiMes.alicuota_iva/100) as 'debito fiscal_iva',
		@debitoF_iibb := (dbAmeca.EstablecimientosLiquiMes.base_imponible*dbAmeca.EstablecimientosLiquiMes.alicuota_iibb/100) as 'debito fiscal_iibb',
		dbAmeca.EstablecimientosLiquiMes.compra_iva, 
		@ivaC := (dbAmeca.EstablecimientosLiquiMes.compra_iva*dbAmeca.EstablecimientosLiquiMes.alicuota_iva/100) as 'iva credito', 
		@debitoF-@ivaC as 'compra total',
		dbAmeca.EstablecimientosLiquiMes.percepcion_iva,
		dbAmeca.EstablecimientosLiquiMes.percepcion_iibb,
		@debitoF_iva-@ivaC-percepcion_iva as 'saldo ddjj iva',
		@debitoF_iibb-percepcion_iibb as 'saldo ddjj iibb'
FROM dbAmeca.Comercios, dbAmeca.Establecimientos, dbAmeca.EstablecimientosLiquiMes
WHERE dbAmeca.Comercios.id_comercio = dbAmeca.Establecimientos.id_comercio 
	AND dbAmeca.Establecimientos.id_establecimiento=dbAmeca.EstablecimientosLiquiMes.id_establecimiento;
  

SELECT dbAmeca.Comercios.nro_cuit, dbAmeca.Comercios.nombre_responsable, dbAmeca.Establecimientos.direccion_establecimiento, 
		dbAmeca.EstablecimientosLiquiMes.base_imponible,
		@debitoF_iva := (dbAmeca.EstablecimientosLiquiMes.base_imponible*dbAmeca.EstablecimientosLiquiMes.alicuota_iva/100) as 'debito fiscal_iva',
		@debitoF_iibb := (dbAmeca.EstablecimientosLiquiMes.base_imponible*dbAmeca.EstablecimientosLiquiMes.alicuota_iibb/100) as 'debito fiscal_iibb',
		dbAmeca.EstablecimientosLiquiMes.compra_iva, 
		@ivaC := (dbAmeca.EstablecimientosLiquiMes.compra_iva*dbAmeca.EstablecimientosLiquiMes.alicuota_iva/100) as 'iva credito', 
		@debitoF-@ivaC as 'compra total',
		dbAmeca.EstablecimientosLiquiMes.percepcion_iva,
		dbAmeca.EstablecimientosLiquiMes.percepcion_iibb,
		@debitoF_iva-@ivaC-percepcion_iva as 'saldo ddjj iva',
		@debitoF_iibb-percepcion_iibb as 'saldo ddjj iibb'
FROM dbAmeca.Comercios, dbAmeca.Establecimientos, dbAmeca.EstablecimientosLiquiMes
WHERE dbAmeca.Comercios.id_comercio = dbAmeca.Establecimientos.id_comercio 
	AND dbAmeca.Establecimientos.id_establecimiento=dbAmeca.EstablecimientosLiquiMes.id_establecimiento;
	AND dbAmeca.Comercios.id_comercio = 12;  //tambien consultar por id_establecimiento para que no sean todas las sucursales del comercio
//	AND dbAmeca.Comercios.id_comercio = 13;  //tambien consultar por id_establecimiento para que no sean todas las sucursales del comercio
	

SELECT 	FORMAT (dbAmeca.EstablecimientosLiquiMes.base_imponible, 2, 'de_DE') as 'base imponible',
		@debitoF_iva := (dbAmeca.EstablecimientosLiquiMes.base_imponible*dbAmeca.EstablecimientosLiquiMes.alicuota_iva/100) as 'debito fiscal_iva',
		FORMAT (@debitoF_iva, 2, 'de_DE') as 'debito iva',
		@debitoF_iibb := (dbAmeca.EstablecimientosLiquiMes.base_imponible*dbAmeca.EstablecimientosLiquiMes.alicuota_iibb/100) as 'debito fiscal_iibb',
		base_imponible+@debitoF_iva as 'Venta Total', 
		dbAmeca.EstablecimientosLiquiMes.compra_iva, 
		@iva_credito := (dbAmeca.EstablecimientosLiquiMes.compra_iva*dbAmeca.EstablecimientosLiquiMes.alicuota_iva/100) as 'iva credito', 
		compra_iva+@iva_credito as 'Compra Total',
		percepcion_iva, percepcion_iibb,
		FORMAT (@debitoF_iva-@iva_credito-percepcion_iva, 2, 'de_DE') as 'saldo ddjj iva',
		@debitoF_iibb-percepcion_iibb as 'saldo ddjj iibb',
		alicuota_iibb, alicuota_iva
FROM dbAmeca.EstablecimientosLiquiMes
WHERE periodo='201909';
-- WHERE dbAmeca.EstablecimientosLiquiMes.id_establecimiento = 7 AND periodo='201909';


SELECT base_imponible, 	base_imponible*(1-10/100) as 'calc', 286688.6*(1+10/100)
FROM dbAmeca.EstablecimientosLiquiMes
WHERE periodo='201906';

SELECT id_establecimiento, periodo, base_imponible, compra_iva, percepcion_iva
FROM dbAmeca.EstablecimientosLiquiMes
WHERE periodo='201906' 
ORDER BY 1;

ALTER TABLE dbAmeca.EstablecimientosLiquiMes MODIFY COLUMN base_imponible decimal(10,2) DEFAULT 0 NOT NULL;


UPDATE dbAmeca.EstablecimientosLiquiMes SET base_imponible=base_imponible*(1+10/100) 
WHERE dbAmeca.EstablecimientosLiquiMes.id_establecimiento = 7 AND periodo='201907';
	
INSERT INTO dbAmeca.EstablecimientosLiquiMes (id_establecimiento, base_imponible, compra_iva, percepcion_iva, periodo)
SELECT 
   id_establecimiento, base_imponible*(1+10/100) , compra_iva*(1+10/100), percepcion_iva*(1+10/100), '201906'
FROM 
   dbAmeca.EstablecimientosLiquiMes
WHERE periodo='201907';

// locales

SELECT @@lc_time_names;

SET lc_time_names = 'es_ES';

SELECT MONTHNAME('1999-10-03');

SHOW VARIABLES LIKE 'character_set_system';

SHOW VARIABLES LIKE 'collate_system';


update EstablecimientosLiquiMes SET base_imponible=245099.02 WHERE id_establecimiento_mes=28;

update EstablecimientosLiquiMes SET percepcion_iibb=compra_iva WHERE periodo ='201906';

SELECT id_establecimiento_mes, base_imponible, compra_iva, percepcion_iva, percepcion_iibb FROM EstablecimientosLiquiMes WHERE periodo ='201906' ;

Update EstablecimientosLiquiMes SET base_imponible = base_imponible*(1+0/100), compra_iva = compra_iva*(1+0/100), percepcion_iva = percepcion_iva*(1+10/100)  WHERE periodo ='201907' ;

SELECT id_establecimiento_mes, base_imponible, percepcion_iibb, id_establecimiento
FROM EstablecimientosLiquiMes 
WHERE periodo ='201908' and id_establecimiento in (6,7,9)
order by 4;

Update EstablecimientosLiquiMes SET base_imponible = base_imponible*(1+0/100), percepcion_iibb = percepcion_iibb*(1+10/100)  WHERE periodo ='201907' ;

Update EstablecimientosLiquiMes SET base_imponible = base_imponible*(1+0/100), percepcion_iibb = percepcion_iibb*100 WHERE periodo ='201907' 

ALTER TABLE dbAmeca.EstablecimientosLiquiMes MODIFY COLUMN compra_iva DECIMAL(10,2) DEFAULT 0.00 NOT NULL;

Update EstablecimientosLiquiMes SET base_imponible = base_imponible*(1+0/100), percepcion_iibb = percepcion_iibb*(1+20/100) WHERE periodo ='201907' ;

SELECT id_comercio, COUNT(*) FROM Establecimientos GROUP BY id_comercio ORDER BY 1;  

SELECT id_establecimiento, id_comercio FROM Establecimientos ORDER BY 2;

SELECT COUNT(*) FROM Establecimientos WHERE id_comercio=4 ;  

-- devuelve cantidad de establecimientos de un comercio en el listado mensual de liquidaciones (junto con sum base imponible y demas campos).
SELECT 	e.id_establecimiento, c.nombre_responsable, FORMAT (em.base_imponible, 2, 'de_DE') as 'base imponible',
		FORMAT (em.base_imponible*0.03, 2, 'de_DE') as 'debito iibb',
		em.percepcion_iibb, e.id_zona, nro_cuit,
		(SELECT CONCAT(COUNT(*), '|',SUM(eem.base_imponible), '|', SUM(eem.percepcion_iibb), '|', SUM(eem.base_imponible*0.03), '|', SUM(eem.base_imponible*1.3)) FROM EstablecimientosLiquiMes eem, Establecimientos ee WHERE periodo='201908' AND eem.id_establecimiento=ee.id_establecimiento AND ee.id_comercio=e.id_comercio) as 'count', c.id_comercio
FROM dbAmeca.EstablecimientosLiquiMes em, Establecimientos e, Comercios c
WHERE periodo='201908' AND em.id_establecimiento=e.id_establecimiento AND c.id_comercio=e.id_comercio -- AND e.id_comercio=12
ORDER BY nro_cuit;




===============
migratio

SELECT COUNT(*) FROM Comercios_old;

SELECT COUNT(*) FROM Liqui_IIBB201907_unicos;

SELECT * FROM Liqui_IIBB201907_unicos;

SELECT * FROM Comercios_old;

SELECT *

SELECT  COUNT(*)
FROM Comercios c, Liqui_IIBB201907_unicos l, Establecimientos e
WHERE e.id_comercio=c.id_comercio AND c.nro_cuit = l.CUIT;

SELECT CUIT, Titular
FROM Liqui_IIBB201907_unicos l
INNER JOIN Comercios c ON c.nro_cuit=l.CUIT
LEFT JOIN Establecimientos e ON e.id_comercio=c.id_comercio
WHERE l.`Domicilio Comercial`=c.domicilio_fiscal;

SELECT  c.nro_cuit, COUNT(*)
FROM Comercios c, Liqui_IIBB201907_unicos l, Establecimientos e
WHERE e.id_comercio=c.id_comercio AND c.nro_cuit = l.CUIT
GROUP BY c.nro_cuit
HAVING COUNT(*)>1;

SELECT  c.nro_cuit, c.nombre_responsable
FROM Comercios c, Liqui_IIBB201907_unicos l, Establecimientos e
WHERE e.id_comercio=c.id_comercio AND c.nro_cuit = l.CUIT AND c.nro_cuit not in ('20-94190860-9', '20-94818162-3', '20-95663851-9');

select * FROM Liqui_IIBB201907_unicos WHERE CUIT in ('20-94190860-9', '20-94818162-3', '20-95663851-9');

select * FROM Liqui_IIBB201907_unicos WHERE CUIT ='20-94478632-6';

SELECT * FROM Liqui_IIBB201907_unicos
WHERE cuit='20-95663851-9';

SELECT * FROM Comercios
WHERE nro_cuit='20-95663851-9';

SELECT * FROM EstablecimientosLiquiMes;


SELECT * FROM Establecimientos
WHERE id_comercio=293;

SELECT * FROM Establecimientos e, Comercios c 
WHERE e.id_comercio=c.id_comercio and ;

SELECT c.nro_cuit, c.nombre_responsable
FROM Establecimientos e
LEFT JOIN Comercios c ON c.id_comercio=e.id_comercio; 

SELECT c.nro_cuit, c.nombre_responsable
FROM Establecimientos e, Comercios c, Liqui_IIBB201907_unicos l 
WHERE l.CUIT=c.nro_cuit AND c.id_comercio=e.id_comercio AND l.`Domicilio Comercial`=c.domicilio_fiscal;


==

TRUNCATE EstablecimientosLiquiMes;

INSERT INTO EstablecimientosLiquiMes (id_establecimiento, base_imponible, alicuota_iibb, percepcion_iibb, periodo)
SELECT e.id_establecimiento, l.base_imponible, l.alícuota_iibb, l.percepcion_iibb, '201907' 
FROM Establecimientos e, Comercios c, Liqui_IIBB201907_unicos l
WHERE e.id_comercio=c.id_comercio and l.CUIT=c.nro_cuit and c.nro_cuit not in ('20-94190860-9', '20-94818162-3', '20-95663851-9');


SELECT  DISTINCT l.cuit
FROM Comercios_old c, Liqui_IIBB201907_unicos l 
WHERE c.cuit = l.CUIT ;

SELECT  c.*
FROM Comercios_old co, Liqui_IIBB201907_unicos l, Comercios c 
WHERE co.cuit = l.CUIT and co.CUIT=c.nro_cuit 
GROUP BY l.CUIT
HAVING COUNT(*)>1;    -- cuits de establecimientos que no se deberian liquidar: ('20-94190860-9', '20-94818162-3', '20-95663851-9')

INSERT INTO EstablecimientosLiquiMes (id_establecimiento, base_imponible, alicuota_iibb, percepcion_iibb, periodo)
SELECT 33, l.base_imponible, l.alícuota_iibb, l.percepcion_iibb, '201907' 
FROM Liqui_IIBB201907_unicos l
WHERE l.CUIT='20-95663851-9';


-- 20-94190860-9: id_comercio=296 id_establecimiento=55
-- 20-94818162-3: id_comercio=306 id_sucursal=316
-- 20-95663851-9: id_comercio=293 id_establecimiento=33

SELECT * FROM Establecimientos WHERE id_establecimiento=33;

SELECT  l.*
FROM Comercios_old co, Liqui_IIBB201907_unicos l 
WHERE co.cuit = l.CUIT  
GROUP BY l.CUIT
HAVING COUNT(*)>1;

==

UPDATE Establecimientos set activo=true WHERE id_establecimiento in (SELECT id_establecimiento FROM EstablecimientosLiquiMes)

select * from Establecimientos WHERE id_establecimiento in (SELECT id_establecimiento FROM EstablecimientosLiquiMes)

SELECT * FROM Establecimientos WHERE activo;

SELECT * FROM Establecimientos e, EstablecimientosLiquiMes em 
where em.id_establecimiento=e.id_establecimiento;

SELECT * FROM Establecimientos e;

SELECT * FROM EstablecimientosLiquiMes e;


SELECT * FROM Comercios_old WHERE CUIT='20-94190860-9';
SELECT e.* FROM Comercios c, Establecimientos e WHERE c.nro_cuit='20-94190860-9' AND e.id_comercio=c.id_comercio;

SELECT * FROM Comercios_old WHERE CUIT='20-94818162-3';
SELECT e.* FROM Comercios c, Establecimientos e WHERE c.nro_cuit='20-94818162-3' AND e.id_comercio=c.id_comercio;

SELECT * FROM Comercios_old WHERE CUIT='20-95663851-9';
SELECT e.* FROM Comercios c, Establecimientos e WHERE c.nro_cuit='20-95663851-9' AND e.id_comercio=c.id_comercio;

SELECT * FROM Liqui_IIBB201907_unicos WHERE CUIT='20-95663851-9';

SELECT * FROM Liqui_IIBB201907_SUCURSALES WHERE CUIT='20-95663851-9';


SELECT  COUNT(*)
FROM Comercios_old c 
WHERE c.cuit IN (SELECT CUIT from Liqui_IIBB201907_unicos);

SELECT COUNT(*)
FROM Liqui_IIBB201907_unicos li
LEFT JOIN Comercios_old co ON li.CUIT=co.CUIT AND co.CUIT IS NOT NULL;

SELECT DISTINCT li.CUIT, co.cuit
FROM Liqui_IIBB201907_unicos li
LEFT JOIN Comercios_old co ON li.CUIT=co.CUIT AND co.CUIT IS NOT NULL;

SELECT li.CUIT, com.cuit, com.NombreResponsable, cuit_administrador
FROM Liqui_IIBB201907_unicos li
LEFT JOIN Comercios_old com ON li.CUIT=com.CUIT 
WHERE li.CUIT=com.cuit and li.cuit in (SELECT  l.cuit
FROM Comercios_old c, Liqui_IIBB201907_unicos l 
WHERE c.cuit = l.CUIT 
GROUP BY l.CUIT
HAVING COUNT(*)>1);

SELECT *
FROM Comercios_old com 
WHERE com.cuit in (SELECT  l.cuit
FROM Comercios_old c, Liqui_IIBB201907_unicos l 
WHERE c.cuit = l.CUIT 
GROUP BY l.CUIT
HAVING COUNT(*)>1)
ORDER BY nombreresponsable;


SELECT COUNT(*)
FROM Comercios_old co
LEFT JOIN Liqui_IIBB201907_unicos li ON li.CUIT=co.CUIT;

SELECT COUNT(*)
FROM Comercios_old co
INNER JOIN Liqui_IIBB201907_unicos li ON li.CUIT=co.CUIT;


SELECT *
FROM Comercios_old com 
WHERE com.cuit in (SELECT  c.cuit
FROM Comercios_old c, Liqui_IIBB201907_unicos l 
WHERE c.cuit = l.CUIT 
GROUP BY l.CUIT
HAVING COUNT(*)>1)
ORDER BY nombreresponsable;

DELETE FROM dbAmeca.Comercios;

UPDATE Comercios  SET cantidad_empleados='0';

UPDATE Comercios com  SET com.cantidad_empleados='1'
WHERE com.nro_cuit in (SELECT  c.cuit
					FROM Comercios_old c 
					GROUP BY c.cuit
					HAVING COUNT(*)>1);


SELECT * FROM Comercios;

INSERT INTO dbAmeca.Comercios (nro_cuit, nombre_responsable, domicilio_fiscal, nro_telefono, fecha_alta, fecha_baja, fecha_inauguracion)
SELECT 
   cuit, nombreresponsable, domicilio_fiscal, telfono1, STR_TO_DATE(fechaalta, "%m/%d/%y"), STR_TO_DATE(fechabaja, "%m/%d/%y"), STR_TO_DATE(fecha_apertura, "%m/%d/%y")
FROM 
   dbAmeca.Comercios_old;

   
   SELECT STR_TO_DATE("6/20/18", "%m/%d/%y");
  
SELECT idcomercio, cuit, nombreresponsable, domicilio_fiscal, direccin_comercial, zona
FROM Comercios_old com 
WHERE com.cuit not in (SELECT  c.cuit
					FROM Comercios_old c 
					GROUP BY c.cuit
					HAVING COUNT(*)>1)
ORDER BY com.nombreresponsable;

SELECT  * -- id_comercio, c.nro_cuit, c.nombre_responsable, c.cantidad_empleados, c.domicilio_fiscal
FROM Comercios c 
where c.cantidad_empleados>0
ORDER BY c.nombre_responsable;



(68, 393, 81, 415, 416, 369, 104, 89, 378, 373, 368, 139, 147, 151, 366,180, 184, 192, 220, 239, 235, 409, 266,269, 270, 288, 363, 362, 292, 281, 301, 318, 391, 330, 335, 377, 364, 365, 207, 348, 349)

repetidos: 18-24 y 3-4 (idcomercio 342 queda y 347 eliminar, guardando telfono1 y agenciaafip)

SELECT * from Comercios_old WHERE idcomercio=320 OR idcomercio=319;

UPDATE Comercios_old set telfono1='1128565200 (SOFIA)' , agenciaafip='9' where idcomercio=342;

UPDATE Comercios_old set localidad='FLORES' where idcomercio=320;

DELETE FROM Comercios_old WHERE idcomercio=319;

SELECT DISTINCT(cuit) from Comercios_old;

SELECT * from Comercios_old;

SELECT idcomercio, cuit, nombreresponsable, domicilio_fiscal, telfono1, mail1, FechaAlta, Fecha_Apertura, FechaBaja, 
Observaciones, ABLInmobiliario, AgenciaAfip, CondicinIIBB, Alicuota_PagoPyme, CondicinIVA, AbreviaturaIVA, TopeCategoraAutnomo,
CategoraAutnomo, MontoMensualAutnomo, CategoraMonotributo, CategAdic
FROM Comercios_old com 
WHERE com.cuit not in (SELECT  c.cuit
					FROM Comercios_old c 
					GROUP BY c.cuit
					HAVING COUNT(*)>1)
ORDER BY com.nombreresponsable;


INSERT INTO dbAmeca.Comercios (nro_cuit, nombre_responsable, domicilio_fiscal, nro_telefono, email, fecha_alta, fecha_baja, fecha_inauguracion, observaciones, abl_inmobiliario, agencia_afip, condicion_iibb, condicion_iva,
alicuota_pago_pyme, abreviatura_iva, tope_categoria_autonomo, categoria_autonomo, monto_mensual_autonomo,
categoria_monotributo )
SELECT cuit, nombreresponsable, domicilio_fiscal, telfono1, mail1, STR_TO_DATE(fechaalta, "%m/%d/%y"), STR_TO_DATE(fechabaja, "%m/%d/%y"), STR_TO_DATE(fecha_apertura, "%m/%d/%y"), 
Observaciones, ABLInmobiliario, AgenciaAfip, CondicinIIBB, CondicinIVA, Alicuota_PagoPyme, AbreviaturaIVA, TopeCategoraAutnomo, CategoraAutnomo, MontoMensualAutnomo, CategoraMonotributo
FROM Comercios_old com 
WHERE com.cuit not in (SELECT  c.cuit
					FROM Comercios_old c 
					GROUP BY c.cuit
					HAVING COUNT(*)>1)
ORDER BY com.cuit;

INSERT INTO dbAmeca.Comercios (nro_cuit, nombre_responsable, domicilio_fiscal, nro_telefono, email, fecha_alta, fecha_baja, fecha_inauguracion, observaciones, abl_inmobiliario, agencia_afip, condicion_iibb, condicion_iva,
alicuota_pago_pyme, abreviatura_iva, tope_categoria_autonomo, categoria_autonomo, monto_mensual_autonomo,
categoria_monotributo, categoria_adicional )
SELECT cuit, nombreresponsable, domicilio_fiscal, telfono1, mail1, STR_TO_DATE(fechaalta, "%m/%d/%y"), STR_TO_DATE(fechabaja, "%m/%d/%y"), STR_TO_DATE(fecha_apertura, "%m/%d/%y"), 
Observaciones, ABLInmobiliario, AgenciaAfip, CondicinIIBB, CondicinIVA, Alicuota_PagoPyme, AbreviaturaIVA, TopeCategoraAutnomo, CategoraAutnomo, MontoMensualAutnomo, CategoraMonotributo, categadic
FROM Comercios_old com 
WHERE com.cuit in (SELECT  DISTINCT c.cuit
					FROM Comercios_old c 
					GROUP BY c.cuit
					HAVING COUNT(*)>1);

UPDATE Comercios_old co, Comercios c set co.id_comercio=c.id_comercio
WHERE c.nro_cuit=co.CUIT

SELECT * 
FROM Comercios_old where id_comercio is NULL
ORDER BY cuit;

SELECT * FROM Comercios_old where cuit='20-95663851-9' ORDER BY NombreResponsable;

SELECT * FROM Comercios where nro_cuit='20-95663851-9' ;

idcomercios que no estan en comercios (ie en id_comercio) 
(16, 345, 131, 219, 139, 216, 242, 52, 152, 155, 170, 231, 250, 298, 153, 184, 211, 95, 37, 99, 312, 56, 31, 29, 324, 284, 30, 279, 238, 122, 86, 295, 127, 189, 268)

UPDATE Comercios_old set Telfono1='1128698688' where idcomercio=284;

INSERT INTO dbAmeca.Comercios (nro_cuit, nombre_responsable, domicilio_fiscal, nro_telefono, email, fecha_alta, fecha_baja, fecha_inauguracion, observaciones, abl_inmobiliario, agencia_afip, condicion_iibb, condicion_iva,
alicuota_pago_pyme, abreviatura_iva, tope_categoria_autonomo, categoria_autonomo, monto_mensual_autonomo,
categoria_monotributo, categoria_adicional )
SELECT cuit, nombreresponsable, domicilio_fiscal, telfono1, mail1, STR_TO_DATE(fechaalta, "%m/%d/%y"), STR_TO_DATE(fechabaja, "%m/%d/%y"), STR_TO_DATE(fecha_apertura, "%m/%d/%y"), 
Observaciones, ABLInmobiliario, AgenciaAfip, CondicinIIBB, CondicinIVA, Alicuota_PagoPyme, AbreviaturaIVA, TopeCategoraAutnomo, CategoraAutnomo, MontoMensualAutnomo, CategoraMonotributo, categadic
FROM Comercios_old com 
WHERE com.cuit not in (SELECT  DISTINCT c.cuit
					FROM Comercios_old c 
					GROUP BY c.cuit
					HAVING COUNT(*)>1);

TRUNCATE Comercios;

SELECT * FROM Comercios;
SELECT * FROM Comercios_old where id_comercio>0;

INSERT INTO dbAmeca.Comercios (nro_cuit, nombre_responsable, domicilio_fiscal, nro_telefono, email, fecha_alta, fecha_baja, fecha_inauguracion, observaciones, abl_inmobiliario, agencia_afip, condicion_iibb, condicion_iva,
alicuota_pago_pyme, abreviatura_iva, tope_categoria_autonomo, categoria_autonomo, monto_mensual_autonomo,
categoria_monotributo, categoria_adicional )
SELECT cuit, nombreresponsable, domicilio_fiscal, telfono1, mail1, STR_TO_DATE(fechaalta, "%m/%d/%y"), STR_TO_DATE(fechabaja, "%m/%d/%y"), STR_TO_DATE(fecha_apertura, "%m/%d/%y"), 
Observaciones, ABLInmobiliario, AgenciaAfip, CondicinIIBB, CondicinIVA, Alicuota_PagoPyme, AbreviaturaIVA, TopeCategoraAutnomo, CategoraAutnomo, MontoMensualAutnomo, CategoraMonotributo, categadic
FROM Comercios_old com 
WHERE com.IdComercio in (16, 345, 131, 219, 139, 216, 242, 52, 152, 155, 170, 231, 250, 298, 153, 184, 211, 95, 37, 99, 312, 56, 31, 29, 324, 284, 30, 279, 238, 122, 86, 295, 127, 189, 268);

SELECT distinct cuit FROM Comercios_old;

UPDATE Comercios_old set id_comercio=0;

UPDATE Comercios_old co, Comercios c set co.id_comercio=c.id_comercio
WHERE c.nro_cuit=co.CUIT

-- migratio on Establecimientos
INSERT INTO dbAmeca.Establecimientos (id_comercio, nombre_responsable, direccion_establecimiento, nro_telefono_establecimiento, telefono2_establecimiento, email_establecimiento, zona, localidad, provincia, fecha_alta, fecha_baja, fecha_inauguracion, observaciones, activo, porcentaje_sociedad)
SELECT id_comercio, nombreresponsable, direccin_comercial, telfono1, telfono2, mail1, zona, localidad, provincia, STR_TO_DATE(fechaalta, "%m/%d/%y"), STR_TO_DATE(fechabaja, "%m/%d/%y"), STR_TO_DATE(fecha_apertura, "%m/%d/%y"), Observaciones, false, porcentajesociedad
FROM Comercios_old ;

TRUNCATE Establecimientos;
SELECT * FROM Establecimientos;


SELECT e.id_comercio, c.nro_cuit
FROM Establecimientos e, Comercios c
WHERE	e.id_comercio=c.id_comercio AND
		e.id_comercio in (SELECT  es.id_comercio
					FROM Establecimientos es 
					GROUP BY es.id_comercio
					HAVING COUNT(*)>1);
				

-- migratio Establecimientos con sucursales
				
SELECT * FROM Liqui_IIBB201907_SUCURSALES;

SELECT DISTINCT CUIT FROM Liqui_IIBB201907_SUCURSALES;
SELECT CUIT, SUM(base_imponible), COUNT(*) FROM Liqui_IIBB201907_SUCURSALES GROUP BY CUIT;

SELECT * FROM Liqui_IIBB201907_SUCURSALES
WHERE Tipo = '';


SELECT * FROM Liqui_IIBB201907_unicos l, Establecimientos e, Comercios c
WHERE e.id_comercio=c.id_comercio AND l.CUIT=c.nro_cuit AND c.nro_cuit='20-94022355-6'

SELECT * FROM Liqui_IIBB201907_SUCURSALES ls, Liqui_IIBB201907_unicos lu
WHERE lu.CUIT=ls.CUIT;

-- primer paso eliminar las filas que calculan totales
DELETE FROM Liqui_IIBB201907_SUCURSALES
WHERE Tipo = '';

SELECT DISTINCT l.*, c.nro_cuit, c.nombre_responsable 
FROM Liqui_IIBB201907_SUCURSALES l, Establecimientos e, Comercios c
WHERE e.id_comercio=c.id_comercio AND l.CUIT=c.nro_cuit;

SELECT * FROM Establecimientos;
SELECT c.nro_cuit, c.nombre_responsable, e.id_establecimiento, e.activo, e.direccion_establecimiento
FROM Establecimientos e, Comercios c
WHERE e.id_comercio=c.id_comercio AND c.nro_cuit='20-94022355-6';

SELECT l.*, e.id_establecimiento, e.direccion_establecimiento
FROM Liqui_IIBB201907_SUCURSALES l, Establecimientos e, Comercios c
WHERE c.id_comercio=e.id_comercio AND e.direccion_establecimiento=l.`Domicilio Comercial` and c.nro_cuit in (select cuit from Liqui_IIBB201907_SUCURSALES)
ORDER BY CUIT;

SELECT l.*, e.id_establecimiento, e.direccion_establecimiento
FROM Liqui_IIBB201907_SUCURSALES l, Establecimientos e, Comercios c
WHERE c.id_comercio=e.id_comercio AND e.direccion_establecimiento=l.`Domicilio Comercial` and c.nro_cuit in (select cuit from Liqui_IIBB201907_SUCURSALES)
ORDER BY CUIT;

-- agrego id_sucursal a liguidaciones para match con id_establecimiento
update Liqui_IIBB201907_SUCURSALES ls, Establecimientos e
set ls.id_sucursal=e.id_establecimiento 
where e.nro_cuit=ls.CUIT AND e.direccion_establecimiento=ls.domicilio_comercial;


SELECT * 
FROM Establecimientos e, Comercios c 
where e.id_comercio=c.id_comercio and (e.id_establecimiento=219 OR e.id_establecimiento=351);

-- agrego nro_cuit a Establecimientos para simplificar migratio
UPDATE Establecimientos e, Comercios c
set e.nro_cuit=c.nro_cuit 
WHERE e.id_comercio=c.id_comercio;

SELECT e.nro_cuit, e.direccion_establecimiento, e.id_establecimiento 
FROM Establecimientos e, Liqui_IIBB201907_SUCURSALES l 
where e.nro_cuit=l.CUIT AND e.direccion_establecimiento=l.domicilio_comercial;

SELECT e.id_establecimiento, ls.*
FROM Establecimientos e, Liqui_IIBB201907_SUCURSALES ls
WHERE e.id_establecimiento=ls.id_sucursal and e.activo;

-- agrego los registros de sucursales a EstablecimientosLiquiMes
INSERT INTO EstablecimientosLiquiMes (id_establecimiento, base_imponible, alicuota_iibb, percepcion_iibb, periodo)
SELECT e.id_establecimiento, ls.base_imponible, ls.alicuota_iibb, ls.percepcion_iibb, '201907' 
FROM Establecimientos e, Liqui_IIBB201907_SUCURSALES ls
WHERE e.id_establecimiento=ls.id_sucursal ;

-- activo los establecimientos con sucursales que tuvieron actividad 
UPDATE Establecimientos e, Liqui_IIBB201907_SUCURSALES ls
set e.activo=TRUE
WHERE e.id_establecimiento=ls.id_sucursal;

SELECT e.id_establecimiento, e.activo FROM Establecimientos e, Liqui_IIBB201907_SUCURSALES ls
WHERE e.id_establecimiento=ls.id_sucursal;


============
MIGRATIO  IVA

SELECT * FROM Establecimientos WHERE not activo_iva;

SELECT CUIT, ls.id_sucursal, ls.base_imponible, 21, ls.compra_iva, ls.percepcion_iva, '201907', ls.SaldoDDJJIVA 
FROM Liqui_IVA201907_unicos ls
ORDER by 1 ;

UPDATE EstablecimientosLiquiMes
set periodo='201907' where periodo='201909';

UPDATE EstablecimientosLiquiMes em, Establecimientos e
set periodo='201909' 
where e.id_establecimiento=em.id_establecimiento and e.activo_iva;


SELECT e.activo_iva, em.* from EstablecimientosLiquiMes em, Establecimientos e
where e.id_establecimiento=em.id_establecimiento and e.activo_iva;

SELECT * FROM Liqui_IVA201907_sucursales;

SELECT CUIT, Titular, Domicilio_Comercial, base_imponible, SaldoDDJJIVA FROM Liqui_IVA201907_sucursales;


DELETE FROM Liqui_IVA201907_sucursales where N_Comercio=0;

SELECT e.id_establecimiento, ls.CUIT
FROM Establecimientos e, Liqui_IVA201907_sucursales ls, Comercios c
WHERE e.direccion_establecimiento=ls.Domicilio_Comercial AND c.nro_cuit=ls.CUIT and ls.CUIT in (SELECT cuit FROM Liqui_IVA201907_sucursales);

SELECT e.id_establecimiento, ls.CUIT, e.direccion_establecimiento, e.zona
FROM Establecimientos e, Liqui_IVA201907_sucursales ls
WHERE e.direccion_establecimiento=ls.Domicilio_Comercial AND e.id_comercio=ls.id_comercio;


SELECT e.id_establecimiento, ls.CUIT, COUNT(*)
FROM Establecimientos e, Liqui_IVA201907_sucursales ls
WHERE e.direccion_establecimiento=ls.Domicilio_Comercial 
GROUP by e.id_establecimiento, ls.CUIT
HAVING COUNT(*)>1;

SELECT ls.CUIT, ls.Titular, ls.Domicilio_Comercial
FROM Liqui_IVA201907_sucursales ls, Comercios c
WHERE c.nro_cuit=ls.CUIT;

UPDATE Liqui_IVA201907_sucursales ls, Comercios c
set ls.id_comercio=c.id_comercio
WHERE c.nro_cuit=ls.CUIT;

UPDATE Liqui_IVA201907_sucursales ls, Establecimientos e
set ls.id_sucursal=e.id_establecimiento
WHERE ls.Domicilio_Comercial=e.direccion_establecimiento AND ls.id_comercio=e.id_comercio;


INSERT INTO EstablecimientosLiquiMes (id_establecimiento, base_imponible, alicuota_iva, compra_iva, percepcion_iva, periodo)
SELECT ls.id_sucursal, ls.base_imponible, 21, ls.compra_iva, ls.percepcion_iva, '201909' 
FROM Liqui_IVA201907_unicos ls;

SELECT ls.id_sucursal, ls.base_imponible, 21, ls.compra_iva, ls.percepcion_iva, '201909' 
FROM Liqui_IVA201907_sucursales ls WHERE ls.id_sucursal in (SELECT id_sucursal FROM Liqui_IVA201907_unicos);



SELECT COUNT(*) FROM Establecimientos WHERE activo_iva;

UPDATE Establecimientos e
set e.activo_iva=TRUE
WHERE e.id_establecimiento in (SELECT id_sucursal FROM Liqui_IVA201907_sucursales)

select e.activo_iva, e.id_establecimiento from Establecimientos e
WHERE e.id_establecimiento in (SELECT id_sucursal FROM Liqui_IVA201907_sucursales)

select * FROM EstablecimientosLiquiMes where 

select * from Establecimientos where activo_iibb or activo_iva;

SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, 
em.base_imponible, em.compra_iva, em.percepcion_iva, e.id_zona, (SELECT COUNT(*) 
 FROM EstablecimientosLiquiMes eem, Establecimientos ee 
 WHERE periodo='201909' 
   AND eem.id_establecimiento=ee.id_establecimiento 
   AND ee.id_comercio=e.id_comercio and e.activo_iva) 
 FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
 WHERE c.id_comercio = e.id_comercio 
 AND e.id_establecimiento=em.id_establecimiento 
 AND em.periodo ='201909' and e.activo_iva
 ORDER BY c.nro_cuit, e.id_zona

select * FROM Establecimientos where activo_iva;
select * FROM Establecimientos where activo_iibb;

select * FROM Establecimientos;
select * FROM Comercios;
select * FROM EstablecimientosLiquiMes;



SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, 
em.base_imponible, em.compra_iva, em.percepcion_iva, e.id_zona 
 FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
 WHERE c.id_comercio = e.id_comercio 
 AND e.id_establecimiento=em.id_establecimiento 
 AND em.periodo ='201909' and e.activo_iva
 ORDER BY c.nro_cuit, e.id_zona
 
 
 update EstablecimientosLiquiMes set periodo='201905' WHERE id_establecimiento in (SELECT id_sucursal from Liqui_IVA201907_sucursales)
 
 TRUNCATE EstablecimientosLiquiMes;

select ls.id_sucursal FROM Liqui_IIBB201907_SUCURSALES ls;

select ls.id_sucursal FROM Liqui_IIBB201907_SUCURSALES ls, EstablecimientosLiquiMes em where em.id_establecimiento=ls.id_sucursal;
 
UPDATE EstablecimientosLiquiMes em, Liqui_IIBB201907_SUCURSALES ls
set em.alicuota_iibb=ls.alicuota_iibb, em.percepcion_iibb=ls.percepcion_iibb
WHERE em.id_establecimiento=ls.id_sucursal;

select ls.* FROM Liqui_IIBB201907_unicos ls;

select ls.CUIT, ls.idComercio, c.id_comercio , c.nombre_responsable, ls.`Domicilio Comercial`, c.domicilio_fiscal
FROM Liqui_IIBB201907_unicos ls, Comercios c
WHERE ls.CUIT=c.nro_cuit;

UPDATE Liqui_IIBB201907_unicos ls, Comercios c
set ls.idComercio=c.id_comercio
where ls.CUIT=c.nro_cuit;

select ls.CUIT, ls.idComercio, ls.`Domicilio Comercial`
FROM Liqui_IIBB201907_unicos ls, Establecimientos e
WHERE e.id_comercio=ls.idComercio and e.direccion_establecimiento=ls.`Domicilio Comercial`;

update Liqui_IIBB201907_unicos ls, Establecimientos e
set ls.id_sucursal=e.id_establecimiento
WHERE e.id_comercio=ls.idComercio and e.direccion_establecimiento=ls.`Domicilio Comercial`;

select *
from Liqui_IIBB201907_unicos where id_sucursal not in (select id_establecimiento from EstablecimientosLiquiMes)

INSERT INTO EstablecimientosLiquiMes (id_establecimiento, base_imponible, alicuota_iibb, percepcion_iibb, periodo)
SELECT ls.id_sucursal, ls.base_imponible, ls.alícuota_iibb, ls.percepcion_iibb, '201909'
FROM Liqui_IIBB201907_unicos ls WHERE ls.id_sucursal in (343, 99, 69);

SELECT *
FROM EstablecimientosLiquiMes WHERE id_establecimiento in (343, 99, 69);

update Liqui_IIBB201907_unicos ls, Establecimientos e
set ls.id_sucursal=e.id_establecimiento
WHERE e.id_comercio=ls.idComercio and e.direccion_establecimiento=ls.`Domicilio Comercial`;

UPDATE EstablecimientosLiquiMes em, Liqui_IIBB201907_unicos ls
set em.alicuota_iibb=ls.alícuota_iibb, em.percepcion_iibb=ls.percepcion_iibb
WHERE em.id_establecimiento=ls.id_sucursal;

SELECT cuit, ls.base_imponible, em.base_imponible
FROM EstablecimientosLiquiMes em, Liqui_IVA201907_unicos ls
WHERE ls.id_sucursal=em.id_establecimiento and ls.base_imponible=em.base_imponible; *

SELECT * FROM Establecimientos WHERE activo_iibb and not activo_iva;
SELECT * FROM Establecimientos WHERE not activo_iibb and activo_iva;

SELECT * FROM Liqui_IIBB201907_SUCURSALES bs, Liqui_IIBB201907_unicos bu, Liqui_IVA201907_sucursales vs, Liqui_IVA201907_unicos vu
where bs.CUIT='27-94266082-6' or bu.CUIT='27-94266082-6' or vs.CUIT='27-94266082-6' or vu.CUIT='27-94266082-6'

SELECT * FROM Liqui_IIBB201907_SUCURSALES WHERE CUIT='27-94266082-6';
SELECT * FROM Liqui_IIBB201907_unicos WHERE CUIT='27-94266082-6';
SELECT * FROM Liqui_IVA201907_sucursales WHERE CUIT like '27-%';
SELECT * FROM Liqui_IVA201907_unicos WHERE CUIT='27-94266082-6';

select * from Zonas;
select * from Localidades;

select * from Establecimientos;
select zona, id_zona from Establecimientos;

select * from EstablecimientosLiquiMes;

select count(*), cuit, CondicinIIBB from Comercios_old
GROUP BY cuit
HAVING COUNT(*)>1;

select * from Comercios;
select * from Comercios_old;
select * from Liqui_IIBB201907_SUCURSALES;

SELECT cuit, NombreResponsable from Comercios_old WHERE cuit not in (SELECT nro_cuit from Comercios); 

update Establecimientos set id_zona=3 where zona='LANUS';
update Establecimientos set id_zona=2 where zona='ZONAS VARIAS';
update Establecimientos set id_zona=5 where zona='SAAVEDRA';
update Establecimientos set id_zona=6 where zona='MICROCENTRO';
update Establecimientos set id_zona=7 where zona='SAN JUSTO';
update Establecimientos set id_zona=4 where zona='SAN MARTIN';
update Establecimientos set id_zona=8 where zona='CAMINANDO';
update Establecimientos set id_zona=9 where zona='MATADEROS';
update Establecimientos set id_zona=10 where zona='Belgrano';

SELECT * FROM Establecimientos where zona like'B%';

-- query definitivo para que tambien aparezcan en listado por zona los establecimientos del mismo comercio que estan en otra zona
SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, 
em.base_imponible, em.compra_iva, em.percepcion_iva, e.id_zona, (SELECT COUNT(*) 
 		FROM EstablecimientosLiquiMes eem, Establecimientos ee 
 		WHERE periodo='201909' -- and ee.id_zona=9
  		  AND eem.id_establecimiento=ee.id_establecimiento 
 		  AND ee.id_comercio=e.id_comercio and e.activo_iva) 
 FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
 WHERE c.id_comercio = e.id_comercio and e.id_comercio in (SELECT ee.id_comercio 
 		FROM EstablecimientosLiquiMes eem, Establecimientos ee 
 		WHERE periodo='201909' and ee.id_zona=3
  		  AND eem.id_establecimiento=ee.id_establecimiento 
 		  AND e.activo_iva) 
 AND e.id_establecimiento=em.id_establecimiento 
 AND em.periodo ='201909' and e.activo_iva
 ORDER BY c.nro_cuit

SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, 
em.base_imponible, em.percepcion_iibb, em.saldo_iibb, e.id_zona, (SELECT COUNT(*) 
 		FROM EstablecimientosLiquiMes eem, Establecimientos ee 
 		WHERE periodo='201909' -- and ee.id_zona=9
  		  AND eem.id_establecimiento=ee.id_establecimiento 
 		  AND ee.id_comercio=e.id_comercio and e.activo_iibb) 
 FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
 WHERE c.id_comercio = e.id_comercio and e.id_comercio in (SELECT ee.id_comercio 
 		FROM EstablecimientosLiquiMes eem, Establecimientos ee 
 		WHERE periodo='201909' and ee.id_zona=3
  		  AND eem.id_establecimiento=ee.id_establecimiento 
 		  AND e.activo_iibb) 
 AND e.id_establecimiento=em.id_establecimiento 
 AND em.periodo ='201909' and e.activo_iibb 
 ORDER BY c.nro_cuit
 
 
 SELECT c.nro_cuit, razon_social, c.nombre_responsable, apellido_responsable, c.id_zona, c.id_localidad, c.nro_telefono, c.email , 
 	SUM(em.base_imponible), SUM(em.percepcion_iibb), SUM(em.base_imponible-em.base_imponible*em.alicuota_iibb/100)  
   FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em
    WHERE c.id_comercio=129 AND c.id_comercio=e.id_comercio and e.id_establecimiento=em.id_establecimiento;
  
   
   select * from Liqui_IIBB201907_unicos where Zona='Zonas Varias';
   SELECT * from Zonas;
  
  select * from Comercios_old WHERE CUIT='20-94474843-2';
  select * from Comercios WHERE nro_cuit='23-94474413-4';
  select id_comercio, nro_cuit, nombre_responsable, fecha_baja from Comercios WHERE year(fecha_baja)=0;
  select id_comercio, nro_cuit, nombre_responsable, fecha_baja from Comercios WHERE fecha_baja is null;
  select id_comercio, observaciones_comercio from Comercios WHERE nro_cuit='20-94474843-2';
  select * from Comercios WHERE condicion_iva not like 'R%' AND condicion_iva not like 'M%';
  select * from Comercios WHERE condicion_iva like 'R%';
  select nro_cuit, nombre_responsable, agencia_afip from Comercios WHERE agencia_afip != '';
  select * from Comercios_old WHERE AgenciaAfip != '';

SELECT * FROM Comercios_old WHERE CategoraAutnomo like 'D%'; 
SELECT * FROM Comercios_old WHERE CondicinIIBB like 'D%'; 
SELECT * FROM Comercios_old WHERE CondicinIVA like 'M%'; 

SELECT CUIT, NombreResponsable, CondicinIIBB, id_comercio 
FROM Comercios_old WHERE CondicinIIBB like 'D%'; 

SELECT condicion_iibb, COUNT(*)
FROM Comercios 
GROUP BY condicion_iibb; 

SELECT condicion_iibb, id_condicion_iibb, COUNT(*)
FROM Comercios 
GROUP BY condicion_iibb, id_condicion_iibb; 

SELECT condicion_iibb FROM Comercios WHERE condicion_iibb like 'reg%';

UPDATE Comercios SET id_condicion_iibb=2 WHERE condicion_iibb like 'reg%';

SELECT CondicinIIBB, COUNT(*)
FROM Comercios_old 
GROUP BY CondicinIIBB;

SELECT *
FROM Comercios_old 
WHERE CondicinIIBB like 'REG%'; 


SELECT condicion_iva, COUNT(*)
FROM Comercios 
GROUP BY condicion_iva; 

SELECT condicion_iva FROM Comercios WHERE condicion_iva like 'resp%';

UPDATE Comercios SET id_condicion_iva=2 WHERE condicion_iva like 'resp%';
==

SELECT c.id_comercio, nro_cuit, nombre_responsable, c.condicion_iibb, co.CondicinIIBB 
FROM Comercios c, Comercios_old co
WHERE c.id_comercio=co.id_comercio AND c.condicion_iibb!=co.CondicinIIBB

SELECT CondicinIIBB, Domicilio_Fiscal, Direccin_Comercial, Zona, Localidad, Provincia FROM Comercios_old WHERE cuit='20-95663851-9' ;

SELECT IFNULL(CondicinIIBB, 'null') as CondicinIIBB, COUNT(*)
FROM Comercios_old 
GROUP BY CondicinIIBB; 


====

SELECT GrupoActividaes, COUNT(*)
FROM Comercios_old
GROUP BY GrupoActividaes; 

SELECT c. , COUNT(*)
FROM Comercios c
GROUP BY abreviatura_iva; 


select * from Comercios_old WHERE GrupoActividaes like 'ot%';
select * from Comercios_old WHERE GrupoActividaes like 'ac%' and CUIT not in (select nro_cuit from Comercios WHERE tope_categoria_autonomo like '> a%');

select * from Comercios WHERE tope_categoria_autonomo like '> a%';
select * from Comercios WHERE nro_cuit='27-95115526-3';
select * from Comercios WHERE id_categ_autonomo>0  AND id_condicion_iva=1;
select * from Comercios_old WHERE CUIT='27-94829792-8';

select tope_categoria_autonomo from Comercios WHERE id_comercio=293;

UPDATE Comercios SET id_categ_autonomo=4 WHERE tope_categoria_autonomo like '> a%';
UPDATE Comercios SET id_categ_autonomo=6 WHERE nro_cuit='27-95115526-3';


===

SELECT CategoraMonotributo, COUNT(*)
FROM Comercios_old
GROUP BY CategoraMonotributo; 

SELECT CategoraMonotributo, CategAdic, COUNT(*)
FROM Comercios_old
GROUP BY CategoraMonotributo, CategAdic; 

select * from Comercios_old WHERE CategAdic='f';
select categoria_monotributo, categoria_adicional, COUNT(*) from Comercios GROUP BY categoria_monotributo, categoria_adicional ORDER BY 1;
select * from Comercios WHERE nro_cuit='20-11869618-3';
select * from Comercios WHERE categoria_monotributo like 'a%';
select * from Comercios WHERE id_categ_monotributo is not null;
select * from Comercios WHERE id_categ_monotributo=2;
select * from Comercios WHERE categoria_monotributo like 'b%' and categoria_adicional='Muebles';
select * from Comercios WHERE categoria_monotributo like 'c%' and categoria_adicional!='Serv';

UPDATE Comercios SET id_categ_monotributo=18 WHERE categoria_monotributo like 'g%' and categoria_adicional!='Muebles';
UPDATE Comercios SET id_categ_autonomo=0, id_categ_monotributo=12 WHERE nro_cuit='27-94829792-8';


-- UPDATE Comercios set fecha_baja=null WHERE YEAR(fecha_baja)=0;

==
-- parece ser que los monotributistas no aparecen en saldos IIBB
SELECT cuit from Comercios_old c, Establecimientos e, EstablecimientosLiquiMes em
WHERE c.id_comercio=e.id_comercio and em.id_establecimiento=e.id_establecimiento 
	and c.id_condicion_iva=1 and c.
	
SELECT c.cuit from Comercios_old c, Liqui_IIBB201907_unicos le
WHERE c.CUIT=le.CUIT and le.saldo_ddjj_iibb>0 and c.CondicinIVA like 'mo%';

SELECT c.cuit from Comercios_old c, Liqui_IVA201907_unicos le
WHERE c.CUIT=le.CUIT and le.SaldoDDJJIVA>=0 and c.CondicinIVA like 'R%';

SELECT * from Liqui_IVA201907_unicos;


========

SELECT e.id_establecimiento, e.id_actividad, e.nombre_establecimiento, e.direccion_establecimiento,
		e.id_zona, e.id_localidad, porcentaje_sociedad, nro_telefono_establecimiento, email_establecimiento,
        em.base_imponible, em.percepcion_iibb, em.percepcion_iva
FROM Establecimientos e, EstablecimientosLiquiMes em
WHERE e.id_comercio=9 and e.id_establecimiento=em.id_establecimiento and em.periodo='201909';
                     
SELECT * FROM Establecimientos WHERE id_comercio=12;

SELECT em.periodo, e.id_establecimiento, e.id_actividad, e.nombre_establecimiento, e.direccion_establecimiento,
		e.id_zona, e.id_localidad, porcentaje_sociedad, nro_telefono_establecimiento, email_establecimiento,
        em.base_imponible, em.percepcion_iibb, em.percepcion_iva
FROM Establecimientos e
LEFT JOIN EstablecimientosLiquiMes em ON e.id_establecimiento=em.id_establecimiento
where  e.id_comercio=12
order by 1;
                                        
update EstablecimientosLiquiMes em set saldo_iibb=em.alicuota_iibb*em.base_imponible/100-em.percepcion_iibb;
update EstablecimientosLiquiMes em set saldo_iva=em.alicuota_iva*em.base_imponible/100-em.compra_iva-em.alicuota_iva*em.base_imponible/100;

select em.base_imponible-em.alicuota_iibb*em.base_imponible/100-em.percepcion_iibb as 'saldo' from EstablecimientosLiquiMes em WHERE em.percepcion_iibb =0;

select c.nro_cuit, base_imponible, alicuota_iibb, percepcion_iibb, saldo_iibb,
FORMAT (em.alicuota_iibb*em.base_imponible/100-em.percepcion_iibb, 2, 'de_DE')  as 'saldo'
from EstablecimientosLiquiMes em, Establecimientos e, Comercios c 
where e.id_establecimiento=em.id_establecimiento AND e.id_zona=9 AND c.id_comercio=e.id_comercio
ORDER by 1;



==============
-- actualizacion datos de reportes en EstablecimientosLiquiMes

UPDATE EstablecimientosLiquiMes em set alicuota_pago_facil=8;
UPDATE EstablecimientosLiquiMes em set reporte_ameca_comision=500;
UPDATE Establecimientos set nro_pago_facil=127 WHERE id_comercio=108;

SELECT * FROM Liqui_IIBB201907_unicos;
SELECT * FROM Liqui_IVA201907_unicos;
SELECT * FROM Comercios_old WHERE CUIT like '23-952433%';

SELECT * FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
WHERE c.id_comercio=108 AND c.id_comercio=e.id_comercio AND e.id_establecimiento=em.id_establecimiento;

UPDATE EstablecimientosLiquiMes em set reporte_gan=0, reporte_afip_esp=0, reporte_suss=43585.77 
where id_establecimiento_mes=80;

SELECT e.id_establecimiento, c.id_categ_monotributo, c.id_categ_autonomo, c.id_condicion_iibb, c.id_condicion_iva, 
		c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, e.id_zona, e.nro_pago_facil, em.alicuota_pago_facil,
		em.saldo_iva, em.saldo_iibb, em.reporte_gan, em.reporte_afip_esp, em.reporte_suss, 
		@subtotal := (em.saldo_iva+ em.saldo_iibb+ em.reporte_gan+ em.reporte_afip_esp+ em.reporte_suss) as 'subtotal',
		@subtotal*em.alicuota_pago_facil/100 as 'pago facil', em.reporte_ameca_comision, @subtotal+@subtotal*em.alicuota_pago_facil/100 + em.reporte_ameca_comision as 'total'
FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em, CategoriasAutonomo ca 
WHERE e.id_establecimiento=126 AND c.id_comercio=e.id_comercio AND e.id_establecimiento=em.id_establecimiento 
		AND c.id_categ_autonomo=ca.id_categoria_autonomo;

SELECT * FROM EstablecimientosLiquiMes WHERE id_establecimiento_mes=80;
SELECT * from Establecimientos WHERE id_comercio=108;
SELECT * from Establecimientos WHERE direccion_establecimiento like '25%';
SELECT * from Comercios WHERE id_comercio=108;
SELECT id_condicion_iva, id_categ_autonomo, id_categ_monotributo from Comercios WHERE id_comercio=108;

SELECT * FROM CategoriasMonotributo;

UPDATE Comercios set id_categ_monotributo=0 WHERE id_categ_monotributo is null;

SELECT * from Comercios WHERE id_categ_monotributo is null;

DELETE FROM CategoriasMonotributo WHERE id_categoria_monotributo=23;


SELECT id_comercio, razon_social, nro_cuit FROM Comercios 
WHERE nro_cuit like '20-94474843-2%'; 

select * from Localidades  WHERE localidad='CABA';
select * from Localidades  WHERE localidad like 'VILLA D%';
select l.IdLocalidad, l.Localidad, p.Provincia 
from Localidades l, Provincias p 
WHERE l.IdProvincia=p.IdProvincia 
ORDER BY 1;

select l.IdLocalidad, l.Localidad, p.Provincia, COUNT(*) 
from Localidades l, Provincias p, Establecimientos e 
WHERE l.IdProvincia=p.IdProvincia AND e.localidad=l.Localidad
GROUP BY l.IdLocalidad, l.Localidad, p.Provincia
ORDER by 4 DESC;

select id_localidad, COUNT(*) 
from Establecimientos 
GROUP BY id_localidad
ORDER by 2 DESC;
select * from Establecimientos WHERE localidad='CABA' ;

select * from Provincias;
select * from Zonas;

SELECT id_establecimiento, razon_social, c.nombre_responsable, nro_cuit, direccion_establecimiento 
FROM Comercios c, Establecimientos e 
WHERE c.id_comercio=e.id_comercio AND direccion_establecimiento like '25%';


-- query que hace updates de reportes
UPDATE EstablecimientosLiquiMes 
SET reporte_gan=0.0, reporte_afip_esp=0.0, reporte_suss=43585.77, reporte_ameca_comision=55, reporte_observacion='era 500 la comsion ameca' 
WHERE id_establecimiento=126 AND periodo='201909'

SELECT * FROM EstablecimientosLiquiMes WHERE id_establecimiento=126 AND periodo='201909';

UPDATE EstablecimientosLiquiMes 
SET reporte_gan=0.0, reporte_afip_esp=0.0, reporte_suss=43585.77, reporte_ameca_comision=500, reporte_observacion='' 
WHERE id_establecimiento=126 AND periodo='201909'

====

SELECT * from Establecimientos  WHERE id_zona >8;
SELECT * from Establecimientos  WHERE id_establecimiento=41;
SELECT * from Establecimientos  WHERE id_localidad is null;
SELECT * from Establecimientos  WHERE id_localidad =307;
SELECT * from Establecimientos  WHERE localidad ='Remedios de escalada';

SELECT id_zona, zona from Establecimientos  WHERE id_zona is null;
SELECT id_localidad, localidad, id_zona from Establecimientos  WHERE id_localidad is null order by 2;
SELECT id_localidad, localidad from Establecimientos  WHERE localidad ='Remedios de Escalada';
SELECT direccion_establecimiento, id_localidad, e.localidad 
from Establecimientos e, Localidades l  
WHERE l.Localidad=e.localidad AND e.localidad='CABA';

UPDATE Establecimientos set id_zona=2 WHERE id_zona is null;
UPDATE Establecimientos set localidad='CABA' WHERE localidad='CAPITAL';
UPDATE Establecimientos set id_localidad='44' WHERE localidad='MATADEROS';
UPDATE Establecimientos set id_zona='3' WHERE id_localidad=307;
UPDATE Establecimientos e, Localidades l set e.id_localidad=l.IdLocalidad 
WHERE e.localidad=l.Localidad and e.id_localidad is NULL;

SELECT e.id_establecimiento, e.localidad, l.Localidad, e.id_localidad, e.direccion_establecimiento 
FROM Establecimientos e, Localidades l  
WHERE e.localidad=l.Localidad and e.id_localidad is NULL
ORDER BY 2;


SELECT DISTINCT e.id_establecimiento 
FROM Establecimientos e, Localidades l  
WHERE e.localidad=l.Localidad and e.id_localidad is NULL;

SELECT id_localidad, localidad from Establecimientos  WHERE localidad like'ciudad%';
SELECT id_localidad, localidad from Establecimientos  WHERE id_localidad=57;
SELECT id_localidad, localidad, id_zona from Establecimientos  WHERE id_localidad is null order by localidad;
SELECT id_localidad, localidad, id_zona from Establecimientos  WHERE id_localidad=5;

UPDATE Establecimientos set id_localidad='319' WHERE localidad like 'Villa el%';
UPDATE Establecimientos set localidad='CABA' WHERE id_localidad =44;

INSERT INTO Localidades (localidad, CódigoPostal, IdProvincia) VALUES ('Villa Elvira', 1877, 2);

SELECT * FROM Provincias;
SELECT * FROM Localidades WHERE Localidad LIKE 'merl%';
SELECT * FROM Establecimientos WHERE Localidad LIKE 'merl%';
SELECT * FROM EstablecimientosLiquiMes;

SELECT e.id_localidad, e.localidad, id_zona, p.Provincia 
FROM Establecimientos e, Localidades l, Provincias p 
WHERE e.id_localidad=l.IdLocalidad AND l.IdProvincia=p.IdProvincia AND id_localidad !=44;
SELECT id_localidad, localidad, id_zona FROM Establecimientos WHERE id_localidad=44 ;
SELECT * FROM Localidades WHERE IdLocalidad>311;

SELECT p.Provincia, COUNT(*) 
FROM Establecimientos e, Localidades l, Provincias p 
WHERE e.id_localidad=l.IdLocalidad AND l.IdProvincia=p.IdProvincia
GROUP BY p.Provincia;

SELECT (CASE id_localidad WHEN 44 THEN 44 ELSE 2 END) as 'localidad', COUNT(*) 
FROM Establecimientos 
GROUP BY (CASE id_localidad WHEN 44 THEN 44 ELSE 2 END)
ORDER by 2 DESC;

SELECT @localidad:= (CASE id_localidad WHEN 44 THEN 44 ELSE 2 END) as 'g21', COUNT(*)
FROM Establecimientos 
 GROUP BY g21
 ORDER by 1 DESC;



SELECT * FROM Localidades WHERE localidad LIKE 'aba%';
SELECT * FROM Localidades WHERE IdLocalidad=5

SELECT IdLocalidad, localidad, l.IdProvincia, provincia
from Localidades l, Provincias p WHERE p.IdProvincia=l.IdProvincia 
ORDER BY 2;

SELECT IdLocalidad, localidad, l.IdProvincia, provincia
from Localidades l, Provincias p WHERE p.IdProvincia=l.IdProvincia and p.IdProvincia=25;

-- ALTER TABLE dbAmeca.EstablecimientosLiquiMes MODIFY COLUMN alicuota_iva decimal(3,1) DEFAULT 21.0 NOT NULL;
ALTER TABLE dbAmeca.EstablecimientosLiquiMes MODIFY COLUMN alicuota_iibb CHAR(4) DEFAULT '3.5' NOT NULL;

SELECT * FROM EstablecimientosLiquiMes LIMIT 4;


=======

select id_localidad, id_zona FROM Comercios -- WHERE id_comercio=170;

UPDATE Comercios c, Establecimientos e 
set c.id_localidad=e.id_localidad, c.id_zona=55 where e.id_comercio=c.id_comercio and e.direccion_establecimiento=c.domicilio_fiscal;

UPDATE Comercios c, Establecimientos e 
set c.id_localidad=e.id_localidad, c.id_zona=55 where e.id_comercio=c.id_comercio and SUBSTRING(c.domicilio_fiscal,1,5)=SUBSTRING(e.direccion_establecimiento,1,5);

UPDATE Comercios c, Establecimientos e 
set c.id_localidad=e.id_localidad, c.id_zona=55 where e.id_comercio=c.id_comercio and c.id_zona!=55  ;

SELECT * FROM Comercios c, Establecimientos e
where e.id_comercio=c.id_comercio and e.direccion_establecimiento=c.domicilio_fiscal;


SELECT * FROM Comercios;
SELECT * FROM Comercios WHERE id_zona!=55;

SELECT c.domicilio_fiscal, c.id_localidad, e.direccion_establecimiento, e.id_localidad 
FROM Comercios c, Establecimientos e 
WHERE e.id_comercio=c.id_comercio and c.id_zona!=55  and SUBSTRING(c.domicilio_fiscal,1,5)=SUBSTRING(e.direccion_establecimiento,1,5);

SELECT c.domicilio_fiscal, c.id_localidad, e.direccion_establecimiento, e.id_localidad 
FROM Comercios c, Establecimientos e 
WHERE e.id_comercio=c.id_comercio and c.id_zona!=55  ;

SELECT c.domicilio_fiscal, c.id_localidad, e.direccion_establecimiento, e.id_localidad 
FROM Comercios c, Establecimientos e 
WHERE e.id_comercio=c.id_comercio and c.id_zona=55 and e.id_localidad!=c.id_localidad;

SELECT * FROM Zonas;
SELECT * FROM Provincias;
SELECT * FROM Localidades where id_provincia=25 or id_provincia=2 order by 2;
SELECT * FROM Localidades order by 1;
SELECT * FROM Actividades order by 1;
SELECT * FROM CondicionesIVA;
SELECT * FROM CategoriasAutonomo;
SELECT * FROM CategoriasMonotributo;


-- UPDATE Comercios set id_localidad=1 WHERE id_localidad=44;

SELECT * FROM Establecimientos WHERE id_localidad=44;

==== averiguar si comercio 170 tiene actividad comercial, ie, saldo iibb o saldo iva (ie, si hay un registro con algun id_establecimiento del id_comercio en EstablecimientosLiquiMes para el periodo vigente)

SELECT * FROM Establecimientos e, EstablecimientosLiquiMes em
WHERE e.id_establecimiento=em.id_establecimiento and e.id_comercio=170;

SELECT activo_iibb, activo_iva, id_establecimiento FROM Establecimientos WHERE id_comercio=170;

SELECT * from Comercios WHERE id_comercio=108;
-- UPDATE Comercios SET id_condicion_iibb=1, id_condicion_iva=2, id_categ_monotributo=0, id_categ_autonomo=4 
-- WHERE id_comercio=108

SELECT * from Establecimientos WHERE id_establecimiento =205;

select * from Establecimientos where cuit='20-95294143-8';


===============

CREATE TABLE `Comercios2` (
  `id_comercio` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `razon_social` varchar(70) COLLATE latin1_spanish_ci NOT NULL DEFAULT 'NN' COMMENT 'nombre del comercio',
  `nombre_responsable` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT 'NN',
  `nro_cuit` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '--',
  `domicilio_fiscal` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `nro_telefono` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nro_telefono2` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nro_telefono3` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `codigo_postal` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `id_localidad` smallint(5) unsigned NOT NULL DEFAULT '1',
  `id_zona` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `email` varchar(70) CHARACTER SET utf8 DEFAULT NULL,
  `Mail2` varchar(70) CHARACTER SET utf8 DEFAULT NULL,
  `fecha_alta` date DEFAULT NULL,
  `fecha_baja` date DEFAULT NULL,
  `fecha_inauguracion` datetime DEFAULT NULL,
  `cantidad_empleados` char(1) CHARACTER SET utf8 DEFAULT '-',
  `observaciones_comercio` longtext COLLATE latin1_spanish_ci,
  `agencia_afip` varchar(120) COLLATE latin1_spanish_ci DEFAULT '-',
  `id_condicion_iva` tinyint(3) unsigned DEFAULT NULL,
  `id_condicion_iibb` tinyint(3) unsigned DEFAULT NULL,
  `id_categ_monotributo` tinyint(3) unsigned DEFAULT NULL,
  `id_categ_autonomo` tinyint(3) unsigned DEFAULT NULL,
  `abl_inmobiliario` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  UNIQUE KEY `Comercios2_id_comercio_IDX` (`id_comercio`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=326 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci COMMENT='';


SELECT * from Comercios2;

INSERT INTO Comercios2 (nro_cuit, razon_social, nombre_responsable, domicilio_fiscal, id_localidad, 
						nro_telefono, email, fecha_alta, fecha_baja, codigo_postal, nro_telefono2, 
						observaciones_comercio) 
VALUES ('12222321', 'NN', 'Chen', 'Constitucion 2314', 2, '111111', 'f@f', CURRENT_DATE, NULL, '', '2222222', 'obs');

INSERT INTO Comercios2 (nro_cuit, razon_social, nombre_responsable, domicilio_fiscal, id_localidad, nro_telefono, email, fecha_alta, fecha_baja, codigo_postal, nro_telefono2, observaciones_comercio) 
VALUES ('cuiy', 'NN', 'Manuel', 'Rucci 2423', 2, '111111', 'f@f', CURRENT_DATE, NULL, '1020', '2222222', 'obsaw');

SELECT * from Comercios WHERE nro_cuit='23-24963650-9';
SELECT * FROM Establecimientos WHERE id_comercio=326;
SELECT * FROM Establecimientos WHERE cuit is null;

UPDATE Establecimientos set activo_iva=1, activo_iibb=1 WHERE id_comercio=326;

-- ALTER TABLE dbAmeca.Establecimientos MODIFY COLUMN nro_pago_facil VARCHAR(7) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL COMMENT 'se usa para el reporte';

select * from Comercios_old WHERE CUIT='20-94474843-2';

SELECT * from EstablecimientosLiquiMes where id_establecimiento=366 ;
SELECT saldo_iibb, saldo_iva, id_establecimiento from EstablecimientosLiquiMes ;
SELECT * from Establecimientos where id_establecimiento=367;
SELECT activo_iibb, activo_iva from Establecimientos where id_comercio=326;
SELECT * from Comercios where id_comercio=326;
-- UPDATE Establecimientos set activo_iibb=1, activo_iva=1 where id_establecimiento=367;

select distinct id_comercio, activo_iva, activo_iibb from Establecimientos WHERE activo_iibb=1 AND activo_iva=1; 
select distinct id_comercio, activo_iva, activo_iibb from Establecimientos WHERE activo_iibb=0 AND activo_iva=1; 
select distinct id_comercio, activo_iva, activo_iibb from Establecimientos WHERE activo_iibb=1 AND activo_iva=0; 
select distinct id_comercio, activo_iva, activo_iibb from Establecimientos WHERE activo_iibb=0 AND activo_iva=0; 

select e.id_comercio, c.id_condicion_iva, c.id_condicion_iibb, c.id_categ_monotributo, e.activo_iva, e.activo_iibb, e.fecha_baja
FROM Establecimientos e, Comercios c 
WHERE e.id_comercio = c.id_comercio AND c.id_condicion_iva=1;

select e.id_comercio, e.activo_iva, e.activo_iibb, e.fecha_baja
FROM Establecimientos e, Comercios c 
WHERE e.id_comercio = c.id_comercio AND c.id_condicion_iva=1;


========= liquidaciones FINAL

SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, em.base_imponible, em.compra_iva, 
       em.percepcion_iva, e.id_zona, em.saldo_iva, em.alicuota_iva,
       (SELECT COUNT(*) FROM EstablecimientosLiquiMes eem, Establecimientos ee 
        WHERE periodo='201909' AND eem.id_establecimiento=ee.id_establecimiento AND ee.id_comercio=e.id_comercio AND ee.activo_iva=1 AND c.id_condicion_iva!=1) as 'sucursales'
FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
WHERE c.id_comercio = e.id_comercio AND e.id_establecimiento=em.id_establecimiento AND em.periodo ='201909' 
	AND e.activo_iva=1 AND c.id_condicion_iva!=1
ORDER BY c.nro_cuit, e.id_zona; -- 230

SELECT * FROM Liqui_IVA201907_unicos;  -- 177
select * from Liqui_IVA201907_sucursales; -- 52  => 229
SELECT * from Liqui_IVA201907_sucursales where Zona LIKE 'cam%' ORDER BY 2; -- 12
SELECT * FROM Liqui_IVA201907_unicos where Zona LIKE 'cam%' ORDER BY 2;  -- 25 

SELECT COUNT(*) FROM EstablecimientosLiquiMes eem, Establecimientos ee 
WHERE periodo='201909' AND eem.id_establecimiento=ee.id_establecimiento AND ee.id_comercio=326 AND ee.activo_iva=1;
        
====  iibb

SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, em.base_imponible, em.percepcion_iibb, 
		em.saldo_iibb, em.alicuota_iibb, e.id_zona, 
		(SELECT COUNT(*) FROM EstablecimientosLiquiMes eem, Establecimientos ee
		 WHERE periodo='201909' AND eem.id_establecimiento=ee.id_establecimiento 
				AND ee.id_comercio=e.id_comercio and ee.activo_iibb=1 and ee.id_zona=3) as 'sucursales'
FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em
WHERE c.id_comercio = e.id_comercio  AND e.activo_iibb=1 and e.id_zona=3
	AND e.id_establecimiento=em.id_establecimiento AND periodo='201909' 
ORDER BY nro_cuit;

SELECT * from Liqui_IIBB201907_SUCURSALES; -- 50
SELECT * FROM Liqui_IIBB201907_unicos;  -- 176   => 226
SELECT * from Liqui_IIBB201907_SUCURSALES where Zona LIKE 'cam%' ORDER BY 2; -- 12
SELECT * FROM Liqui_IIBB201907_unicos where Zona LIKE 'cam%' ORDER BY 2;  -- 25 

SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, em.base_imponible, 
em.percepcion_iibb, em.saldo_iibb, em.alicuota_iibb, e.id_zona, 
(SELECT COUNT(*) FROM EstablecimientosLiquiMes eem, Establecimientos ee 
	WHERE eem.periodo='201909' AND ee.id_zona=2 AND eem.id_establecimiento=ee.id_establecimiento AND ee.id_comercio=e.id_comercio 
		and ee.activo_iibb=1 and c.id_condicion_iibb not in (2, 4, 5)) as 'sucursales' 
FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
WHERE c.id_comercio = e.id_comercio AND e.activo_iibb AND e.id_zona=2 AND e.id_establecimiento=em.id_establecimiento 
	AND em.periodo='201909' and c.id_condicion_iibb not in (2, 4, 5) 
ORDER BY nro_cuit, e.id_zona 


=======

SELECT MAX(periodo) from EstablecimientosLiquiMes;


=======  listado de ddjj s por comercio

SELECT elm.base_imponible, elm.compra_iva, elm.percepcion_iva, elm.percepcion_iibb, e.nombre_establecimiento, 
		e.direccion_establecimiento, e.id_zona, e.id_localidad, elm.alicuota_iva, elm.alicuota_iibb, 
		elm.saldo_iva, elm.saldo_iibb 
FROM EstablecimientosLiquiMes elm, Establecimientos e 
WHERE elm.periodo = '201908' AND elm.id_establecimiento = e.id_establecimiento AND e.id_comercio=326


=======

SELECT alicuota_iibb_provincia, alicuota_iibb_caba, alicuota_iva, alicuota_pago_facil, comision_pago_facil FROM Parametros;

select * from EstablecimientosLiquiMes WHERE id_establecimiento=16;


========  cambio de periodo

SELECT id_establecimiento, base_imponible*(1+10/100) as 'bi' , compra_iva*(1+10/100) as 'compra', percepcion_iva*(1+10/100) as 'pcp iva', 
  	   percepcion_iibb*(1+10/100) as 'pcp iibb', '201910'
FROM  EstablecimientosLiquiMes
WHERE periodo ='201909' ;

-- falta saldo iibb, saldo_iva, alic_iva, alic_iibb, y los campos parametrizados de reporte alic pago facil y comsion pf
SELECT em.id_establecimiento, base_imponible*(1+10/100) as 'bi' , compra_iva*(1+10/100) as 'compra', percepcion_iva*(1+10/100) as 'pcp iva', 
  	   percepcion_iibb*(1+10/100) as 'pcp iibb', '201910', em.saldo_iibb, em.saldo_iva, em.alicuota_iibb, em.alicuota_iva,
  	   em.alicuota_pago_facil, em.reporte_ameca_comision
FROM  EstablecimientosLiquiMes em, Establecimientos e
WHERE periodo ='201909' and e.id_establecimiento=em.id_establecimiento and (e.activo_iibb or e.activo_iva);

-- no incrementa porcentajes porque jode los saldos, si todas las variables se incrementan en el mismo %, el saldo tambien se incrementa ese %.
SELECT em.id_establecimiento, base_imponible , compra_iva, percepcion_iva, 
  	   percepcion_iibb, '201910', em.saldo_iibb, em.saldo_iva, em.alicuota_iibb, em.alicuota_iva,
  	   em.alicuota_pago_facil, em.reporte_ameca_comision
FROM  EstablecimientosLiquiMes em, Establecimientos e
WHERE periodo ='201909' and e.id_establecimiento=em.id_establecimiento and (e.activo_iibb or e.activo_iva);

SELECT base_imponible , percepcion_iibb, em.saldo_iibb, base_imponible*(1+10/100) as 'bi', percepcion_iibb*(1+10/100) as 'pcp iibb', 
		saldo_iibb*(1+10/100) as 'saldo iibb', TRUNCATE(base_imponible*(1+10/100)*alicuota_iibb/100-percepcion_iibb*(1+10/100),2) as 'saldo2'
FROM  EstablecimientosLiquiMes em, Establecimientos e
WHERE periodo ='201909' and e.id_establecimiento=em.id_establecimiento and (e.activo_iibb or e.activo_iva);

-- iva
SELECT base_imponible , percepcion_iva, compra_iva, em.saldo_iva, base_imponible*(1+10/100) as 'bi 10%', percepcion_iva*(1+10/100) as 'pcp iva 10%', 
		TRUNCATE(saldo_iva*(1+10/100),2) as 'saldo iva 10%', TRUNCATE(base_imponible*(1+10/100)*alicuota_iva/100-percepcion_iva*(1+10/100)-compra_iva*(1+10/100)*alicuota_iva/100,2) as 'saldo2'
FROM  EstablecimientosLiquiMes em, Establecimientos e
WHERE periodo ='201909' and e.id_establecimiento=em.id_establecimiento and (e.activo_iibb or e.activo_iva);


-- INSERT INTO EstablecimientosLiquiMes (id_establecimiento, base_imponible, compra_iva, percepcion_iva, percepcion_iibb, periodo, saldo_iibb, saldo_iva, alicuota_iibb, alicuota_iva, alicuota_pago_facil, reporte_ameca_comision) 
SELECT em.id_establecimiento, base_imponible, compra_iva, percepcion_iva, percepcion_iibb, '201910', em.saldo_iibb, em.saldo_iva, em.alicuota_iibb, em.alicuota_iva, em.alicuota_pago_facil, em.reporte_ameca_comision 
FROM EstablecimientosLiquiMes em, Establecimientos e 
WHERE periodo ='201909' and e.id_establecimiento=em.id_establecimiento and (e.activo_iibb or e.activo_iva) 
