SELECT count(*) FROM iva_08_unicos LIMIT 1;

SELECT * FROM iva_08_unicos LIMIT 1;

SELECT * FROM iva_08_unicos where IdComercio in (375, 376);
SELECT * FROM iva_08_sucursales where IdComercio in (377, 378);
SELECT * FROM iibb_08_sucursales where IdComercio in (377, 378);
SELECT * FROM iibb_08_unicos where IdComercio in (374, 379, 380);

SELECT * FROM iibb_08_unicos where IdComercio =375;

====

SELECT cuit FROM iva_08_unicos iv, Comercios c 
WHERE iv.CUIT=c.nro_cuit;

SELECT IdComercio, cuit FROM iva_08_unicos iv 
WHERE iv.CUIT not in (SELECT c.nro_cuit from dbAmeca.Comercios c);

SELECT * FROM iva_08_sucursales iv 
WHERE iv.CUIT not in (SELECT c.nro_cuit from dbAmeca.Comercios c);

SELECT * FROM iibb_08_unicos ib 
WHERE ib.CUIT not in (SELECT c.nro_cuit from dbAmeca.Comercios c);

SELECT * FROM iibb_08_sucursales ib 
WHERE ib.CUIT not in (SELECT c.nro_cuit from dbAmeca.Comercios c);


SELECT cuit, IdComercio, NombreResponsable FROM iva_08_unicos WHERE IdComercio>370;

SELECT * FROM dbAmeca.Comercios WHERE nro_cuit='27-95242700-3';
   

SELECT * from dbAmeca.EstablecimientosLiquiMes where id_establecimiento=369;

-- UPDATE dbAmeca.EstablecimientosLiquiMes em set em.periodo='201907' where em.periodo='201909';

==== migratio 1 =====  preparacion de tablas excel, agrego id_comercio e id_establecimiento (y agrego a dbAmeca los nuevos).

SELECT iv.id_establecimiento, iv.BaseImponible, iv.CompraGenerica, iv.RetencionPercepcion, iv.SaldoDDJJIVA FROM iva_08_unicos iv;
SELECT cuit FROM iva_08_unicos iv, dbAmeca.Comercios c WHERE iv.id_comercio=c.id_comercio;
SELECT iv.cuit FROM iva_08_unicos iv, dbAmeca.Establecimientos e WHERE iv.id_establecimiento=e.id_establecimiento;

SELECT cuit, id_comercio FROM iva_08_sucursales iv;
SELECT iv.CUIT FROM iva_08_sucursales iv, dbAmeca.Comercios c WHERE iv.id_comercio=c.id_comercio;
SELECT iv.cuit FROM iva_08_sucursales iv, dbAmeca.Establecimientos e WHERE iv.id_establecimiento=e.id_establecimiento;

SELECT cuit FROM iibb_08_unicos iv;
SELECT cuit FROM iibb_08_unicos ib, dbAmeca.Comercios c WHERE ib.id_comercio=c.id_comercio;
SELECT iv.cuit FROM iva_08_unicos iv, dbAmeca.Establecimientos e WHERE iv.id_establecimiento=e.id_establecimiento;

SELECT cuit, id_comercio FROM iibb_08_sucursales ib;
SELECT ib.CUIT, ib.id_comercio, c.id_comercio FROM iibb_08_sucursales ib, dbAmeca.Comercios c WHERE ib.id_comercio=c.id_comercio;
SELECT ib.cuit FROM iibb_08_sucursales ib, dbAmeca.Establecimientos e WHERE ib.id_establecimiento=e.id_establecimiento;


SELECT * from iva_08_unicos iv 
where iv.CUIT not in (SELECT ivi.CUIT FROM iva_08_unicos ivi, dbAmeca.Establecimientos e WHERE ivi.id_establecimiento=e.id_establecimiento);
SELECT * from iva_08_sucursales iv -- cuit problematico 20-95192816-0
where iv.CUIT not in (SELECT nro_cuit FROM dbAmeca.Comercios);
SELECT * from iva_08_sucursales iv, dbAmeca.Establecimientos e -- cuit problematico 20-95192816-0
where iv.id_comercio=e.id_comercio AND iv.Direccion=e.direccion_establecimiento;
SELECT * from iibb_08_unicos ib 
where ib.CUIT not in (SELECT ibi.CUIT FROM iibb_08_unicos ibi, dbAmeca.Comercios c WHERE ibi.id_comercio=c.id_comercio);
SELECT * from iibb_08_unicos ib 
where ib.CUIT not in (SELECT ibi.CUIT FROM iibb_08_unicos ibi, dbAmeca.Establecimientos e WHERE ibi.id_establecimiento=e.id_establecimiento);
SELECT * from iibb_08_sucursales ib, dbAmeca.Comercios c WHERE ib.CUIT=c.nro_cuit;
SELECT ib.CUIT from iibb_08_sucursales ib, dbAmeca.Establecimientos e WHERE ib.id_comercio=e.id_comercio AND ib.Direccion=e.direccion_establecimiento;


SELECT cuit FROM iibb_08_unicos iv, dbAmeca.Comercios c WHERE iv.CUIT=c.nro_cuit;

UPDATE iva_08_unicos iv, dbAmeca.Comercios c set iv.id_comercio=c.id_comercio WHERE iv.CUIT=c.nro_cuit; 
UPDATE iibb_08_unicos ib, dbAmeca.Comercios c set ib.id_comercio=c.id_comercio WHERE ib.CUIT=c.nro_cuit; 
UPDATE iva_08_sucursales iv, dbAmeca.Comercios c set iv.id_comercio=c.id_comercio WHERE iv.CUIT=c.nro_cuit; 
UPDATE iibb_08_sucursales ib, dbAmeca.Comercios c set ib.id_comercio=c.id_comercio WHERE ib.CUIT=c.nro_cuit; 

UPDATE iva_08_unicos iv, dbAmeca.Establecimientos e SET iv.id_establecimiento=e.id_establecimiento WHERE e.id_comercio=iv.id_comercio;
UPDATE iibb_08_unicos ib, dbAmeca.Establecimientos e SET ib.id_establecimiento=e.id_establecimiento WHERE e.id_comercio=ib.id_comercio;
UPDATE iva_08_sucursales iv, dbAmeca.Establecimientos e set iv.id_establecimiento=e.id_establecimiento WHERE iv.id_comercio=e.id_comercio AND iv.Direccion=e.direccion_establecimiento; 
UPDATE iibb_08_sucursales ib, dbAmeca.Establecimientos e set ib.id_establecimiento=e.id_establecimiento WHERE ib.id_comercio=e.id_comercio AND ib.Direccion=e.direccion_establecimiento; 


==== fin migratio 1 =====



==== migratio 2 ===== 

-- iibb
SELECT ib.id_establecimiento, '201908', ib.Base, ib.AlicuotaIIBB, ib.Percepciones, ib.SaldoDDJJ, Base*AlicuotaIIBB/100 as 'debito', truncate (Base*AlicuotaIIBB/100-Percepciones, 2) as 'saldo'
FROM iibb_08_unicos ib;

SELECT * from dbAmeca.EstablecimientosLiquiMes;

-- INSERT INTO dbAmeca.EstablecimientosLiquiMes (id_establecimiento, base_imponible, compra_iva, percepcion_iva, periodo)
INSERT INTO dbAmeca.EstablecimientosLiquiMes (id_establecimiento, base_imponible, alicuota_iibb, percepcion_iibb, saldo_iibb, periodo)
SELECT ib.id_establecimiento, ib.Base , ib.AlicuotaIIBB, ib.Percepciones, truncate (Base*AlicuotaIIBB/100-Percepciones, 2), '201908'
FROM iibb_08_unicos ib;

SELECT ib.id_establecimiento, ib.Base , ib.AlicuotaIIBB, ib.Percepciones, truncate (Base*AlicuotaIIBB/100-Percepciones, 2), '201908'
FROM iibb_08_unicos ib;

SELECT ib.id_establecimiento, ib.SaldoDDJJ, em.saldo_iibb FROM iibb_08_unicos ib, dbAmeca.EstablecimientosLiquiMes em WHERE em.id_establecimiento=ib.id_establecimiento and em.periodo='201908';

-- iva
SELECT iv.id_establecimiento, iv.BaseImponible, iv.CompraGenerica, iv.RetencionPercepcion, iv.SaldoDDJJIVA 
FROM iva_08_unicos iv;

SELECT * from iva_08_unicos iv, dbAmeca.EstablecimientosLiquiMes em WHERE em.id_establecimiento=iv.id_establecimiento AND em.periodo='201908';

-- update de los que ya figuran en EstablecimientosLiquiMes
UPDATE dbAmeca.EstablecimientosLiquiMes em, iva_08_unicos iv 
SET em.alicuota_iva=21, em.compra_iva=iv.CompraGenerica, em.percepcion_iva=iv.RetencionPercepcion, em.saldo_iva=em.base_imponible*0.21-iv.CompraGenerica*0.21-iv.RetencionPercepcion
WHERE em.id_establecimiento=iv.id_establecimiento AND em.periodo='201908';

SELECT iv.id_establecimiento, iv.BaseImponible, em.base_imponible, iv.CompraGenerica, iv.RetencionPercepcion, iv.SaldoDDJJIVA, truncate (em.base_imponible*0.21-iv.CompraGenerica*0.21-iv.RetencionPercepcion, 2) as 'saldo'
from dbAmeca.EstablecimientosLiquiMes em, iva_08_unicos iv
WHERE em.id_establecimiento=iv.id_establecimiento AND em.periodo='201908' ;

SELECT * from iva_08_unicos iv WHERE iv.CUIT='30-71556584-2';
SELECT * FROM dbAmeca.EstablecimientosLiquiMes WHERE id_establecimiento=311;

-- inserts de los establecimientos que figuran en Establecimientos pero no en EstablecimientosLiquiMes.
SELECT * from iva_08_unicos iv WHERE iv.id_establecimiento not in (SELECT em.id_establecimiento FROM dbAmeca.EstablecimientosLiquiMes em );
SELECT * from iva_08_unicos iv WHERE iv.id_establecimiento not in (SELECT em.id_establecimiento FROM dbAmeca.EstablecimientosLiquiMes em WHERE em.periodo='201908');
30-71556584-2  -- no figura en establecimientosliquimes , id_establecimiento=311 (da negativo el saldo en excel)
-- estos figuran en ELiquiMes pero en el periodo anterior
20-11869618-3	96     ok
20-94039526-8	259    ok
20-94190860-9	55     ok
20-95738030-2	308    ok
20-94029458-5	341    ok
20-94818162-3	316    ok

SELECT iv.CUIT, iv.id_establecimiento from iva_08_unicos iv WHERE iv.id_establecimiento not in (SELECT em.id_establecimiento FROM dbAmeca.EstablecimientosLiquiMes em WHERE em.periodo='201908');


INSERT INTO dbAmeca.EstablecimientosLiquiMes (id_establecimiento, base_imponible, alicuota_iibb, alicuota_iva, percepcion_iibb, percepcion_iva, 
												saldo_iibb, saldo_iva, periodo, compra_iva)
SELECT iv.id_establecimiento, iv.BaseImponible , 3, 21, 0, iv.RetencionPercepcion, 0, truncate (iv.BaseImponible*0.21-iv.RetencionPercepcion-iv.CompraGenerica*0.21, 2), '201908', iv.CompraGenerica
FROM iva_08_unicos iv WHERE iv.id_establecimiento=316;

SELECT iv.id_establecimiento, iv.BaseImponible , 3, 21, 0, iv.RetencionPercepcion, 0, truncate (iv.BaseImponible*0.21-iv.RetencionPercepcion-iv.CompraGenerica*0.21, 2), '201908', iv.CompraGenerica
FROM iva_08_unicos iv WHERE iv.id_establecimiento=316;

SELECT * FROM dbAmeca.EstablecimientosLiquiMes WHERE id_establecimiento=316;

SELECT iv.SaldoDDJJIVA, em.saldo_iva, em.base_imponible, em.alicuota_iva, em.compra_iva, em.percepcion_iva , iv.RetencionPercepcion, iv.BaseImponible
from dbAmeca.EstablecimientosLiquiMes em, iva_08_unicos iv 
WHERE em.id_establecimiento=96 and em.id_establecimiento=iv.id_establecimiento and em.periodo='201908';

UPDATE dbAmeca.EstablecimientosLiquiMes em, iva_08_unicos iv
SET em.base_imponible=iv.BaseImponible, em.compra_iva=iv.CompraGenerica, em.percepcion_iva=iv.RetencionPercepcion
WHERE em.id_establecimiento=311 and em.id_establecimiento=iv.id_establecimiento;

UPDATE dbAmeca.EstablecimientosLiquiMes em
SET em.saldo_iva=em.base_imponible*0.21-em.compra_iva*0.21-em.percepcion_iva
WHERE em.id_establecimiento=311 ;



--  iibb sucursales (55 inserts)
SELECT * FROM iibb_08_sucursales ib; 
SELECT * FROM dbAmeca.EstablecimientosLiquiMes em WHERE id_establecimiento=97;
SELECT ib.CUIT, ib.SaldoDDJJ, em.saldo_iibb FROM iibb_08_sucursales ib, dbAmeca.EstablecimientosLiquiMes em
WHERE ib.id_establecimiento=em.id_establecimiento AND em.periodo='201908';

SELECT ib.CUIT, ib.id_establecimiento FROM iibb_08_sucursales ib WHERE ib.id_establecimiento not in (SELECT e.id_establecimiento from dbAmeca.Establecimientos e);

SELECT ib.CUIT, ib.id_establecimiento FROM iibb_08_sucursales ib WHERE ib.id_establecimiento not in (SELECT em.id_establecimiento from dbAmeca.EstablecimientosLiquiMes em WHERE em.periodo='201908');
-- no figuran en E.LiquiMes pero si en Establecimientos (caute: pensaba que no cambiaba nada, ser`ian los primeros 
-- registros del establecimiento xq pensaba que entraban todos los establecimientos que figuran en Establecimientos por un insert.. 
-- pero el tema es que aca hice updates en casi todos los casos, xq ya hice el insert desde iibb_unicos, a estos hay que insertarlos a mano).
20-95192816-0	374
20-95192816-0	375
20-95663851-9	364
20-95663851-9	365

SELECT ib.CUIT, ib.id_establecimiento, em.alicuota_iibb, em.percepcion_iibb 
FROM iibb_08_sucursales ib, dbAmeca.EstablecimientosLiquiMes em  
WHERE ib.id_establecimiento = em.id_establecimiento AND em.id_establecimiento=375 AND em.periodo='201908';


INSERT INTO dbAmeca.EstablecimientosLiquiMes (id_establecimiento, base_imponible, alicuota_iibb, percepcion_iibb, saldo_iibb, periodo)
SELECT ib.id_establecimiento, ib.Base , ib.AlicuotaIIBB, ib.Percepciones, truncate (Base*AlicuotaIIBB/100-Percepciones, 2), '201908'
FROM iibb_08_sucursales ib;


-- iva sucursales (55 updates y 2 inserts)
SELECT * FROM iva_08_sucursales iv;
SELECT iv.CUIT, iv.SaldoDDJJIVA, em.saldo_iva FROM iva_08_sucursales iv, dbAmeca.EstablecimientosLiquiMes em
WHERE iv.id_establecimiento=em.id_establecimiento AND em.periodo='201908';

SELECT iv.CUIT, iv.id_establecimiento FROM iva_08_sucursales iv WHERE iv.id_establecimiento not in (SELECT e.id_establecimiento from dbAmeca.Establecimientos e);
-- si todos los establecimientos de excel estan en Establecimientos, directamente inserto en E.LiquiMes, salvo que ya este en ese periodo y hago update.
SELECT iv.CUIT, iv.id_establecimiento FROM iva_08_sucursales iv WHERE iv.id_establecimiento not in (SELECT em.id_establecimiento from dbAmeca.EstablecimientosLiquiMes em WHERE em.periodo='201908');
-- no figuran en E.LiquiMes para este periodo, el resto ya estan, requieren update solamente.
23-94712653-9	89
23-94712653-9	90

UPDATE dbAmeca.EstablecimientosLiquiMes em, iva_08_sucursales iv 
SET em.compra_iva=iv.CompraGenerica, em.percepcion_iva=iv.RetencionPercepcion, em.saldo_iva=em.base_imponible*0.21-iv.CompraGenerica*0.21-iv.RetencionPercepcion
WHERE em.id_establecimiento=iv.id_establecimiento AND em.periodo='201908';

SELECT em.* from dbAmeca.EstablecimientosLiquiMes em, iva_08_sucursales iv 
WHERE iv.id_establecimiento=em.id_establecimiento AND em.periodo='201908' ; -- and em.id_establecimiento=89;

SELECT * FROM dbAmeca.EstablecimientosLiquiMes em WHERE em.periodo='201908' AND em.id_establecimiento=90;

INSERT INTO dbAmeca.EstablecimientosLiquiMes (id_establecimiento, base_imponible, alicuota_iibb, alicuota_iva, percepcion_iibb, percepcion_iva, 
			saldo_iibb, saldo_iva, periodo, compra_iva)
SELECT iv.id_establecimiento, iv.BaseImponible , 3, 21, 0, iv.RetencionPercepcion, 0, truncate (iv.BaseImponible*0.21-iv.RetencionPercepcion-iv.CompraGenerica*0.21, 2), '201908', iv.CompraGenerica
FROM iva_08_sucursales iv WHERE iv.id_establecimiento=90;




UPDATE dbAmeca.EstablecimientosLiquiMes em, iva_08_unicos iv 
SET em.alicuota_iva=21, em.compra_iva=iv.CompraGenerica, em.percepcion_iva=iv.RetencionPercepcion, em.saldo_iva=em.base_imponible*0.21-iv.CompraGenerica*0.21-iv.RetencionPercepcion
WHERE em.id_establecimiento=iv.id_establecimiento AND em.periodo='201908';



==== migratio 3 =====  con activo iva e iibb ahora en E.LiquiMes, y actualizacion en periodo anterior tambien.

-- periodo=201908
-- insertar en dbAmeca.EstablecimientosLiquiMes base imponible, y saldos. Y reportes. La primer tabla inserta todos, 
-- pero las siguientes primero update y marcarlos, y despues insert.

SELECT COUNT(*) from iva_08_unicos UNION SELECT COUNT(*) from iva_08_sucursales; -- 233 = 176+57
SELECT COUNT(*) from iibb_08_unicos UNION SELECT COUNT(*) from iibb_08_sucursales; -- 233 = 178+55

SELECT count(*) FROM dbAmeca.EstablecimientosLiquiMes WHERE periodo='201908';  -- 242 y los queries del listado dan 230 en iibb y 231 iva 


-- poner activo_iva_periodo=1 en eLiquiMes a todos los que estan en planilla excel iva (idem iibb).
UPDATE dbAmeca.EstablecimientosLiquiMes em, dbAmeca2.iva_08_sucursales iv
SET em.activo_iva_periodo=1 WHERE iv.id_establecimiento=em.id_establecimiento AND em.periodo='201908';

select * from dbAmeca.EstablecimientosLiquiMes em, dbAmeca2.iva_08_unicos iv WHERE iv.id_establecimiento=em.id_establecimiento AND em.periodo='201908';
select * from dbAmeca.EstablecimientosLiquiMes em, dbAmeca2.iva_08_sucursales iv WHERE iv.id_establecimiento=em.id_establecimiento AND em.periodo='201908';
UPDATE dbAmeca.EstablecimientosLiquiMes SET activo_iva_periodo=0 WHERE activo_iva_periodo is null AND periodo='201908';
SELECT COUNT(*) FROM dbAmeca.EstablecimientosLiquiMes WHERE periodo='201908' AND activo_iva_periodo=1;
SELECT COUNT(*) FROM dbAmeca.EstablecimientosLiquiMes WHERE periodo='201908' AND activo_iva_periodo is null;
SELECT COUNT(*) FROM dbAmeca.EstablecimientosLiquiMes WHERE periodo='201908' AND activo_iva_periodo=0;


select * from dbAmeca.EstablecimientosLiquiMes em, dbAmeca2.iibb_08_unicos ib WHERE ib.id_establecimiento=em.id_establecimiento AND em.periodo='201908';
select * from dbAmeca.EstablecimientosLiquiMes em, dbAmeca2.iibb_08_sucursales ib WHERE ib.id_establecimiento=em.id_establecimiento AND em.periodo='201908';
UPDATE dbAmeca.EstablecimientosLiquiMes em, dbAmeca2.iibb_08_unicos ib
SET activo_iibb_periodo=1 WHERE ib.id_establecimiento=em.id_establecimiento AND em.periodo='201908';
UPDATE dbAmeca.EstablecimientosLiquiMes em, dbAmeca2.iibb_08_sucursales ib
SET activo_iibb_periodo=1 WHERE ib.id_establecimiento=em.id_establecimiento AND em.periodo='201908';

SELECT COUNT(*) FROM dbAmeca.EstablecimientosLiquiMes WHERE periodo='201908' AND activo_iibb_periodo=1;
SELECT COUNT(*) FROM dbAmeca.EstablecimientosLiquiMes WHERE periodo='201908' AND activo_iibb_periodo is null;
UPDATE dbAmeca.EstablecimientosLiquiMes SET activo_iibb_periodo=0 WHERE activo_iibb_periodo is null AND periodo='201908';
SELECT COUNT(*) FROM dbAmeca.EstablecimientosLiquiMes WHERE periodo='201908' AND activo_iibb_periodo=0;


SELECT * FROM dbAmeca.EstablecimientosLiquiMes WHERE activo_iibb_periodo=0 AND activo_iva_periodo=1;
SELECT c.nro_cuit, e.id_establecimiento, em.activo_iva_periodo FROM dbAmeca.EstablecimientosLiquiMes em, dbAmeca.Establecimientos e, dbAmeca.Comercios c 
  WHERE em.id_establecimiento=e.id_establecimiento AND e.id_comercio=c.id_comercio AND em.activo_iibb_periodo=0 AND em.activo_iva_periodo=1;
SELECT * FROM dbAmeca.EstablecimientosLiquiMes WHERE activo_iibb_periodo=1 AND activo_iva_periodo=0;

nueve cuits e id_establecimientos activos iva e inactivos iibb
30-71556584-2	311
20-11869618-3	96
20-94039526-8	259
20-94190860-9	55
20-95738030-2	308
20-94029458-5	341
20-94818162-3	316
23-94712653-9	89
23-94712653-9	90

SELECT c.nro_cuit, e.id_establecimiento, em.activo_iva_periodo FROM dbAmeca.EstablecimientosLiquiMes em, dbAmeca.Establecimientos e, dbAmeca.Comercios c 
  WHERE em.id_establecimiento=e.id_establecimiento AND e.id_comercio=c.id_comercio AND em.activo_iibb_periodo=1 AND em.activo_iva_periodo=0;

 nueve activos iibb e inactivos iva:
20-35969339-8	371
20-95962017-3	372
20-94611053-2	343
20-94190860-9	54
20-94471737-5	15
20-95034652-4	373
20-95121455-9	99
27-33945744-7	69
20-94818162-3	156



-- funciona ok, pero en iibb se rompe la tabla porque el perfil impositivo del comercio de algun establecimiento
-- dice que queda afuera pero esta activo iibb=1 xq aparece en la planilla excel. Ader estaba como exento:20-94471737-5

SELECT * FROM dbAmeca.Comercios c, dbAmeca.Establecimientos e, dbAmeca.EstablecimientosLiquiMes em
WHERE c.id_comercio=e.id_comercio AND e.id_establecimiento=em.id_establecimiento 
AND c.id_condicion_iibb in (2, 4, 5) AND em.activo_iibb_periodo=1;

-- en iva faltan dos, el nro_cuit=20-94022355-6, id_comercio=291 estaba como monotributista.
SELECT * FROM dbAmeca.Comercios c, dbAmeca.Establecimientos e, dbAmeca.EstablecimientosLiquiMes em
WHERE c.id_comercio=e.id_comercio AND e.id_establecimiento=em.id_establecimiento 
AND c.id_condicion_iva=1 AND em.activo_iva_periodo=1;


-- actualizacion de liquidaciones periodo anterior: 201807
-- iibb_unicos
SELECT * from dbAmeca.Liqui_IIBB201907_unicos;  -- 176
SELECT * from dbAmeca.Liqui_IIBB201907_unicos ib, dbAmeca.EstablecimientosLiquiMes em WHERE em.id_establecimiento=ib.id_sucursal AND em.periodo='201907';  -- 176

UPDATE dbAmeca.EstablecimientosLiquiMes em, dbAmeca.Liqui_IIBB201907_unicos ib
SET em.activo_iibb_periodo=1 WHERE em.id_establecimiento=ib.id_sucursal AND em.periodo='201907';

-- iibb sucursales
SELECT * from dbAmeca.Liqui_IIBB201907_SUCURSALES;  -- 50
SELECT * from dbAmeca.Liqui_IIBB201907_SUCURSALES ib, dbAmeca.EstablecimientosLiquiMes em WHERE em.id_establecimiento=ib.id_sucursal AND em.periodo='201907';  -- 50
UPDATE dbAmeca.EstablecimientosLiquiMes em, dbAmeca.Liqui_IIBB201907_SUCURSALES ib
   SET em.activo_iibb_periodo=1 WHERE em.id_establecimiento=ib.id_sucursal AND em.periodo='201907';

-- iva_unicos
SELECT * from dbAmeca.Liqui_IVA201907_unicos;  -- 177
SELECT * from dbAmeca.Liqui_IVA201907_unicos iv, dbAmeca.EstablecimientosLiquiMes em WHERE em.id_establecimiento=iv.id_sucursal AND em.periodo='201907';  -- 177

UPDATE dbAmeca.EstablecimientosLiquiMes em, dbAmeca.Liqui_IVA201907_unicos iv
SET em.activo_iva_periodo=1 WHERE em.id_establecimiento=iv.id_sucursal AND em.periodo='201907';

-- iibb sucursales
SELECT * from dbAmeca.Liqui_IVA201907_sucursales;  -- 52
SELECT * from dbAmeca.Liqui_IVA201907_sucursales iv, dbAmeca.EstablecimientosLiquiMes em WHERE em.id_establecimiento=iv.id_sucursal AND em.periodo='201907';  -- 52
UPDATE dbAmeca.EstablecimientosLiquiMes em, dbAmeca.Liqui_IVA201907_sucursales iv
   SET em.activo_iva_periodo=1 WHERE em.id_establecimiento=iv.id_sucursal AND em.periodo='201907';
  
SELECT * FROM dbAmeca.EstablecimientosLiquiMes WHERE activo_iibb_periodo is null;
UPDATE dbAmeca.EstablecimientosLiquiMes SET activo_iva_periodo=0 WHERE activo_iva_periodo is null;
UPDATE dbAmeca.EstablecimientosLiquiMes SET activo_iibb_periodo=0 WHERE activo_iibb_periodo is null;








=====================  restos migratio

SELECT * FROM iva_08_unicos iv;  -- 176
SELECT * FROM iva_08_unicos iv, dbAmeca.EstablecimientosLiquiMes em WHERE em.id_establecimiento=iv.id_establecimiento AND em.periodo='201908';  -- 176



306 : este comercio tiene dos establecimientos: el que aparece este periodo es id_establecimiento 316 (calle italia, zonas varias)
325 : id_establecimiento 341 (calle4 zonas varias)
296 : id_establecimiento 55 (ramallo, san martin)

SELECT * from iva_08_unicos WHERE id_comercio=306;
SELECT * from dbAmeca.Establecimientos WHERE id_comercio=306;

SELECT iv.CUIT, e.id_comercio, COUNT(*) FROM iva_08_unicos iv, dbAmeca.Establecimientos e
WHERE e.id_comercio=iv.id_comercio
GROUP BY iv.CUIT, e.id_comercio
order by 3;





=====  back to normal  =====

SELECT * from dbAmeca.Comercios;
SELECT * FROM dbAmeca.Establecimientos e WHERE e.id_establecimiento=2;
SELECT * FROM dbAmeca.Establecimientos e, dbAmeca.EstablecimientosLiquiMes em
WHERE e.id_establecimiento=2 AND e.id_establecimiento=em.id_establecimiento; -- AND em.periodo='201908';

SELECT * FROM dbAmeca.Establecimientos e LEFT JOIN dbAmeca.EstablecimientosLiquiMes em ON e.id_establecimiento=em.id_establecimiento
WHERE e.id_establecimiento=341 ORDER BY em.periodo; -- AND em.periodo='201908';

SELECT * FROM dbAmeca.Establecimientos e LEFT JOIN dbAmeca.EstablecimientosLiquiMes em ON e.id_establecimiento=em.id_establecimiento
WHERE e.id_comercio=325 ORDER BY em.periodo; -- AND em.periodo='201908';

SELECT e.direccion_establecimiento, e.id_establecimiento, (SELECT em.activo_iva_periodo FROM dbAmeca.EstablecimientosLiquiMes em WHERE em.id_establecimiento=e.id_establecimiento AND em.periodo='201908') as 'activo_iva' 
FROM dbAmeca.Establecimientos e WHERE e.id_comercio=325; -- AND em.periodo='201908';

SELECT em.activo_iva_periodo FROM dbAmeca.EstablecimientosLiquiMes em WHERE em.id_establecimiento=341 AND em.periodo='201908';

SELECT * FROM dbAmeca.EstablecimientosLiquiMes WHERE id_establecimiento=341;
SELECT * FROM dbAmeca.Establecimientos WHERE id_establecimiento=341;

SELECT id_establecimiento FROM dbAmeca.Establecimientos WHERE id_establecimiento not in (SELECT id_establecimiento FROM dbAmeca.EstablecimientosLiquiMes);

select * from Comercios WHERE id_comercio=291;




========  dbAmeca2 activo for testing

SELECT * FROM dbAmeca2.Establecimientos e, dbAmeca2.EstablecimientosLiquiMes em
WHERE  e.id_establecimiento=em.id_establecimiento AND em.periodo='201909';

SELECT em.* FROM dbAmeca2.Establecimientos e, dbAmeca2.EstablecimientosLiquiMes em
WHERE e.id_establecimiento=366 AND e.id_establecimiento=em.id_establecimiento AND em.periodo='201907';

SELECT em.periodo, em.activo_iibb_periodo, em.activo_iva_periodo, em.saldo_iibb, em.saldo_iva 
FROM dbAmeca2.Establecimientos e, dbAmeca2.EstablecimientosLiquiMes em
WHERE e.id_comercio=326 AND e.id_establecimiento=em.id_establecimiento AND em.periodo='201907';

SELECT * from Comercios WHERE id_comercio=333;
SELECT * from dbAmeca2.Comercios WHERE id_comercio=333;

SELECT em.id_establecimiento, base_imponible, compra_iva, percepcion_iva, percepcion_iibb,
                          periodo, em.saldo_iibb, em.saldo_iva, em.alicuota_iibb, em.alicuota_iva, 
		em.alicuota_pago_facil, em.reporte_ameca_comision, em.activo_iva_periodo, em.activo_iibb_periodo 
FROM  EstablecimientosLiquiMes em, Establecimientos e 
WHERE periodo ='201909' and e.id_establecimiento=em.id_establecimiento ;-- and (em.activo_iibb_periodo or em.activo_iva_periodo)

UPDATE EstablecimientosLiquiMes em, EstablecimientosLiquiMes emm 
SET em.activo_iibb_periodo=emm.activo_iibb_periodo, em.activo_iva_periodo=emm.activo_iva_periodo 
where em.periodo='201909' AND emm.periodo='201908' and em.id_establecimiento=emm.id_establecimiento;

SELECT activo_iibb_periodo, activo_iibb_periodo FROM EstablecimientosLiquiMes WHERE periodo='201909';

SELECT em.activo_iibb_periodo, emm.activo_iibb_periodo 
FROM EstablecimientosLiquiMes em, EstablecimientosLiquiMes emm 
WHERE em.periodo='201909' and emm.periodo='201908' and em.id_establecimiento=emm.id_establecimiento;



====

SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, em.base_imponible, em.percepcion_iibb, em.saldo_iibb, em.alicuota_iibb, e.id_zona, c.id_condicion_iibb FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
WHERE c.id_comercio = e.id_comercio AND em.activo_iibb_periodo=1 AND e.id_comercio=321 AND e.id_establecimiento=em.id_establecimiento AND em.periodo='201913' 
ORDER BY nro_cuit, e.id_zona;

SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, em.base_imponible, em.percepcion_iibb, em.saldo_iibb, em.alicuota_iibb, e.id_zona, c.id_condicion_iibb FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em WHERE c.id_comercio = e.id_comercio AND em.activo_iibb_periodo=1 AND e.id_comercio=321 AND e.id_establecimiento=em.id_establecimiento AND em.periodo='201913' ORDER BY nro_cuit, e.id_zona;

UPDATE EstablecimientosLiquiMes 
SET saldo_iibb=base_imponible*alicuota_iibb/100 - percepcion_iibb, saldo_iva= base_imponible*0.21 - compra_iva*0.21 - percepcion_iva
where periodo='201913';

UPDATE EstablecimientosLiquiMes 
SET base_imponible=id_establecimiento*1000, percepcion_iibb=id_establecimiento_mes, percepcion_iva=id_establecimiento 
where periodo='201913';

DELETE FROM EstablecimientosLiquiMes WHERE periodo='201914';


SELECT periodo, base_imponible, compra_iva, percepcion_iva, saldo_iva, percepcion_iibb ,saldo_iibb 
from dbAmeca2.EstablecimientosLiquiMes where id_establecimiento=367;


=========   liquidaciones totales iva e iibb

SELECT em.id_establecimiento, em.base_imponible, em.base_imponible*0.21 as 'debito iva', em.base_imponible*em.alicuota_iibb/100 as 'debito iibb', em.compra_iva*em.alicuota_iva/100 as 'credito iva'
FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em
WHERE c.id_comercio = e.id_comercio AND e.id_establecimiento=em.id_establecimiento
  AND em.periodo ='201909' AND (activo_iva_periodo OR activo_iibb_periodo) 
ORDER by c.nro_cuit;

select * from EstablecimientosLiquiMes where id_establecimiento=369;



========= liquidacion x zona (incluir si al menos uno de esa zona)

SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, em.base_imponible, e.id_zona, c.id_comercio,
			(SELECT COUNT(*) FROM EstablecimientosLiquiMes eem, Establecimientos ee 
			 WHERE periodo='201913'  AND eem.id_establecimiento=ee.id_establecimiento
			 	AND ee.id_comercio=e.id_comercio AND eem.activo_iva_periodo=1 AND c.id_condicion_iva!=1
			 	AND ee.id_comercio in (select eeee.id_comercio FROM Establecimientos eeee where eeee.id_zona=6)) as 'count' 
FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
WHERE c.id_comercio = e.id_comercio  AND em.activo_iva_periodo=1 AND c.id_condicion_iva!=1 AND e.id_establecimiento=em.id_establecimiento 
	AND em.periodo ='201913'  AND c.id_comercio in (select eee.id_comercio FROM Establecimientos eee where eee.id_zona=6)
ORDER BY c.nro_cuit;

SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, em.base_imponible, e.id_zona, c.id_comercio,
			(SELECT COUNT(*) FROM EstablecimientosLiquiMes eem, Establecimientos ee 
			 WHERE periodo='201913'  AND eem.id_establecimiento=ee.id_establecimiento AND eem.activo_iibb_periodo=1 
			 	AND ee.id_comercio=e.id_comercio AND ee.id_comercio in (select eeee.id_comercio FROM Establecimientos eeee where eeee.id_zona=3)) as 'count2' 
FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
WHERE c.id_comercio = e.id_comercio  AND em.activo_iibb_periodo=1 AND e.id_establecimiento=em.id_establecimiento 
	AND em.periodo ='201913'  AND c.id_comercio in (select eee.id_comercio FROM Establecimientos eee where eee.id_zona=3)
ORDER BY c.nro_cuit;


=====  admin comercio

SELECT e.* 
FROM Establecimientos e, Comercios c 
LEFT JOIN EstablecimientosLiquiMes em USING(id_establecimiento)
WHERE  e.id_comercio=170  AND c.id_comercio=e.id_comercio;

SELECT  e.id_establecimiento, e.cuit, em.periodo, em.reporte_ameca_comision, em.reporte_gan, em.reporte_suss, 
		em.reporte_afip_esp, (SELECT COUNT(*) from Establecimientos ee where ee.id_comercio=170) as 'count'
FROM Establecimientos e LEFT JOIN Comercios c USING (id_comercio) LEFT JOIN EstablecimientosLiquiMes em USING(id_establecimiento)  
WHERE c.id_comercio=326 -- and em.periodo='201913';
ORDER BY 3 Desc;

SELECT COUNT(*) from Establecimientos ee where ee.id_comercio=100;


========  Reporte

SELECT  c.id_categ_monotributo, c.id_categ_autonomo, c.id_condicion_iibb, c.id_condicion_iva, 
		c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, e.id_zona, e.nro_pago_facil, em.alicuota_pago_facil, 
		em.saldo_iva, em.saldo_iibb, em.reporte_gan, em.reporte_afip_esp, em.reporte_suss, e.id_localidad, em.periodo, 
		em.reporte_ameca_comision, em.reporte_observacion
FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em, CategoriasAutonomo ca
WHERE e.id_establecimiento=107 AND c.id_comercio=e.id_comercio AND e.id_establecimiento=em.id_establecimiento
    AND c.id_categ_autonomo=ca.id_categoria_autonomo AND periodo='201914';

SELECT  c.id_categ_monotributo, c.id_categ_autonomo, c.id_condicion_iibb, c.id_condicion_iva, 
		c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, e.id_zona, e.nro_pago_facil, em.alicuota_pago_facil, 
		em.saldo_iva, em.saldo_iibb, em.reporte_gan, em.reporte_afip_esp, em.reporte_suss, e.id_localidad, em.periodo, 
		em.reporte_ameca_comision, em.reporte_observacion
FROM Establecimientos e LEFT JOIN Comercios c USING (id_comercio) LEFT JOIN EstablecimientosLiquiMes em ON e.id_establecimiento=em.id_establecimiento AND periodo='201914'
WHERE e.id_establecimiento=107 ;

SELECT e.id_establecimiento 
FROM Establecimientos e LEFT JOIN Comercios c USING (id_comercio) LEFT JOIN EstablecimientosLiquiMes em USING(id_establecimiento)
WHERE periodo='201914' and e.id_establecimiento=107;   
   
SELECT * FROM Establecimientos WHERE id_establecimiento=107;
SELECT * FROM EstablecimientosLiquiMes WHERE id_establecimiento=107;


=======  Liqui a excel

-- IVA
SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, em.base_imponible, e.id_zona, c.id_comercio,
			(SELECT COUNT(*) FROM EstablecimientosLiquiMes eem, Establecimientos ee 
			 WHERE periodo='201913'  AND eem.id_establecimiento=ee.id_establecimiento
			 	AND ee.id_comercio=e.id_comercio AND eem.activo_iva_periodo=1 AND c.id_condicion_iva!=1 ) as 'count'
FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
WHERE c.id_comercio = e.id_comercio  AND em.activo_iva_periodo=1 AND c.id_condicion_iva!=1 AND e.id_establecimiento=em.id_establecimiento 
	AND em.periodo ='201912'
ORDER BY count, c.nro_cuit;

-- IIBB
SELECT c.nro_cuit, c.nombre_responsable, e.direccion_establecimiento, em.base_imponible, e.id_zona, c.id_comercio,
			(SELECT COUNT(*) FROM EstablecimientosLiquiMes eem, Establecimientos ee 
			 WHERE periodo='201914'  AND eem.id_establecimiento=ee.id_establecimiento
			 	AND ee.id_comercio=e.id_comercio AND eem.activo_iibb_periodo=1) as 'count'
FROM Comercios c, Establecimientos e, EstablecimientosLiquiMes em 
WHERE c.id_comercio = e.id_comercio  AND em.activo_iibb_periodo=1 AND e.id_establecimiento=em.id_establecimiento 
	AND em.periodo ='201914'
ORDER BY count, c.nro_cuit;



select * from EstablecimientosLiquiMes where id_establecimiento=368 and periodo>'201906' and periodo<'201914' ;

====   tabla para el nuevo requerimiento

CREATE TABLE dbAmeca2.ComerciosCompras (
	id_comercio SMALLINT UNSIGNED NOT NULL,
	periodo CHAR(6) NOT NULL,
	imp_neto_gravado DECIMAL(10,2) DEFAULT 0.0 NULL,
	imp_neto_no_gravado DECIMAL(10,2) DEFAULT 0.0 NULL,
	imp_op_exentas DECIMAL(10,2) DEFAULT 0.0 NULL,
	iva DECIMAL(4,2) DEFAULT 21.0 NULL,
	imp_total DECIMAL(10,2) DEFAULT 0.0 NULL
)
ENGINE=MyISAM
DEFAULT CHARSET=latin1
COLLATE=latin1_spanish_ci;

select * from ComerciosCompras;

UPDATE Establecimientos SET observaciones='prueba lerma' 
WHERE id_establecimiento=330; 


Select observaciones from Establecimientos 
WHERE id_establecimiento=368; 

Select * from EstablecimientosLiquiMes
WHERE id_establecimiento=366 and periodo = '201916'; 

Select periodo, autonomo_check, monotributo_check from EstablecimientosLiquiMes
WHERE id_establecimiento=366 
order by 1 desc; 

DELETE FROM EstablecimientosLiquiMes WHERE
periodo='201916'; 

=======

ALTER TABLE dbAmeca2.EstablecimientosLiquiMes ADD saldo_iva_report DECIMAL(10,2) DEFAULT 0 NULL;
ALTER TABLE dbAmeca2.EstablecimientosLiquiMes ADD saldo_iibb_report DECIMAL(10,2) DEFAULT 0 NULL;

SELECT id_categoria_autonomo, nom_categoria_autonomo, tope_categoria_autonomo, FORMAT(monto_mensual_autonomo, 2, 'de_DE') monto, tabla_autonomo, categoria_tabla_autonomo 
FROM CategoriasAutonomo;

SELECT * FROM CategoriasAutonomo as c;

SELECT em.periodo, e.id_comercio, em.autonomo_check
FROM Establecimientos e LEFT JOIN Comercios c USING (id_comercio) LEFT JOIN EstablecimientosLiquiMes em ON e.id_establecimiento=em.id_establecimiento AND  periodo='201906' 
WHERE e.id_establecimiento=366;




====

ALTER TABLE dbAmeca.EstablecimientosLiquiMes ADD autonomo_check BIT DEFAULT 0 NULL;
ALTER TABLE dbAmeca2.EstablecimientosLiquiMes ADD monotributo_check BIT DEFAULT 0 NULL;

UPDATE dbAmeca.EstablecimientosLiquiMes set autonomo_check=0;

SELECT autonomo_check, monotributo_check from dbAmeca.EstablecimientosLiquiMes as e;





================================

SELECT * FROM `09_iibb_unicos` as iu, Comercios as c
WHERE c.nro_cuit=iu.CUIT;

SELECT * FROM `09_iibb_unicos` as iu LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit)
WHERE c.nro_cuit is null;
SELECT * FROM `09_iva_unicos` as iu LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit)
WHERE c.nro_cuit is null;
SELECT * FROM `09_iibb_sucursales` LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit)
WHERE c.nro_cuit is null;
SELECT * FROM `09_iva_sucursales` as iu LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit)
WHERE c.nro_cuit is null;

UPDATE `09_iibb_unicos` set nro_cuit=CUIT;
UPDATE `09_iva_unicos` set nro_cuit=CUIT;
UPDATE `09_iibb_sucursales` set nro_cuit=CUIT;
UPDATE `09_iva_sucursales` set nro_cuit=CUIT;

DELETE from `09_iibb_sucursales` WHERE IdComercio = '';
DELETE from `09_iva_sucursales` WHERE IdComercio = '';

===
-- cargar bases:

SELECT IdComercio FROM `09_iibb_unicos`;
SELECT IdComercio, id_comercio FROM `09_iibb_unicos` as iu LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit);
SELECT Dirección, e.id_comercio, e.id_establecimiento, e.direccion_establecimiento,e.nro_cuit, iu.nro_cuit FROM `09_iibb_unicos` as iu LEFT JOIN dbAmeca2.Establecimientos e USING (nro_cuit) where iu.Dirección=e.direccion_establecimiento;
SELECT e.nro_cuit, iu.nro_cuit, Dirección, e.id_comercio, e.direccion_establecimiento FROM `09_iibb_unicos` as iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_comercio) where iu.Dirección!=e.direccion_establecimiento;

UPDATE `09_iibb_unicos` iu LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit) set iu.id_comercio=c.id_comercio  where iu.Dirección=c.direccion_establecimiento;
UPDATE `09_iibb_unicos` iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_comercio) set iu.id_establecimiento=e.id_establecimiento  where iu.Dirección=e.direccion_establecimiento;

select e.nro_cuit, iu.nro_cuit, e.id_comercio, e.id_establecimiento, e.direccion_establecimiento 
FROM `09_iibb_unicos` iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_establecimiento);

select * from dbAmeca.Establecimientos where nro_cuit='20-35969339-8';
select * from dbAmeca2.Establecimientos where id_comercio=329;

UPDATE `09_iibb_unicos` iu LEFT JOIN dbAmeca.Establecimientos e USING (id_establecimiento)
SET e.nro_cuit=iu.nro_cuit WHERE e.nro_cuit is null;

=====

SELECT IdComercio FROM `09_iva_unicos`;
SELECT IdComercio, c.id_comercio, iu.id_comercio 
FROM `09_iva_unicos` as iu LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit);
SELECT Dirección, e.id_comercio, e.id_establecimiento, e.direccion_establecimiento,e.nro_cuit, iu.nro_cuit, iu.id_establecimiento 
FROM `09_iva_unicos` as iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_comercio) 
where iu.Dirección=e.direccion_establecimiento;
-- inutil:
SELECT e.nro_cuit, iu.nro_cuit, Dirección, e.id_comercio, e.direccion_establecimiento, e.id_establecimiento 
FROM `09_iva_unicos` as iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_comercio) 
where iu.Dirección!=e.direccion_establecimiento;

UPDATE `09_iva_unicos` iu LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit) set iu.id_comercio=c.id_comercio ;
UPDATE `09_iva_unicos` iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_comercio) 
set iu.id_establecimiento=e.id_establecimiento  where iu.Dirección=e.direccion_establecimiento;

select e.nro_cuit, iu.nro_cuit, e.id_comercio, e.id_establecimiento, e.direccion_establecimiento, iu.* 
FROM `09_iva_unicos` iu LEFT JOIN dbAmeca.Establecimientos e USING (id_establecimiento); -- WHERE e.nro_cuit is null;

select * from dbAmeca.Establecimientos where nro_cuit='27-36566917-7';
select * from dbAmeca2.Establecimientos where id_comercio=329;

UPDATE `09_iva_unicos` iu LEFT JOIN dbAmeca.Establecimientos e USING (id_establecimiento)
SET e.nro_cuit=iu.nro_cuit WHERE e.nro_cuit is null;


===  sucursales

-- iva

SELECT IdComercio FROM `09_iva_sucursales` ;
SELECT IdComercio, c.id_comercio, iu.id_comercio 
FROM `09_iva_sucursales` as iu LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit);
SELECT Dirección, e.id_comercio, e.id_establecimiento, e.direccion_establecimiento,e.nro_cuit, iu.nro_cuit, iu.id_establecimiento 
FROM `09_iva_sucursales` as iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_comercio) 
where iu.Dirección=e.direccion_establecimiento;
-- inutil:
SELECT e.nro_cuit, iu.nro_cuit, Dirección, e.id_comercio, e.direccion_establecimiento, e.id_establecimiento 
FROM `09_iva_unicos` as iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_comercio) 
where iu.Dirección!=e.direccion_establecimiento;

UPDATE `09_iva_sucursales` iu LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit) set iu.id_comercio=c.id_comercio ;
UPDATE `09_iva_sucursales` iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_comercio) 
set iu.id_establecimiento=e.id_establecimiento  where iu.Dirección=e.direccion_establecimiento;

select e.nro_cuit, iu.nro_cuit, e.id_comercio, e.id_establecimiento, e.direccion_establecimiento, iu.* 
FROM `09_iva_unicos` iu LEFT JOIN dbAmeca.Establecimientos e USING (id_establecimiento); -- WHERE e.nro_cuit is null;

-- iibb

SELECT IdComercio FROM `09_iibb_sucursales` ;
SELECT IdComercio, c.id_comercio, iu.id_comercio 
FROM `09_iibb_sucursales` as iu LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit);
SELECT Dirección, e.id_comercio, e.id_establecimiento, e.direccion_establecimiento,e.nro_cuit, iu.nro_cuit, iu.id_establecimiento 
FROM `09_iibb_sucursales` as iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_comercio) 
where iu.Dirección=e.direccion_establecimiento;
-- inutil:
SELECT e.nro_cuit, iu.nro_cuit, Dirección, e.id_comercio, e.direccion_establecimiento, e.id_establecimiento 
FROM `09_iibb_unicos` as iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_comercio) 
where iu.Dirección!=e.direccion_establecimiento;

UPDATE `09_iibb_sucursales` iu LEFT JOIN dbAmeca2.Comercios c USING (nro_cuit) set iu.id_comercio=c.id_comercio ;
UPDATE `09_iibb_sucursales` iu LEFT JOIN dbAmeca2.Establecimientos e USING (id_comercio) 
set iu.id_establecimiento=e.id_establecimiento  where iu.Dirección=e.direccion_establecimiento;

select e.nro_cuit, iu.nro_cuit, e.id_comercio, e.id_establecimiento, e.direccion_establecimiento, iu.* 
FROM `09_iibb_unicos` iu LEFT JOIN dbAmeca.Establecimientos e USING (id_establecimiento); -- WHERE e.nro_cuit is null;

select e.id_establecimiento from dbAmeca2.Establecimientos as e, `09_iibb_sucursales` as iibb WHERE e.id_establecimiento=iibb.id_establecimiento;

=============  BASE  ================

-- iibb
SELECT ib.id_establecimiento, '201909', ib.Base, ib.AlícuotaIIBB, ib.Percepciones, ib.SaldoDDJJ, Base*AlícuotaIIBB/100 as 'debito', truncate (Base*AlícuotaIIBB/100-Percepciones, 2) as 'saldo', 1 as 'activo_iibb_periodo'
FROM `09_iibb_unicos` as ib;

SELECT * from dbAmeca2.EstablecimientosLiquiMes where periodo='201909';
delete FROM dbAmeca2.EstablecimientosLiquiMes where periodo='201909';

INSERT INTO dbAmeca2.EstablecimientosLiquiMes (id_establecimiento, base_imponible, alicuota_iibb, percepcion_iibb, saldo_iibb, periodo, activo_iibb_periodo)
SELECT ib.id_establecimiento, ib.Base , ib.AlícuotaIIBB, ib.Percepciones, truncate (Base*AlícuotaIIBB/100-Percepciones, 2), '201909', 1
FROM `09_iibb_unicos` as ib;

SELECT ib.id_establecimiento, ib.Base , ib.AlícuotaIIBB, ib.Percepciones, truncate (Base*AlícuotaIIBB/100-Percepciones, 2), '201909'
FROM `09_iibb_unicos` ib;

SELECT ib.id_establecimiento, ib.SaldoDDJJ, em.saldo_iibb 
FROM `09_iibb_unicos` ib, dbAmeca2.EstablecimientosLiquiMes em 
WHERE em.id_establecimiento=ib.id_establecimiento and em.periodo='201909';


-- iibb sucursales

INSERT INTO dbAmeca2.EstablecimientosLiquiMes (id_establecimiento, base_imponible, alicuota_iibb, percepcion_iibb, saldo_iibb, periodo, activo_iibb_periodo)
SELECT ib.id_establecimiento, ib.Base , ib.AlícuotaIIBB, ib.Percepciones, truncate (Base*AlícuotaIIBB/100-Percepciones, 2), '201909', 1
FROM `09_iibb_sucursales` as ib;


-- iva  UPDATES + INSERT
SELECT iv.id_establecimiento, iv.BaseImponible, iv.CompraGenérica, iv.RetenciónPercepción, iv.SaldoDDJJIVA 
FROM `09_iva_unicos` iv;

SELECT * from `09_iva_unicos` iv;


SELECT * from `09_iva_unicos` iv, dbAmeca2.EstablecimientosLiquiMes em
WHERE em.id_establecimiento=iv.id_establecimiento AND em.periodo='201909';

-- update de los que ya figuran en EstablecimientosLiquiMes:  172  de 177
UPDATE dbAmeca2.EstablecimientosLiquiMes em, `09_iva_unicos` iv 
SET em.alicuota_iva=21, em.compra_iva=iv.CompraGenérica, em.percepcion_iva=iv.RetenciónPercepción, em.saft_iva=iv.SAFTécnico,
	em.saldo_iva=em.base_imponible*0.21-iv.CompraGenérica*0.21-iv.RetenciónPercepción, activo_iva_periodo=1
WHERE em.id_establecimiento=iv.id_establecimiento AND em.periodo='201909';

SELECT em.*
from dbAmeca2.EstablecimientosLiquiMes em, `09_iva_unicos` iv
WHERE em.id_establecimiento=iv.id_establecimiento AND em.periodo='201909' ;

SELECT * from `09_iva_unicos` iv WHERE iv.CUIT='30-71556584-2';
SELECT * FROM dbAmeca.EstablecimientosLiquiMes WHERE id_establecimiento=311;

-- estos figuran en ELiquiMes pero en el periodo anterior
20-11869618-3	96  -- IBAÑEZ MIGUEL ANTONIO, Domicilio Fiscal: Colon 3660
20-94039526-8	259 -- YAO FAXING	LA MERCED 4656
30-71556584-2	311 -- PALLAS LZ S.R.L	AV RIVADAVIA 6087
20-94029458-5	341 -- ZHANG MING	AV ANGEL GALLARDO 685
27-95683580-7	379 -- CHEN MINGQIN	GUATEMALA 4832

SELECT iv.id_establecimiento, iv.* from `09_iva_unicos` iv 
WHERE iv.id_establecimiento not in (SELECT em.id_establecimiento FROM dbAmeca2.EstablecimientosLiquiMes em WHERE em.periodo='201909');


INSERT INTO dbAmeca2.EstablecimientosLiquiMes 
(id_establecimiento, base_imponible, alicuota_iibb, alicuota_iva, percepcion_iibb, percepcion_iva, 
saldo_iibb, saldo_iva, periodo, compra_iva, saft_iva, activo_iva_periodo, activo_iibb_periodo)
SELECT iv.id_establecimiento, iv.BaseImponible , 3, 21, 0, iv.RetenciónPercepción, 0,
truncate (iv.BaseImponible*0.21-iv.RetenciónPercepción-iv.CompraGenérica*0.21, 2), '201909', 
iv.CompraGenérica, iv.SAFTécnico, 1, 0
FROM `09_iva_unicos` iv WHERE iv.id_establecimiento=379;

-- sucursales
SELECT * from `09_iva_sucursales` iv;


SELECT iv.id_comercio, iv.* from `09_iva_sucursales` iv, dbAmeca2.EstablecimientosLiquiMes em
WHERE em.id_establecimiento=iv.id_establecimiento AND em.periodo='201909'
order by iv.id_comercio;

-- update de los que ya figuran en EstablecimientosLiquiMes:  52  de 55
UPDATE dbAmeca2.EstablecimientosLiquiMes em, `09_iva_sucursales` iv 
SET em.alicuota_iva=21, em.compra_iva=iv.CompraGenérica, em.percepcion_iva=iv.RetenciónPercepción, em.saft_iva=iv.SAFTécnico,
	em.saldo_iva=em.base_imponible*0.21-iv.CompraGenérica*0.21-iv.RetenciónPercepción, activo_iva_periodo=1
WHERE em.id_establecimiento=iv.id_establecimiento AND em.periodo='201909';

-- los tres que faltan
SELECT iv.id_establecimiento, iv.* from `09_iva_sucursales` iv 
WHERE iv.id_establecimiento not in (SELECT em.id_establecimiento FROM dbAmeca2.EstablecimientosLiquiMes em WHERE em.periodo='201909');


INSERT INTO dbAmeca2.EstablecimientosLiquiMes 
(id_establecimiento, base_imponible, alicuota_iibb, alicuota_iva, percepcion_iibb, percepcion_iva, 
saldo_iibb, saldo_iva, periodo, compra_iva, saft_iva, activo_iva_periodo, activo_iibb_periodo)
SELECT iv.id_establecimiento, iv.BaseImponible , 3, 21, 0, iv.RetenciónPercepción, 0,
truncate (iv.BaseImponible*0.21-iv.RetenciónPercepción-iv.CompraGenérica*0.21, 2), '201909', 
iv.CompraGenérica, iv.SAFTécnico, 1, 0
FROM `09_iva_sucursales` iv WHERE iv.id_establecimiento=90;





==================

SELECT em.saft_iva, em.* from dbAmeca2.EstablecimientosLiquiMes as em WHERE saft_iva<0;

SELECT * FROM `09_iva_sucursales` iv where iv.SAFTécnico!=0;
SELECT * FROM `09_iva_unicos` iv where iv.SAFTécnico!=0;

select * from dbAmeca.Establecimientos where nro_cuit='27-94160892-8';

select * from dbAmeca.Zonas;


