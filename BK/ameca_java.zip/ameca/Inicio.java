package ameca;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;




/**
 *
 * @author manu
 */
public class Inicio extends HttpServlet {

        HTML htm=new HTML();

    
    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
    if (!HTML.getIgnited_localidades())
         HTML.Carga_localidades();
    if (!HTML.getIgnited_condiciones_iva())
         HTML.Carga_condiciones_iva();
    if (!HTML.getIgnited_condiciones_iibb())
         HTML.Carga_condiciones_iibb();
    if (!HTML.getIgnited_periodo())
         htm.Carga_periodo();
    if (!HTML.getIgnited_categorias_autonomo())
         HTML.Carga_categorias_autonomo();    
    if (!HTML.getIgnited_categorias_monotributo())
         HTML.Carga_categorias_monotributo();
        
    String operacion  = request.getParameter ("operacion") != null ?  request.getParameter ("operacion") : "nuevo" ;
    String new_periodo  = request.getParameter ("new_periodo") != null ?  request.getParameter ("new_periodo") : "0" ;
    String set_periodo  = request.getParameter ("set_periodo") != null ?  request.getParameter ("set_periodo") : "0" ;

        
        out.println(HTML.getHead("inicio", htm.getPeriodo_nostatic())); //devuelve la mitad de la tabla con <tr>s hasta las catgegs del menu (inicio, comercios, liquidaciones, facturacion).

        switch (new_periodo)
            {
            case "1": htm.Carga_periodo();
                    break;
            case "2": htm.setPeriodo_nostatic(set_periodo);
                    break;
        }
        
        
        out.println("<table>"
                + "<tr><td>"+htm.getPeriodo_prn()+"</td></tr>"
                + "<tr><td>"+htm.getPeriodo_prn_long()+"</td></tr>"
                + "<tr><td height='266px'></td></tr>"
                + "<tr><td>ignited periodo?: "+HTML.getIgnited_periodo()+"</td></tr>"
                + "<tr><td>periodo: "+htm.getPeriodo_nostatic()+"</td></tr>"
                + "<tr><td>periodo_com: <a href='/ameca/inicio?new_periodo=1'>UPDATE PERIODO</a> </td></tr>"
                + "<tr><td>periodo_com: <a href='/ameca/inicio?new_periodo=2&set_periodo=201912'>SET PERIODO 201912</a> </td></tr>"
                + "</table>"); 
        
        

            
        out.println("<table>"
                + "<tr><td height='50px'></td></tr>"
                + "<tr><td>carga manual realizada</td></tr>"
                + "<tr><td>ignited periodo?: "+HTML.getIgnited_periodo()+"</td></tr>"
                + "<tr><td>periodo: "+htm.getPeriodo_nostatic()+"</td></tr>"
//                + "<tr><td>periodo_com: "+HTML.getPeriodo_com()+"</td></tr>"
                + "</table>"); 
        out.println(HTML.getTail());
    }
}