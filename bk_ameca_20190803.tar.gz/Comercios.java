/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ameca;

/**
 *
 * @author manu
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import manu.utils.*;

public class Comercios extends HttpServlet
{  public void doGet(HttpServletRequest request, HttpServletResponse response)
	  throws ServletException, IOException

   {  //	htmls.logger.fine("homeOsoc. Carga servlet\n--");
   
   		response.setContentType("text/html");
	  	PrintWriter out = response.getWriter();

		String operacion  = request.getParameter ("operacion") != null ?  request.getParameter ("operacion") : "nuevo" ;
		String nro_cuit  = request.getParameter ("nro_cuit") != null ?  request.getParameter ("nro_cuit") : "--" ;
		String razon_social  = request.getParameter ("razon_social") != null ?  request.getParameter ("razon_social") : "" ;
		String nombre_responsable  = request.getParameter ("nombre_responsable") != null ?  request.getParameter ("nombre_responsable") : "" ;
		String apellido_responsable  = request.getParameter ("apellido_responsable") != null ?  request.getParameter ("apellido_responsable") : "" ;
		String id_zona  = request.getParameter ("id_zona") != null ?  request.getParameter ("id_zona") : "0" ;
		String id_localidad  = request.getParameter ("id_localidad") != null ?  request.getParameter ("id_localidad") : "0" ;
		String nro_telefono  = request.getParameter ("nro_telefono") != null ?  request.getParameter ("nro_telefono") : "" ;
		String email  = request.getParameter ("email") != null ?  request.getParameter ("email") : "" ;

		String id_comercio  = request.getParameter ("id_comercio") != null ?  request.getParameter ("id_comercio") : "0" ;

                

                if(operacion.equals("find"))
                    {
                    out.println("<html><head><title>Ameca</title>\n\n</head>" +
   				"<body marginheight='0' marginwidth='0'>  \n\n  " +
   				"\nIngrese CUIT del Comercio: <br>" +
   				"\n<form action=\"/ameca/comercios\">\n\t" +
                                "\n\tCUIT: <input type=\"number\" name=\"nro_cuit\">\n\t");
		
                    out.println("<input type=\"hidden\" name=\"operacion\" value=\"find\"> "+ 
                                "<input type=\"submit\"></form><br><br>");
                    
                    if(!nro_cuit.equals("--"))
                        out.println(this.TablaFindComercios(nro_cuit));
                    
                    out.println("</body></html>");


                    }
                else if (operacion.equals("new"))
                    {
                    out.println("<html><head><title>Ameca - Nuevo Comercio</title>\n\n</head>" +
   				"<body marginheight='0' marginwidth='0'>  \n\n  "+
   				"\nDatos del nuevo Comercio: <br>"+
   				"\n<form action=/ameca/comercios><table cellSpacing='0' cellPadding='0'>\n\t"+
                                "<tr>\n\t\t<td>CUIT: </td><td><input type=\"number\" name=\"nro_cuit\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Razon Social: </td><td><input type=\"text\" name=\"razon_social\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Nombre Responsable: </td><td><input type=\"text\" name=\"nombre_responsable\"></td>\n\t"+
                                "\t<td>Apellido Responsable: </td><td><input type=\"text\" name=\"apellido_responsable\"></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Domicilio Fiscal: </td><td><input type=\"text\" name=\"domicilio_fiscal\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Localidad: </td><td><select name=\"id_localidad\"><option value=\"1\">CABA</option><option value=\"2\">Pvcia. BA</option></td>\t"+
                                "\t<td>Zona: </td><td><select name=\"id_zona\"><option value=\"1\">Caminando</option><option value=\"2\">Lanus</option></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Telefono: </td><td><input type=\"number\" name=\"nro_telefono\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Email: </td><td><input type=\"email\" name=\"email\"></td><td></td><td></td></tr>");
		
                    out.println("</table><input type=\"hidden\" name=\"operacion\" value=\"save\"> <input type=\"submit\"></form></body></html>");
                    
                    
                    }
                else if (operacion.equals("save")) //guarda los datos recibidos del formulario ya completo
                    {
                    out.println("<html><head><title>Ameca - Save Data</title>\n\n</head>" +
   				"<body marginheight='0' marginwidth='0'>  \n\n  "+
   				"\nValores recibidos del formulario: <br>"+
   				"\n<table cellSpacing='0' cellPadding='0'>\n\t"+
                                "<tr>\n\t\t<td>CUIT: "+nro_cuit+"</td></tr>"+
                                "<tr>\n\t\t<td>Razon Social: "+razon_social+"</td></tr>"+
   				"\n\t<tr>\n\t\t<td>Nombre Responsable: "+nombre_responsable+"</td></tr>"+
   				"\n\t<tr>\n\t\t<td>Apellido Responsable: "+apellido_responsable+"</td></tr>"+
   				"\n\t<tr>\n\t\t<td>Localidad: "+id_localidad+"</td></tr>"+
   				"\n\t<tr>\n\t\t<td>Zona: "+id_zona+"</td></tr>" +
   				"\n\t<tr>\n\t\t<td>Telefono: "+nro_telefono+"</td></tr>" +
   				"\n\t<tr>\n\t\t<td>E-Mail: "+email+"</td></tr>" +
                                "</table>");
                    
                    String res=this.insertaComercio(nro_cuit, razon_social, nombre_responsable, apellido_responsable, id_zona, id_localidad, nro_telefono, email);
                    
                    out.println("INSERT Execute: "+res+"<br><br>");
                    
                    
                    out.println("<a href=\"/ameca/comercios?operacion=edit&id_comercio="+res+"\">Cargar Establecimientos</a> <br><br>");
                    out.println("<a href=\"/ameca/comercios?operacion=new\">Nuevo Comercio</a></body></html>");
                    
                    }
                else if (operacion.equals("edit"))
                    {
                    out.println("<html><head><title>Ameca - Edit Comercios</title>\n\n</head>" +
   				"<body marginheight='0' marginwidth='0'>  \n\n  "+
   				"\nEditar Datos del Comercio<br><br>"+
   				"\n<table cellSpacing='2' cellPadding='2' border='1'>\n\t"+
                                "<tr>\n\t\t<td>Datos del Comercio</td>\t</tr>\n\t");

                    out.println("<tr>\n\t\t<td>");
                    
                    out.println(this.DatosComercioTable(id_comercio));
                    
                    out.println("\t</td></tr>\t\n");

                    out.println("\n\n\t<tr><td></td></tr>\n\n\t<tr><td>Establecimientos del Comercio <a href=\"/ameca/establecimientos?operacion=new&id_comercio="+id_comercio+"\">Nuevo</a></td></tr>");

                    out.println("\n\t<tr><td>"+this.DatosEstablecimientoTable(id_comercio)+"</td></tr>");

                    out.println("\n\n\t</table>");                    
                                        
                    }
                
                
  }



    // Recibe  el id_comercio y devuelve una tabla html con sus datos 

    private String DatosComercioTable(String id_comercio) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        CX connection=null;

        String razon_social="", nombre_responsable="", apellido_responsable="", id_zona="", id_localidad="", nro_telefono="", email="", nro_cuit="";
	String resul="";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement( "SELECT nro_cuit, razon_social, nombre_responsable, apellido_responsable, id_zona, id_localidad, nro_telefono, email " +
                                        " FROM dbAmeca.Comercios"+
                                        " WHERE id_comercio="+id_comercio);

                                               
            rs = pst.executeQuery();
            if (rs.next())
                {
                 nro_cuit=rs.getString(1);
                 razon_social=rs.getString(2);
                 nombre_responsable=rs.getString(3);
                 apellido_responsable=rs.getString(4);
                 id_zona=rs.getString(5);
                 id_localidad=rs.getString(6);
                 nro_telefono=rs.getString(7);
                 email=rs.getString(8);
                }
            
            resul="<table><tr>\n\t\t<td>CUIT: "+nro_cuit+"</td></tr>"+
                    "<tr>\n\t\t<td>Razon Social: "+razon_social+"</td></tr>"+
                    "\n\t<tr>\n\t\t<td>Nombre Responsable: "+nombre_responsable+"</td></tr>"+
                    "\n\t<tr>\n\t\t<td>Apellido Responsable: "+apellido_responsable+"</td></tr>"+
                    "\n\t<tr>\n\t\t<td>Localidad: "+id_localidad+"</td></tr>"+
                    "\n\t<tr>\n\t\t<td>Zona: "+id_zona+"</td></tr>" +
                    "\n\t<tr>\n\t\t<td>Telefono: "+nro_telefono+"</td></tr>" +
                    "\n\t<tr>\n\t\t<td>E-Mail: "+email+"</td></tr>" +
                    "</table>";
            
            }
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con datos del comercio
        }

 
    

    // Recibe  el id_comercio y devuelve una tabla html con los datos de sus establecimientos 

    private String DatosEstablecimientoTable(String id_comercio) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        CX connection=null;

	String resul="";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement( "SELECT id_establecimiento, id_actividad, nombre_establecimiento, direccion_establecimiento, id_zona, id_localidad, "+
                                                "porcentaje_sociedad, nro_telefono_establecimiento, email_establecimiento " +
                                        " FROM dbAmeca.Establecimientos"+
                                        " WHERE id_comercio="+id_comercio);

                                               

            rs = pst.executeQuery();

            resul="\n<table>";
            while (rs.next())
                {
                 resul+="\n\t<tr>\n\t\t<td>Nombre Establecimiento: "+rs.getString(3)+"</td>\n\t</tr>";
                 resul+="\n\t<tr>\n\t\t<td>Direccion Establecimiento: "+rs.getString(4)+"</td>\n\t</tr>";
                 resul+="\n\t<tr>\n\t\t<td>Actividad: "+rs.getString(2)+"</td>\n\t</tr>";
                 resul+="\n\t<tr>\n\t\t<td>Editar Establecimiento <a href=\"/ameca/establecimientos?operacion=liqui&id_establecimiento="+rs.getString(1)+"&id_comercio="+id_comercio+"\">Cargar Tributos</a> </td>\n\t</tr>";
                 resul+="\n\t<tr>\n\t\t<td>================================</td>\n\t</tr>";
                }

            resul+="\n</table>";
            
            }
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con establecimientos del comercio activo
        }

    
    
    
    
     // inserta nuevo comercio en tabla Comercios y devuelve el id_comercio 

    private String insertaComercio(String nro_cuit, String razon_social, String nombre_responsable, String apellido_responsable, 
                                    String id_zona, String id_localidad, String nro_telefono, String email) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        CX connection=null;
        long resul_insert;
 
	String resul="";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement("INSERT INTO dbAmeca.Comercios (nro_cuit, razon_social, nombre_responsable, apellido_responsable, id_zona, id_localidad, nro_telefono, email) "
                                    + " VALUES ('"+nro_cuit+"', '"+razon_social+"', '"+nombre_responsable+"', '"+apellido_responsable+"', "
                                                +id_zona+", "+id_localidad+", '"+nro_telefono+"', '"+email+"')");
                                               
            resul_insert = pst.executeUpdate();
            if (resul_insert>0)
                pst = con.prepareStatement("select last_insert_id()");
            else 
                return "todo mal";
            rs=pst.executeQuery();
            if (rs.next())
		resul=rs.getString(1);
            rs = pst.executeQuery();

            }
        catch (SQLException ex) {
               return "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                return ex.getMessage();
                }
            }
        
        return resul;  //id_comercio del nuevo registro
        }

    
    
     
     // recibe CUIT, entero o parte, y devuelve tabla con loc comercios que cumplen con link para editarlos
    
   private String TablaFindComercios (String nro_cuit) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        CX connection=null;
        
	String resul="<table>";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement("SELECT id_comercio, razon_social, apellido_responsable FROM dbAmeca.Comercios WHERE nro_cuit like '"+nro_cuit+"%' ");
                                               
            rs = pst.executeQuery();
            while (rs.next())
		resul+="<tr><td>"+rs.getString(2)+", "+rs.getString(3)+"</td><td><a href=\"/ameca/comercios?operacion=edit&id_comercio="+rs.getString(1)+"\">Ver Comercio</a></tr>\n";
            resul+="</table";
            }
            
        catch (SQLException ex) {
               return "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                return ex.getMessage();
                }
            }
        
        return resul;  //id_comercio del nuevo registro
        }


}