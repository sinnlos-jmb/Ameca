package ameca;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


//import ameca.CX;  no hace falta importar porque es el mismo package

/**
 *
 * @author manu
 */
public class Hikari extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        CX connection=null;
        
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Ameca - Contabilidad</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Sistema Ameca - Prueba Cx POOL Hikari</h1>");
        out.println("<table>");
        
        try 
            {
            con=CX.getCx_pool();
             if (con==null)
                out.println("CONEXION NULA</table></body></html>");
            
            pst = con.prepareStatement("SELECT * FROM Comercios");
            rs = pst.executeQuery();

            while (rs.next()) 
                {
                out.println("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td>");
                out.println("<td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td></tr>");
                }
            }
        catch (SQLException ex) {
               out.println("<br><br>ERROR: "+ex.getMessage()+"<br><br>");
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
              // lgr.log(Level.WARNING, ex.getMessage(), ex);
                }
            }
        
        out.println("</table></body>");
        out.println("</html>");
    }
}