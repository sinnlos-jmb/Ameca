package ameca;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;




/**
 *
 * @author manu
 */
public class Inicio extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Ameca - Contabilidad</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Sistema Ameca - Home</h1>");
        out.println("<br> <a href=\"/ameca/comercios?operacion=new\">Nuevo Comercio</a> <br>");
        out.println("<br> <a href=\"/ameca/comercios?operacion=find\">Administrar Comercios</a> <br>");
        out.println("</body>");
        out.println("</html>");
    }
}