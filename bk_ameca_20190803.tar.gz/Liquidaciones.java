/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ameca;

/**
 *
 * @author manu
 */

import java.io.IOException;
import java.io.PrintWriter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import manu.utils.*;

public class Liquidaciones extends HttpServlet
{  public void doGet(HttpServletRequest request, HttpServletResponse response)
	  throws ServletException, IOException

   {  //	htmls.logger.fine("homeOsoc. Carga servlet\n--");
   
   		response.setContentType("text/html");
	  	PrintWriter out = response.getWriter();

		String operacion  = request.getParameter ("operacion") != null ?  request.getParameter ("operacion") : "nuevo" ;
		
 		String id_comercio  = request.getParameter ("id_comercio") != null ?  request.getParameter ("id_comercio") : "0" ;
		String id_establecimiento  = request.getParameter ("id_establecimiento") != null ?  request.getParameter ("id_establecimiento") : "0" ;

		String periodo  = request.getParameter ("periodo") != null ?  request.getParameter ("periodo") : "2021908" ;
		String base_imponible  = request.getParameter ("base_imponible") != null ?  request.getParameter ("base_imponible") : "0" ;
		String alicuota_iva  = request.getParameter ("alicuota_iva") != null ?  request.getParameter ("alicuota_iva") : "21" ;
		String alicuota_iibb  = request.getParameter ("alicuota_iibb") != null ?  request.getParameter ("alicuota_iibb") : "3" ;
		String compra_iva  = request.getParameter ("compra_iva") != null ?  request.getParameter ("compra_iva") : "0" ;
		String percepcion_iva  = request.getParameter ("percepcion_iva") != null ?  request.getParameter ("percepcion_iva") : "0" ;
		String percepcion_iibb  = request.getParameter ("percepcion_iibb") != null ?  request.getParameter ("percepcion_iibb") : "0" ;
                
                

                if(operacion.equals("find"))
                    {


                    }
                else if (operacion.equals("new"))
                    {
                    out.println("<html><head><title>Ameca - Nuevo Comercio</title>\n\n</head>" +
   				"<body marginheight='0' marginwidth='0'>  \n\n  "+
   				"\nDatos del nuevo Comercio: <br>"+
   				"\n<form action=/ameca/establecimientos><table cellSpacing='0' cellPadding='0'>\n\t"+
                                "<tr>\n\t\t<td>Direccion: </td><td><input type=\"text\" name=\"direccion_establecimiento\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Nombre Establecimiento: </td><td><input type=\"text\" name=\"nombre_establecimiento\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Actividad: </td><td><select name=\"id_actividad\"><option value=\"1\">Supermercado</option><option value=\"2\">Verduleria</option></td>\t"+
                                "<tr>\n\t\t<td>Localidad: </td><td><select name=\"id_localidad\"><option value=\"1\">CABA</option><option value=\"2\">Pvcia. BA</option></td>\t"+
                                "\t<td>Zona: </td><td><select name=\"id_zona\"><option value=\"1\">Caminando</option><option value=\"2\">Lanus</option></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Telefono: </td><td><input type=\"number\" name=\"nro_telefono_establecimiento\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Email: </td><td><input type=\"email\" name=\"email_establecimiento\"></td><td></td><td></td></tr>");
		
                    out.println("</table><input type=\"hidden\" name=\"operacion\" value=\"save\">\n<input type=\"hidden\" name=\"id_comercio\" value=\""+id_comercio+"\"> <input type=\"submit\"></form></body></html>");
                    
                    }
                else if (operacion.equals("save")) //guarda los datos recibidos del formulario ya completo
                    {
                    out.println("<html><head><title>Ameca - Save Data</title>\n\n</head>" +
   				"<body marginheight='0' marginwidth='0'>  \n\n  "+
   				"\nValores recibidos del formulario: <br>"+
   				"\n<table cellSpacing='0' cellPadding='0'>\n\t"+
                                "</table>");
                    

                    out.println("<a href=\"/ameca/comercios?operacion=edit&id_comercio="+id_comercio+"\">Ver Comercio y Establecimientos</a> <br><br>");
                    out.println("<a href=\"/ameca/establecimientos?operacion=new&id_comercio="+id_comercio+"\">Nuevo Establecimiento</a></body></html>");
                    
                    }
                else if (operacion.equals("edit"))
                    {
                    out.println("<html><head><title>Ameca - Edit Comercios</title>\n\n</head>" +
   				"<body marginheight='0' marginwidth='0'>  \n\n  "+
   				"\nEditar Datos del Comercio<br><br>"+
   				"\n<table cellSpacing='2' cellPadding='2' border='1'>\n\t"+
                                "<tr>\n\t\t<td>Datos del Comercio</td>\t</tr>\n\t");

                    out.println("\n\n\t</table>");                    
                                        
                    }
                else if(operacion.equals("liqui"))
                    {
                    out.println("<html><head><title>Ameca - Carga Tributos</title>\n\n</head>" +
   				"<body marginheight='0' marginwidth='0'>  \n\n  "+
   				"\nDatos para el calculo impositivo: <br>"+
   				"\n<form action=/ameca/establecimientos><table cellSpacing='0' cellPadding='0'>\n\t"+
                                "<tr>\n\t\t<td>Periodo (mmyyyy): </td><td><input type=\"text\" name=\"periodo\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Base Imponible: </td><td><input type=\"number\" name=\"base_imponible\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Alicuota IVA:   </td><td><input type=\"number\" name=\"alicuota_iva\" value=\"21\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Compra (IVA): </td><td><input type=\"number\" name=\"compra_iva\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Percepcion IVA: </td><td><input type=\"number\" name=\"percepcion_iva\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Alicuota IIBB:   </td><td><input type=\"number\" name=\"alicuota_iibb\" value=\"3\"></td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Percepcion IIBB: </td><td><input type=\"number\" name=\"percepcion_iibb\"></td><td></td><td></td></tr>\n\t");
		
                    out.println("</table><input type=\"hidden\" name=\"operacion\" value=\"liqui_save\">\n<input type=\"hidden\" name=\"id_comercio\" value=\""+id_comercio+"\">"+
                                "\n<input type=\"hidden\" name=\"id_establecimiento\" value=\""+id_establecimiento+"\"> \n<input type=\"submit\">\n</form></body>\n\n</html>");


                    }
                else if(operacion.equals("liqui_save"))
                    {
                    out.println("<html><head><title>Ameca - Guarda Actividad Impositiva</title>\n\n</head>" +
   				"<body marginheight='0' marginwidth='0'>  \n\n  "+
   				"\nDatos para el calculo impositivo: <br>"+
   				"\n<table cellSpacing='0' cellPadding='0'>\n\t"+
                                "<tr>\n\t\t<td>Periodo (mmyyyy): </td><td>"+periodo+"</td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Base Imponible: </td><td>"+base_imponible+"</td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Alicuota IVA:   </td><td>"+alicuota_iva+"</td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Compra (IVA): </td><td>"+compra_iva+"</td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Percepcion IVA: </td><td>"+percepcion_iva+"</td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Alicuota IIBB:   </td><td>"+alicuota_iibb+"</td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>Percepcion IIBB: </td><td>"+percepcion_iibb+"</td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>id_comercio: </td><td>"+id_comercio+"</td><td></td><td></td></tr>\n\t"+
                                "<tr>\n\t\t<td>id_establecimiento: </td><td>"+id_establecimiento+"</td><td></td><td></td></tr>\n\t");
                    out.println("<br><br><a href=\"/ameca/comercios?operacion=edit&id_comercio="+id_comercio+"\">Ver Comercio y Establecimientos</a> <br>");
                    out.println("</body>\n\n</html>");


                    }               
                

   
   
   
 }



   
// Recibe  el id_comercio y devuelve una tabla de los saldos de sus establecimientos 

    public static String LiquiEstablecimientoTable(String id_establecimiento) 
	{
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        String base_imponible="", debito_iva="", debito_iibb="", venta_total="", compra_iva="", credito_iva="", compra_total="", percepcion_iva="", 
                percepcion_iibb="", saldo_ddjj_iva="", saldo_ddjj_iibb="", alicuota_iva="", alicuota_iibb="";
	String resul="";
        try 
            {
            con=CX.getCx_pool();
            pst = con.prepareStatement( "SELECT FORMAT (base_imponible, 2, 'de_DE'), " +
                                                "@debitoF_iva := (base_imponible*alicuota_iva/100), " +   //debito fiscal IVA
                                                "@debitoF_iibb := (base_imponible*alicuota_iibb/100), " +  // debito fiscal IIBB
                                                "FORMAT (base_imponible+@debitoF_iva, 2, 'de_DE'), " + //venta total
                                                "FORMAT (compra_iva, 2, 'de_DE'), " +
                                                "@iva_credito := (compra_iva*alicuota_iva/100), " +
                                                "FORMAT (compra_iva+@iva_credito, 2, 'de_DE'), " + //compra total
                                                "percepcion_iva, percepcion_iibb, " +
                                                "FORMAT (@debitoF_iva-@iva_credito-percepcion_iva, 2, 'de_DE'), " +  // SALDO DDJJ IVA
                                                "@debitoF_iibb-percepcion_iibb, "+   // SALDO DDJJ IIBB
                                                "alicuota_iva, alicuota_iibb, "+ 
                                                "FORMAT (@debitoF_iva, 2, 'de_DE'), "+ 
                                                "FORMAT (@debitoF_iibb, 2, 'de_DE') "+ 
                                       " FROM dbAmeca.EstablecimientosLiquiMes " +
                                       " WHERE dbAmeca.EstablecimientosLiquiMes.id_establecimiento ="+id_establecimiento);
            
/*            
            pst = con.prepareStatement( "SELECT dbAmeca.Comercios.nro_cuit, dbAmeca.Comercios.nombre_responsable, dbAmeca.Establecimientos.direccion_establecimiento, " +
                                                "dbAmeca.EstablecimientosLiquiMes.base_imponible, " +
                                                "@debitoF_iva := (dbAmeca.EstablecimientosLiquiMes.base_imponible*dbAmeca.EstablecimientosLiquiMes.alicuota_iva/100) as 'debito fiscal_iva', " +
                                                "@debitoF_iibb := (dbAmeca.EstablecimientosLiquiMes.base_imponible*dbAmeca.EstablecimientosLiquiMes.alicuota_iibb/100) as 'debito fiscal_iibb', " +
                                                "dbAmeca.EstablecimientosLiquiMes.compra_iva, " +
                                                "@ivaC := (dbAmeca.EstablecimientosLiquiMes.compra_iva*dbAmeca.EstablecimientosLiquiMes.alicuota_iva/100) as 'iva credito', " +
                                                "@debitoF-@ivaC as 'compra total', " +
                                                "dbAmeca.EstablecimientosLiquiMes.percepcion_iva, " +
                                                "dbAmeca.EstablecimientosLiquiMes.percepcion_iibb, " +
                                                "@debitoF_iva-@ivaC-percepcion_iva as 'saldo ddjj iva', " +
                                                "@debitoF_iibb-percepcion_iibb as 'saldo ddjj iibb' " +
                                       " FROM dbAmeca.Comercios, dbAmeca.Establecimientos, dbAmeca.EstablecimientosLiquiMes " +
                                       " WHERE dbAmeca.Comercios.id_comercio = dbAmeca.Establecimientos.id_comercio " +
                                           " AND dbAmeca.Establecimientos.id_establecimiento=dbAmeca.EstablecimientosLiquiMes.id_establecimiento " +
                                           " AND dbAmeca.Establecimientos.id_establecimiento ="+id_establecimiento);
                                        
*/

            resul="<table><tr>\n\t\t<td>Base Imponible</td><td>Alic. IVA</td><td>Alic. IIBB</td><td>Debito IVA</td><td>Venta Total</td><td>Debito IIBB</td>"+
                    "<td>Compra IVA</td><td>Credito IVA</td><td>Compra Total</td><td>Percepcion IVA</td><td>Percepcion IIBB</td>"+
                    "<td>SALDO D.D.J.J. IVA</td><td>SALDO D.D.J.J. IIBB</td><td>";

            rs = pst.executeQuery();
            while (rs.next())
                {
                 base_imponible=rs.getString(1);
                 alicuota_iva=rs.getString(12);
                 alicuota_iibb=rs.getString(13);
                 debito_iva=rs.getString(14);
                 debito_iibb=rs.getString(15);
                 venta_total=rs.getString(4);
                 compra_iva=rs.getString(5);
                 credito_iva=rs.getString(6);
                 compra_total=rs.getString(7);
                 percepcion_iva=rs.getString(8);
                 percepcion_iibb=rs.getString(9);
                 saldo_ddjj_iva=rs.getString(10);
                 saldo_ddjj_iibb=rs.getString(11);

                resul+="\n\t<tr><td>"+base_imponible+"</td><td>"+alicuota_iva+"</td><td>"+alicuota_iibb+"</td><td>"+debito_iva+"</td><td>"+venta_total+"</td>"+
                    "<td>"+debito_iibb+"</td><td>"+compra_iva+"</td><td>"+credito_iva+"</td><td>"+compra_total+"</td>" +
                    "<td>"+percepcion_iva+"</td><td>"+percepcion_iibb+"</td><td>"+saldo_ddjj_iva+"</td><td>"+saldo_ddjj_iibb+"</td>" +
                    "\n\t<tr>";
                }
            resul+="\n\t</table>";


            
            }
        catch (SQLException ex) {
               resul= "<br><br>ERROR: "+ex.getMessage()+"<br><br>";
            //Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
            //lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        finally 
            {
            try {
                if (rs != null) 
                  rs.close();
                if (pst != null)
                  pst.close();
                if (con != null) 
                  con.close();
                }
            catch (SQLException ex) {
              // Logger lgr = Logger.getLogger(HikariCPEx.class.getName());
                resul= ex.getMessage();
                }
            }
        
        return resul;  //tabla con datos de liquidacion del establecimiento
        }


     

}